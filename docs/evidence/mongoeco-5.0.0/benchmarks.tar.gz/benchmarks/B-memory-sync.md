# Benchmark Report

## Environment

- Generated at: 2026-11-02T19:54:39.060707+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 5
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: unset
- Git revision: `7dcb9df2087c4e8d0cad091bfdce1ad9d45c3699`
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:4a6949d179df72d2c7de595975c08afc7819619cb1bbaa37e3c286ab29df827f`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.2453 | +61.0% | 0.1860 | memory/python scan>filter>slice | 0.00 | 83.66 |

- `memory-sync` `query_shape`: `username equality`
- `memory-sync` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0411 | +45.7% | 0.0360 | memory/python scan>filter | 0.03 | 102.50 |

- `memory-sync` `query_shape`: `city equality`
- `memory-sync` `consumption_mode`: `first`
- `memory-sync` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.6378 | +128.6% | 0.6200 | memory/python scan>filter | 0.15 | 102.50 |

- `memory-sync` `query_shape`: `city equality`
- `memory-sync` `consumption_mode`: `materialized`
- `memory-sync` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0035 | +6.1% | 0.0020 | memory/python scan>filter>sort>project>slice | 0.00 | 102.94 |

- `memory-sync` `pipeline_shape`: `match-sort-limit-project`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.2551 | +20.0% | 0.2420 | memory/python scan>filter>sort>slice | 0.00 | 105.94 |

- `memory-sync` `query_shape`: `sort score desc + limit 10`
- `memory-sync` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.2547 | +20.3% | 0.2420 | memory/python scan>filter>sort>slice | 0.00 | 106.11 |

- `memory-sync` `query_shape`: `sort score desc + limit 10`
- `memory-sync` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.4074 | +9.5% | 0.3940 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.text title/body ada`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.3721 | +11.7% | 0.3560 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.autocomplete title/body alg`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.2402 | +13.1% | 0.2260 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.wildcard body *vector*`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.2244 | +16.7% | 0.2080 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.regex title Ada.*algorithms`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.4650 | +7.1% | 0.4520 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.4661 | +14.2% | 0.4500 | memory/search opaque | 0.01 | 110.06 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 1.2864 | +2.7% | 1.2720 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 1.2221 | +24.4% | 1.2060 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `2`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.7132 | +49.3% | 0.6960 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `2`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 1.0091 | +3.7% | 0.9940 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.3923 | +6.0% | 0.3800 | memory/search opaque | 0.00 | 110.06 |

- `memory-sync` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1023 | +45.5% | 0.0880 | memory/search opaque | 0.00 | 212.50 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1016 | +44.3% | 0.0860 | memory/search opaque | 0.00 | 212.50 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `10`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1013 | +48.3% | 0.0880 | memory/search opaque | 0.00 | 212.50 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `48`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1022 | +49.0% | 0.0880 | memory/search opaque | 0.00 | 216.55 |

- `memory-sync` `query_shape`: `$vectorSearch dotProduct topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `dotProduct`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1114 | +57.1% | 0.0960 | memory/search opaque | 0.00 | 219.70 |

- `memory-sync` `query_shape`: `$vectorSearch euclidean topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `euclidean`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1029 | +48.5% | 0.0900 | memory/search opaque | 0.00 | 219.70 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `334`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1066 | +46.8% | 0.0920 | memory/search opaque | 0.00 | 219.70 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `454`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1058 | +47.6% | 0.0920 | memory/search opaque | 0.00 | 219.70 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `10`
- `memory-sync` `candidates_evaluated`: `61`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1042 | +46.8% | 0.0900 | memory/search opaque | 0.00 | 219.70 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `666`
