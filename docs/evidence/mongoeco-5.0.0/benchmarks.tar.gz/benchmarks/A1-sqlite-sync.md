# Benchmark Report

## Environment

- Generated at: 2026-11-02T19:51:29.282019+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 5
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: unset
- Git revision: `bb0597c1b42d4228b547a8eec87ce704489bcb7b`
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:4a6949d179df72d2c7de595975c08afc7819619cb1bbaa37e3c286ab29df827f`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.3587 | 0.3589 | 0.2160 | sqlite/sql opaque | 0.10 | 93.17 |

- `sqlite-sync` `query_shape`: `username equality`
- `sqlite-sync` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.0697 | 0.0698 | 0.0420 | sqlite/sql opaque | 0.01 | 139.20 |

- `sqlite-sync` `query_shape`: `city equality`
- `sqlite-sync` `consumption_mode`: `first`
- `sqlite-sync` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.4486 | 0.4481 | 0.3560 | sqlite/sql opaque | 0.21 | 139.33 |

- `sqlite-sync` `query_shape`: `city equality`
- `sqlite-sync` `consumption_mode`: `materialized`
- `sqlite-sync` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.0028 | 0.0028 | 0.0020 | sqlite/sql scan>filter>sort>slice>project | 0.01 | 140.27 |

- `sqlite-sync` `pipeline_shape`: `match-sort-limit-project`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.3561 | 0.3523 | 0.2900 | sqlite/sql scan>filter>sort>slice | 0.09 | 144.58 |

- `sqlite-sync` `query_shape`: `sort score desc + limit 10`
- `sqlite-sync` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.3262 | 0.3174 | 0.2680 | sqlite/sql scan>filter>sort>slice | 0.07 | 144.73 |

- `sqlite-sync` `query_shape`: `sort score desc + limit 10`
- `sqlite-sync` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.9509 | 0.9485 | 0.9440 | sqlite/search opaque | 0.00 | 147.34 |

- `sqlite-sync` `query_shape`: `$search.text title/body ada`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.9505 | 0.9493 | 0.9400 | sqlite/search opaque | 0.00 | 147.34 |

- `sqlite-sync` `query_shape`: `$search.autocomplete title/body alg`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.9447 | 0.9437 | 0.9320 | sqlite/search opaque | 0.00 | 147.34 |

- `sqlite-sync` `query_shape`: `$search.wildcard body *vector*`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 3.7222 | 3.7220 | 3.7040 | sqlite/search opaque | 0.01 | 147.50 |

- `sqlite-sync` `query_shape`: `$search.regex title Ada.*algorithms`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 1.2254 | 1.2277 | 1.2160 | sqlite/search opaque | 0.02 | 147.50 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 1.2646 | 1.2631 | 1.2540 | sqlite/search opaque | 0.01 | 147.50 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.4315 | 0.4304 | 0.4220 | sqlite/search opaque | 0.01 | 147.53 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.5293 | 0.5251 | 0.5240 | sqlite/search opaque | 0.01 | 147.56 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `2`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.5193 | 0.5183 | 0.5120 | sqlite/search opaque | 0.00 | 147.78 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `2`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.4472 | 0.4413 | 0.4440 | sqlite/search opaque | 0.00 | 147.89 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.4014 | 0.3968 | 0.3960 | sqlite/search opaque | 0.00 | 147.89 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1117 | 0.1116 | 0.1060 | sqlite/search opaque | 0.00 | 151.28 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.0930 | 0.0929 | 0.0880 | sqlite/search opaque | 0.00 | 151.28 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `10`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1429 | 0.1426 | 0.1400 | sqlite/search opaque | 0.00 | 151.34 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `48`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1111 | 0.1113 | 0.1060 | sqlite/search opaque | 0.00 | 151.70 |

- `sqlite-sync` `query_shape`: `$vectorSearch dotProduct topk`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `dotProduct`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1119 | 0.1116 | 0.1020 | sqlite/search opaque | 0.00 | 151.84 |

- `sqlite-sync` `query_shape`: `$vectorSearch euclidean topk`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `euclidean`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1063 | 0.1052 | 0.1000 | sqlite/search opaque | 0.00 | 151.84 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `candidates_requested`: `32`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1131 | 0.1129 | 0.1020 | sqlite/search opaque | 0.00 | 151.84 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1885 | 0.1856 | 0.1800 | sqlite/search opaque | 0.00 | 151.84 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `exact_fallback_reason`: `candidate-prefilter-underflow`
- `sqlite-sync` `candidates_requested`: `10`
- `sqlite-sync` `candidates_evaluated`: `0`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1123 | 0.1120 | 0.1080 | sqlite/search opaque | 0.00 | 151.86 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`
