# Benchmark Report

## Environment

- Generated at: 2026-11-02T23:08:35.088117+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 1
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: stdlib
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:df42746bcc2361660d2498b901fd308006d07ab0a40254147146e1b1533ca552`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2704 | 0.2704 | 0.2100 | memory/python scan>filter>slice | 0.30 | 82.27 |

- `memory-sync` `query_shape`: `username equality`
- `memory-sync` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.0405 | 0.0405 | 0.0400 | memory/python scan>filter | 0.00 | 96.97 |

- `memory-sync` `query_shape`: `city equality`
- `memory-sync` `consumption_mode`: `first`
- `memory-sync` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.6390 | 0.6390 | 0.6200 | memory/python scan>filter | 0.52 | 97.52 |

- `memory-sync` `query_shape`: `city equality`
- `memory-sync` `consumption_mode`: `materialized`
- `memory-sync` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.0035 | 0.0035 | 0.0000 | memory/python scan>filter>sort>project>slice | 0.00 | 99.39 |

- `memory-sync` `pipeline_shape`: `match-sort-limit-project`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2490 | 0.2490 | 0.2400 | memory/python scan>filter>sort>slice | 0.00 | 100.92 |

- `memory-sync` `query_shape`: `sort score desc + limit 10`
- `memory-sync` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2502 | 0.2502 | 0.2400 | memory/python scan>filter>sort>slice | 0.00 | 101.62 |

- `memory-sync` `query_shape`: `sort score desc + limit 10`
- `memory-sync` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.4152 | 0.4152 | 0.4000 | memory/search opaque | 0.00 | 103.95 |

- `memory-sync` `query_shape`: `$search.text title/body ada`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.3742 | 0.3742 | 0.3600 | memory/search opaque | 0.00 | 103.95 |

- `memory-sync` `query_shape`: `$search.autocomplete title/body alg`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2401 | 0.2401 | 0.2200 | memory/search opaque | 0.00 | 104.23 |

- `memory-sync` `query_shape`: `$search.wildcard body *vector*`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2369 | 0.2369 | 0.2200 | memory/search opaque | 0.00 | 104.23 |

- `memory-sync` `query_shape`: `$search.regex title Ada.*algorithms`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.5015 | 0.5015 | 0.4800 | memory/search opaque | 0.00 | 104.25 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.4892 | 0.4892 | 0.4700 | memory/search opaque | 0.00 | 104.25 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 1.3007 | 1.3007 | 1.2800 | memory/search opaque | 0.00 | 104.34 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 1.2219 | 1.2219 | 1.2100 | memory/search opaque | 0.00 | 104.34 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `2`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.7082 | 0.7082 | 0.7000 | memory/search opaque | 0.00 | 104.47 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `2`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 1.0247 | 1.0247 | 1.0100 | memory/search opaque | 0.00 | 104.48 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.3880 | 0.3880 | 0.3800 | memory/search opaque | 0.00 | 104.48 |

- `memory-sync` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1052 | 0.1052 | 0.1000 | memory/search opaque | 0.00 | 161.30 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1032 | 0.1032 | 0.0900 | memory/search opaque | 0.00 | 161.30 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `10`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1012 | 0.1012 | 0.0900 | memory/search opaque | 0.00 | 161.30 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `48`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1017 | 0.1017 | 0.0900 | memory/search opaque | 0.00 | 167.66 |

- `memory-sync` `query_shape`: `$vectorSearch dotProduct topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `dotProduct`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.0995 | 0.0995 | 0.0800 | memory/search opaque | 0.00 | 177.17 |

- `memory-sync` `query_shape`: `$vectorSearch euclidean topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `euclidean`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1013 | 0.1013 | 0.0900 | memory/search opaque | 0.00 | 177.20 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `334`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1062 | 0.1062 | 0.0900 | memory/search opaque | 0.00 | 177.22 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `454`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1061 | 0.1061 | 0.1000 | memory/search opaque | 0.00 | 177.22 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `10`
- `memory-sync` `candidates_evaluated`: `61`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1027 | 0.1027 | 0.0900 | memory/search opaque | 0.00 | 177.22 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `666`
