# Benchmark Report

## Environment

- Generated at: 2026-11-02T23:10:46.867498+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 1
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: stdlib
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:df42746bcc2361660d2498b901fd308006d07ab0a40254147146e1b1533ca552`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.1929 | 0.1929 | 0.1700 | memory/python scan>filter>slice | 0.02 | 87.56 |

- `memory-async` `query_shape`: `username equality`
- `memory-async` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0369 | 0.0369 | 0.0300 | memory/python scan>filter | 0.00 | 98.30 |

- `memory-async` `query_shape`: `city equality`
- `memory-async` `consumption_mode`: `first`
- `memory-async` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.6128 | 0.6128 | 0.6100 | memory/python scan>filter | 3.83 | 102.12 |

- `memory-async` `query_shape`: `city equality`
- `memory-async` `consumption_mode`: `materialized`
- `memory-async` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0051 | 0.0051 | 0.0100 | memory/python scan>filter>sort>project>slice | 0.00 | 102.78 |

- `memory-async` `pipeline_shape`: `match-sort-limit-project`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2373 | 0.2373 | 0.2300 | memory/python scan>filter>sort>slice | 0.00 | 104.98 |

- `memory-async` `query_shape`: `sort score desc + limit 10`
- `memory-async` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2354 | 0.2354 | 0.2300 | memory/python scan>filter>sort>slice | 0.00 | 105.70 |

- `memory-async` `query_shape`: `sort score desc + limit 10`
- `memory-async` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.3866 | 0.3866 | 0.3900 | memory/search opaque | 0.00 | 113.97 |

- `memory-async` `query_shape`: `$search.text title/body ada`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.3496 | 0.3496 | 0.3500 | memory/search opaque | 0.00 | 113.97 |

- `memory-async` `query_shape`: `$search.autocomplete title/body alg`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2221 | 0.2221 | 0.2100 | memory/search opaque | 0.00 | 114.05 |

- `memory-async` `query_shape`: `$search.wildcard body *vector*`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2060 | 0.2060 | 0.2000 | memory/search opaque | 0.00 | 114.05 |

- `memory-async` `query_shape`: `$search.regex title Ada.*algorithms`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.4425 | 0.4425 | 0.4400 | memory/search opaque | 0.00 | 114.06 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.4430 | 0.4430 | 0.4400 | memory/search opaque | 0.00 | 114.06 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 1.2736 | 1.2736 | 1.2700 | memory/search opaque | 0.00 | 114.06 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 1.2093 | 1.2093 | 1.2100 | memory/search opaque | 0.00 | 114.06 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `2`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.6922 | 0.6922 | 0.6900 | memory/search opaque | 0.00 | 114.38 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `2`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.9787 | 0.9787 | 0.9800 | memory/search opaque | 0.00 | 114.38 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.3782 | 0.3782 | 0.3700 | memory/search opaque | 0.00 | 114.39 |

- `memory-async` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0842 | 0.0842 | 0.0800 | memory/search opaque | 0.12 | 176.41 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0834 | 0.0834 | 0.0800 | memory/search opaque | 0.02 | 176.42 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `10`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0843 | 0.0843 | 0.0800 | memory/search opaque | 0.02 | 176.44 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `48`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0844 | 0.0844 | 0.0800 | memory/search opaque | 0.00 | 189.70 |

- `memory-async` `query_shape`: `$vectorSearch dotProduct topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `dotProduct`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0833 | 0.0833 | 0.0800 | memory/search opaque | 0.00 | 199.14 |

- `memory-async` `query_shape`: `$vectorSearch euclidean topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `euclidean`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0851 | 0.0851 | 0.0800 | memory/search opaque | 0.00 | 199.14 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `334`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0919 | 0.0919 | 0.0900 | memory/search opaque | 0.00 | 199.14 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `454`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0946 | 0.0946 | 0.0900 | memory/search opaque | 0.00 | 199.14 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `10`
- `memory-async` `candidates_evaluated`: `61`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0882 | 0.0882 | 0.0900 | memory/search opaque | 0.00 | 199.14 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `666`
