# Benchmark Report

## Environment

- Generated at: 2026-11-02T23:16:58.219473+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 1
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: stdlib
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:df42746bcc2361660d2498b901fd308006d07ab0a40254147146e1b1533ca552`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.5106 | 0.5106 | 0.3200 | sqlite/sql opaque | 0.03 | 92.14 |

- `sqlite-sync` `query_shape`: `username equality`
- `sqlite-sync` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.1002 | 0.1002 | 0.0600 | sqlite/sql opaque | -1.00 | 133.75 |

- `sqlite-sync` `query_shape`: `city equality`
- `sqlite-sync` `consumption_mode`: `first`
- `sqlite-sync` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.7725 | 0.7725 | 0.6900 | sqlite/sql opaque | 1.36 | 134.11 |

- `sqlite-sync` `query_shape`: `city equality`
- `sqlite-sync` `consumption_mode`: `materialized`
- `sqlite-sync` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.0030 | 0.0030 | 0.0000 | sqlite/sql scan>filter>sort>slice>project | 0.00 | 135.33 |

- `sqlite-sync` `pipeline_shape`: `match-sort-limit-project`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.3139 | 0.3139 | 0.2600 | sqlite/sql scan>filter>sort>slice | 0.41 | 132.17 |

- `sqlite-sync` `query_shape`: `sort score desc + limit 10`
- `sqlite-sync` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.3699 | 0.3699 | 0.3100 | sqlite/sql scan>filter>sort>slice | 0.34 | 133.44 |

- `sqlite-sync` `query_shape`: `sort score desc + limit 10`
- `sqlite-sync` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.9957 | 0.9957 | 0.9700 | sqlite/search opaque | 0.00 | 137.39 |

- `sqlite-sync` `query_shape`: `$search.text title/body ada`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.9952 | 0.9952 | 0.9800 | sqlite/search opaque | 0.00 | 137.39 |

- `sqlite-sync` `query_shape`: `$search.autocomplete title/body alg`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.9781 | 0.9781 | 0.9600 | sqlite/search opaque | 0.00 | 137.39 |

- `sqlite-sync` `query_shape`: `$search.wildcard body *vector*`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 3.7578 | 3.7578 | 3.7300 | sqlite/search opaque | 0.03 | 137.62 |

- `sqlite-sync` `query_shape`: `$search.regex title Ada.*algorithms`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 1.2415 | 1.2415 | 1.2200 | sqlite/search opaque | 0.03 | 137.67 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 1.2182 | 1.2182 | 1.1900 | sqlite/search opaque | 0.00 | 137.67 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 4.9172 | 4.9172 | 4.8800 | sqlite/search opaque | 0.03 | 137.92 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 3.6927 | 3.6927 | 3.6700 | sqlite/search opaque | 0.00 | 137.92 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `2`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 1.6341 | 1.6341 | 1.6100 | sqlite/search opaque | 0.00 | 137.92 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `2`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 2.5502 | 2.5502 | 2.5200 | sqlite/search opaque | 0.00 | 137.92 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 1.1654 | 1.1654 | 1.1400 | sqlite/search opaque | 0.00 | 137.92 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.1604 | 0.1604 | 0.1400 | sqlite/search opaque | 0.00 | 140.30 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `24`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.1365 | 0.1365 | 0.1100 | sqlite/search opaque | 0.00 | 140.44 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `10`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.2093 | 0.2093 | 0.1900 | sqlite/search opaque | 0.00 | 140.44 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `48`
- `sqlite-sync` `candidates_evaluated`: `48`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.1609 | 0.1609 | 0.1400 | sqlite/search opaque | 0.00 | 140.66 |

- `sqlite-sync` `query_shape`: `$vectorSearch dotProduct topk`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `dotProduct`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `24`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.1630 | 0.1630 | 0.1400 | sqlite/search opaque | 0.00 | 141.27 |

- `sqlite-sync` `query_shape`: `$vectorSearch euclidean topk`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `euclidean`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `24`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.1526 | 0.1526 | 0.1300 | sqlite/search opaque | 0.00 | 141.27 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `candidates_requested`: `32`
- `sqlite-sync` `candidates_evaluated`: `11`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.1648 | 0.1648 | 0.1400 | sqlite/search opaque | 0.00 | 141.27 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `12`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.2396 | 0.2396 | 0.2200 | sqlite/search opaque | 0.00 | 141.27 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `exact_fallback_reason`: `candidate-prefilter-underflow`
- `sqlite-sync` `candidates_requested`: `10`
- `sqlite-sync` `candidates_evaluated`: `0`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 1 | 0.1611 | 0.1611 | 0.1500 | sqlite/search opaque | 0.00 | 141.27 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `16`
