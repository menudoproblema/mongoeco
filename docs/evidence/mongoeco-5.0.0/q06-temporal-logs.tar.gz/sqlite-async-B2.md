# Benchmark Report

## Environment

- Generated at: 2026-11-02T23:20:42.462854+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 1
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: stdlib
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:df42746bcc2361660d2498b901fd308006d07ab0a40254147146e1b1533ca552`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.4548 | 0.4548 | 0.2900 | sqlite/sql opaque | 0.05 | 91.91 |

- `sqlite-async` `query_shape`: `username equality`
- `sqlite-async` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1019 | 0.1019 | 0.0600 | sqlite/sql opaque | 0.02 | 103.28 |

- `sqlite-async` `query_shape`: `city equality`
- `sqlite-async` `consumption_mode`: `first`
- `sqlite-async` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.6261 | 0.6261 | 0.5400 | sqlite/sql opaque | 32.31 | 135.59 |

- `sqlite-async` `query_shape`: `city equality`
- `sqlite-async` `consumption_mode`: `materialized`
- `sqlite-async` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.0030 | 0.0030 | 0.0100 | sqlite/sql scan>filter>sort>slice>project | 0.16 | 110.56 |

- `sqlite-async` `pipeline_shape`: `match-sort-limit-project`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.2896 | 0.2896 | 0.2400 | sqlite/sql scan>filter>sort>slice | 0.80 | 115.84 |

- `sqlite-async` `query_shape`: `sort score desc + limit 10`
- `sqlite-async` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.3551 | 0.3551 | 0.2900 | sqlite/sql scan>filter>sort>slice | 0.44 | 117.16 |

- `sqlite-async` `query_shape`: `sort score desc + limit 10`
- `sqlite-async` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.5742 | 0.5742 | 0.5600 | sqlite/search opaque | 0.03 | 125.92 |

- `sqlite-async` `query_shape`: `$search.text title/body ada`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.5747 | 0.5747 | 0.5700 | sqlite/search opaque | 0.00 | 126.33 |

- `sqlite-async` `query_shape`: `$search.autocomplete title/body alg`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.5740 | 0.5740 | 0.5600 | sqlite/search opaque | 0.67 | 127.06 |

- `sqlite-async` `query_shape`: `$search.wildcard body *vector*`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 3.7480 | 3.7480 | 3.7300 | sqlite/search opaque | 1.33 | 128.41 |

- `sqlite-async` `query_shape`: `$search.regex title Ada.*algorithms`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.8161 | 0.8161 | 0.8100 | sqlite/search opaque | 0.02 | 128.45 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.7996 | 0.7996 | 0.7900 | sqlite/search opaque | 0.00 | 128.45 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 3.1949 | 3.1949 | 3.1700 | sqlite/search opaque | 2.19 | 132.06 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 2.3729 | 2.3729 | 2.3500 | sqlite/search opaque | 0.05 | 132.16 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `2`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 1.1295 | 1.1295 | 1.1200 | sqlite/search opaque | 0.00 | 132.39 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `2`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 1.7218 | 1.7218 | 1.7100 | sqlite/search opaque | 0.02 | 132.42 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.7391 | 0.7391 | 0.7300 | sqlite/search opaque | 0.00 | 132.42 |

- `sqlite-async` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1382 | 0.1382 | 0.1300 | sqlite/search opaque | 0.00 | 142.50 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `24`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1125 | 0.1125 | 0.1000 | sqlite/search opaque | 0.00 | 142.53 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `10`
- `sqlite-async` `candidates_evaluated`: `10`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1793 | 0.1793 | 0.1700 | sqlite/search opaque | 0.00 | 142.64 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `48`
- `sqlite-async` `candidates_evaluated`: `48`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1360 | 0.1360 | 0.1200 | sqlite/search opaque | 0.00 | 142.80 |

- `sqlite-async` `query_shape`: `$vectorSearch dotProduct topk`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `dotProduct`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `24`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1364 | 0.1364 | 0.1300 | sqlite/search opaque | 0.06 | 143.72 |

- `sqlite-async` `query_shape`: `$vectorSearch euclidean topk`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `euclidean`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `24`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1268 | 0.1268 | 0.1200 | sqlite/search opaque | 0.12 | 143.84 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `candidates_requested`: `32`
- `sqlite-async` `candidates_evaluated`: `11`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1362 | 0.1362 | 0.1300 | sqlite/search opaque | 0.05 | 143.91 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `12`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.2159 | 0.2159 | 0.2100 | sqlite/search opaque | 0.06 | 143.97 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `exact_fallback_reason`: `candidate-prefilter-underflow`
- `sqlite-async` `candidates_requested`: `10`
- `sqlite-async` `candidates_evaluated`: `0`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1354 | 0.1354 | 0.1300 | sqlite/search opaque | 0.00 | 144.22 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `16`
