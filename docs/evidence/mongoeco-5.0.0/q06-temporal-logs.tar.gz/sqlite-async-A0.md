# Benchmark Report

## Environment

- Generated at: 2026-11-02T23:18:01.344964+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 1
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: stdlib
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:df42746bcc2361660d2498b901fd308006d07ab0a40254147146e1b1533ca552`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.5174 | 0.5174 | 0.3300 | sqlite/sql opaque | 0.34 | 92.91 |

- `sqlite-async` `query_shape`: `username equality`
- `sqlite-async` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.0980 | 0.0980 | 0.0600 | sqlite/sql opaque | 0.00 | 103.47 |

- `sqlite-async` `query_shape`: `city equality`
- `sqlite-async` `consumption_mode`: `first`
- `sqlite-async` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.7618 | 0.7618 | 0.6800 | sqlite/sql opaque | 31.78 | 135.25 |

- `sqlite-async` `query_shape`: `city equality`
- `sqlite-async` `consumption_mode`: `materialized`
- `sqlite-async` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.0029 | 0.0029 | 0.0000 | sqlite/sql scan>filter>sort>slice>project | 0.00 | 112.75 |

- `sqlite-async` `pipeline_shape`: `match-sort-limit-project`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.3031 | 0.3031 | 0.2500 | sqlite/sql scan>filter>sort>slice | 0.14 | 116.70 |

- `sqlite-async` `query_shape`: `sort score desc + limit 10`
- `sqlite-async` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.3736 | 0.3736 | 0.3100 | sqlite/sql scan>filter>sort>slice | 0.97 | 119.95 |

- `sqlite-async` `query_shape`: `sort score desc + limit 10`
- `sqlite-async` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.9860 | 0.9860 | 0.9800 | sqlite/search opaque | 0.03 | 127.70 |

- `sqlite-async` `query_shape`: `$search.text title/body ada`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.9829 | 0.9829 | 0.9700 | sqlite/search opaque | 0.00 | 128.03 |

- `sqlite-async` `query_shape`: `$search.autocomplete title/body alg`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.9601 | 0.9601 | 0.9400 | sqlite/search opaque | 0.02 | 128.25 |

- `sqlite-async` `query_shape`: `$search.wildcard body *vector*`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 3.7606 | 3.7606 | 3.7400 | sqlite/search opaque | 0.00 | 128.25 |

- `sqlite-async` `query_shape`: `$search.regex title Ada.*algorithms`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 1.2524 | 1.2524 | 1.2400 | sqlite/search opaque | 0.03 | 128.30 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 1.2049 | 1.2049 | 1.1900 | sqlite/search opaque | 0.00 | 128.70 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 4.8894 | 4.8894 | 4.8700 | sqlite/search opaque | 0.03 | 128.84 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 3.6434 | 3.6434 | 3.6300 | sqlite/search opaque | 0.02 | 129.12 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `2`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 1.5932 | 1.5932 | 1.5800 | sqlite/search opaque | 0.00 | 129.14 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `2`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 2.5480 | 2.5480 | 2.5400 | sqlite/search opaque | 0.02 | 129.17 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 1.1476 | 1.1476 | 1.1400 | sqlite/search opaque | 0.00 | 129.20 |

- `sqlite-async` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1438 | 0.1438 | 0.1300 | sqlite/search opaque | 0.00 | 135.30 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `24`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1188 | 0.1188 | 0.1100 | sqlite/search opaque | 0.00 | 135.30 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `10`
- `sqlite-async` `candidates_evaluated`: `10`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1843 | 0.1843 | 0.1800 | sqlite/search opaque | 0.00 | 135.34 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `48`
- `sqlite-async` `candidates_evaluated`: `48`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1433 | 0.1433 | 0.1300 | sqlite/search opaque | 0.00 | 135.88 |

- `sqlite-async` `query_shape`: `$vectorSearch dotProduct topk`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `dotProduct`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `24`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1425 | 0.1425 | 0.1400 | sqlite/search opaque | 0.00 | 136.39 |

- `sqlite-async` `query_shape`: `$vectorSearch euclidean topk`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `euclidean`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `24`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1342 | 0.1342 | 0.1300 | sqlite/search opaque | 0.03 | 136.44 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `candidates_requested`: `32`
- `sqlite-async` `candidates_evaluated`: `11`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1443 | 0.1443 | 0.1400 | sqlite/search opaque | 0.09 | 136.53 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `12`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.2242 | 0.2242 | 0.2200 | sqlite/search opaque | 0.03 | 137.20 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `exact_fallback_reason`: `candidate-prefilter-underflow`
- `sqlite-async` `candidates_requested`: `10`
- `sqlite-async` `candidates_evaluated`: `0`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1447 | 0.1447 | 0.1400 | sqlite/search opaque | 0.00 | 137.20 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `16`
