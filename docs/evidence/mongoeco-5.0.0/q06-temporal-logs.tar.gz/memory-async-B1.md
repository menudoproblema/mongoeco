# Benchmark Report

## Environment

- Generated at: 2026-11-02T23:11:11.937425+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 1
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: stdlib
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:df42746bcc2361660d2498b901fd308006d07ab0a40254147146e1b1533ca552`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.1817 | 0.1817 | 0.1600 | memory/python scan>filter>slice | 0.00 | 84.80 |

- `memory-async` `query_shape`: `username equality`
- `memory-async` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0353 | 0.0353 | 0.0300 | memory/python scan>filter | 0.00 | 95.69 |

- `memory-async` `query_shape`: `city equality`
- `memory-async` `consumption_mode`: `first`
- `memory-async` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.4780 | 0.4780 | 0.4700 | memory/python scan>filter | 3.80 | 99.48 |

- `memory-async` `query_shape`: `city equality`
- `memory-async` `consumption_mode`: `materialized`
- `memory-async` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0052 | 0.0052 | 0.0000 | memory/python scan>filter>sort>project>slice | 0.00 | 102.50 |

- `memory-async` `pipeline_shape`: `match-sort-limit-project`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2368 | 0.2368 | 0.2300 | memory/python scan>filter>sort>slice | 0.00 | 106.56 |

- `memory-async` `query_shape`: `sort score desc + limit 10`
- `memory-async` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2363 | 0.2363 | 0.2300 | memory/python scan>filter>sort>slice | 0.00 | 107.48 |

- `memory-async` `query_shape`: `sort score desc + limit 10`
- `memory-async` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.3825 | 0.3825 | 0.3800 | memory/search opaque | 0.00 | 113.84 |

- `memory-async` `query_shape`: `$search.text title/body ada`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.3438 | 0.3438 | 0.3400 | memory/search opaque | 0.00 | 114.05 |

- `memory-async` `query_shape`: `$search.autocomplete title/body alg`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2189 | 0.2189 | 0.2200 | memory/search opaque | 0.00 | 114.25 |

- `memory-async` `query_shape`: `$search.wildcard body *vector*`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2005 | 0.2005 | 0.2000 | memory/search opaque | 0.00 | 114.25 |

- `memory-async` `query_shape`: `$search.regex title Ada.*algorithms`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.4397 | 0.4397 | 0.4300 | memory/search opaque | 0.00 | 114.25 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.4356 | 0.4356 | 0.4300 | memory/search opaque | 0.00 | 114.25 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 1.2849 | 1.2849 | 1.2800 | memory/search opaque | 0.00 | 114.27 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 1.0162 | 1.0162 | 1.0100 | memory/search opaque | 0.00 | 114.27 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `2`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.5146 | 0.5146 | 0.5100 | memory/search opaque | 0.00 | 114.27 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `2`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 1.0203 | 1.0203 | 1.0200 | memory/search opaque | 0.00 | 114.28 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.3800 | 0.3800 | 0.3800 | memory/search opaque | 0.00 | 114.28 |

- `memory-async` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0810 | 0.0810 | 0.0800 | memory/search opaque | 0.14 | 167.36 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0793 | 0.0793 | 0.0700 | memory/search opaque | 0.00 | 167.38 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `10`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0784 | 0.0784 | 0.0700 | memory/search opaque | 0.00 | 167.38 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `48`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0791 | 0.0791 | 0.0800 | memory/search opaque | 0.00 | 179.52 |

- `memory-async` `query_shape`: `$vectorSearch dotProduct topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `dotProduct`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0777 | 0.0777 | 0.0700 | memory/search opaque | 0.00 | 179.52 |

- `memory-async` `query_shape`: `$vectorSearch euclidean topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `euclidean`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0808 | 0.0808 | 0.0800 | memory/search opaque | 0.00 | 179.52 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `334`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0859 | 0.0859 | 0.0800 | memory/search opaque | 0.00 | 179.52 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `454`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0849 | 0.0849 | 0.0900 | memory/search opaque | 0.00 | 179.52 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `10`
- `memory-async` `candidates_evaluated`: `61`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0824 | 0.0824 | 0.0800 | memory/search opaque | 0.00 | 179.52 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `666`
