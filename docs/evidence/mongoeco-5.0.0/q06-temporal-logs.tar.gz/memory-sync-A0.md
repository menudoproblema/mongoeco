# Benchmark Report

## Environment

- Generated at: 2026-11-02T23:08:07.437023+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 1
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: stdlib
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:df42746bcc2361660d2498b901fd308006d07ab0a40254147146e1b1533ca552`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2386 | 0.2386 | 0.1900 | memory/python scan>filter>slice | 0.00 | 93.95 |

- `memory-sync` `query_shape`: `username equality`
- `memory-sync` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.0384 | 0.0384 | 0.0400 | memory/python scan>filter | 0.00 | 109.80 |

- `memory-sync` `query_shape`: `city equality`
- `memory-sync` `consumption_mode`: `first`
- `memory-sync` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.6283 | 0.6283 | 0.6100 | memory/python scan>filter | 0.17 | 109.97 |

- `memory-sync` `query_shape`: `city equality`
- `memory-sync` `consumption_mode`: `materialized`
- `memory-sync` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.0036 | 0.0036 | 0.0000 | memory/python scan>filter>sort>project>slice | 0.00 | 111.77 |

- `memory-sync` `pipeline_shape`: `match-sort-limit-project`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2503 | 0.2503 | 0.2300 | memory/python scan>filter>sort>slice | 0.00 | 113.97 |

- `memory-sync` `query_shape`: `sort score desc + limit 10`
- `memory-sync` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2466 | 0.2466 | 0.2300 | memory/python scan>filter>sort>slice | 0.00 | 114.19 |

- `memory-sync` `query_shape`: `sort score desc + limit 10`
- `memory-sync` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.4413 | 0.4413 | 0.4300 | memory/search opaque | 0.00 | 116.45 |

- `memory-sync` `query_shape`: `$search.text title/body ada`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.4091 | 0.4091 | 0.3900 | memory/search opaque | 0.00 | 116.47 |

- `memory-sync` `query_shape`: `$search.autocomplete title/body alg`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2624 | 0.2624 | 0.2500 | memory/search opaque | 0.00 | 116.47 |

- `memory-sync` `query_shape`: `$search.wildcard body *vector*`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.2285 | 0.2285 | 0.2100 | memory/search opaque | 0.00 | 116.47 |

- `memory-sync` `query_shape`: `$search.regex title Ada.*algorithms`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.4608 | 0.4608 | 0.4500 | memory/search opaque | 0.00 | 116.47 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.4531 | 0.4531 | 0.4400 | memory/search opaque | 0.00 | 116.48 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 1.3059 | 1.3059 | 1.2900 | memory/search opaque | 0.00 | 116.48 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 1.2253 | 1.2253 | 1.2100 | memory/search opaque | 0.00 | 116.48 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `2`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.7141 | 0.7141 | 0.6900 | memory/search opaque | 0.00 | 116.55 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `2`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 1.1593 | 1.1593 | 1.1400 | memory/search opaque | 0.00 | 116.55 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.3899 | 0.3899 | 0.3800 | memory/search opaque | 0.00 | 116.55 |

- `memory-sync` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.0994 | 0.0994 | 0.0800 | memory/search opaque | 0.00 | 164.67 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1024 | 0.1024 | 0.0800 | memory/search opaque | 0.00 | 164.67 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `10`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.0988 | 0.0988 | 0.0800 | memory/search opaque | 0.00 | 164.88 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `48`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1080 | 0.1080 | 0.0900 | memory/search opaque | 0.00 | 168.89 |

- `memory-sync` `query_shape`: `$vectorSearch dotProduct topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `dotProduct`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1080 | 0.1080 | 0.1000 | memory/search opaque | 0.02 | 173.77 |

- `memory-sync` `query_shape`: `$vectorSearch euclidean topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `euclidean`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1095 | 0.1095 | 0.0900 | memory/search opaque | 0.00 | 173.77 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `334`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1067 | 0.1067 | 0.0900 | memory/search opaque | 0.00 | 174.06 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `454`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1100 | 0.1100 | 0.1000 | memory/search opaque | 0.00 | 174.06 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `10`
- `memory-sync` `candidates_evaluated`: `61`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 1 | 0.1089 | 0.1089 | 0.0900 | memory/search opaque | 0.00 | 174.06 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `666`
