# Benchmark Report

## Environment

- Generated at: 2026-11-02T23:19:53.796209+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 1
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: stdlib
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:df42746bcc2361660d2498b901fd308006d07ab0a40254147146e1b1533ca552`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.4493 | 0.4493 | 0.2700 | sqlite/sql opaque | 1.09 | 89.83 |

- `sqlite-async` `query_shape`: `username equality`
- `sqlite-async` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.0961 | 0.0961 | 0.0500 | sqlite/sql opaque | 0.02 | 102.42 |

- `sqlite-async` `query_shape`: `city equality`
- `sqlite-async` `consumption_mode`: `first`
- `sqlite-async` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.6267 | 0.6267 | 0.5400 | sqlite/sql opaque | 32.38 | 134.80 |

- `sqlite-async` `query_shape`: `city equality`
- `sqlite-async` `consumption_mode`: `materialized`
- `sqlite-async` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.0030 | 0.0030 | 0.0000 | sqlite/sql scan>filter>sort>slice>project | 0.00 | 110.22 |

- `sqlite-async` `pipeline_shape`: `match-sort-limit-project`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.2929 | 0.2929 | 0.2400 | sqlite/sql scan>filter>sort>slice | 0.30 | 114.83 |

- `sqlite-async` `query_shape`: `sort score desc + limit 10`
- `sqlite-async` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.3557 | 0.3557 | 0.2900 | sqlite/sql scan>filter>sort>slice | 1.39 | 117.70 |

- `sqlite-async` `query_shape`: `sort score desc + limit 10`
- `sqlite-async` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.5823 | 0.5823 | 0.5700 | sqlite/search opaque | 0.06 | 126.70 |

- `sqlite-async` `query_shape`: `$search.text title/body ada`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.5777 | 0.5777 | 0.5600 | sqlite/search opaque | 0.00 | 126.70 |

- `sqlite-async` `query_shape`: `$search.autocomplete title/body alg`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.5735 | 0.5735 | 0.5600 | sqlite/search opaque | 0.67 | 127.38 |

- `sqlite-async` `query_shape`: `$search.wildcard body *vector*`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 3.7722 | 3.7722 | 3.7400 | sqlite/search opaque | 1.33 | 128.70 |

- `sqlite-async` `query_shape`: `$search.regex title Ada.*algorithms`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.8294 | 0.8294 | 0.8100 | sqlite/search opaque | 0.06 | 128.77 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.9198 | 0.9198 | 0.9000 | sqlite/search opaque | 0.02 | 128.95 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 3.2262 | 3.2262 | 3.1800 | sqlite/search opaque | 2.12 | 132.72 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 2.4770 | 2.4770 | 2.4400 | sqlite/search opaque | 0.05 | 132.78 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `2`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 1.1781 | 1.1781 | 1.1600 | sqlite/search opaque | 0.09 | 132.92 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `2`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 1.8053 | 1.8053 | 1.7800 | sqlite/search opaque | 0.05 | 132.97 |

- `sqlite-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.8058 | 0.8058 | 0.7900 | sqlite/search opaque | 0.00 | 132.97 |

- `sqlite-async` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `1`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1437 | 0.1437 | 0.1300 | sqlite/search opaque | 0.00 | 142.94 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `24`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1225 | 0.1225 | 0.1100 | sqlite/search opaque | 0.02 | 142.97 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `10`
- `sqlite-async` `candidates_evaluated`: `10`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1883 | 0.1883 | 0.1800 | sqlite/search opaque | 0.00 | 142.97 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `48`
- `sqlite-async` `candidates_evaluated`: `48`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1439 | 0.1439 | 0.1400 | sqlite/search opaque | 0.00 | 143.12 |

- `sqlite-async` `query_shape`: `$vectorSearch dotProduct topk`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `dotProduct`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `24`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1535 | 0.1535 | 0.1400 | sqlite/search opaque | 0.08 | 144.05 |

- `sqlite-async` `query_shape`: `$vectorSearch euclidean topk`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `euclidean`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `24`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1309 | 0.1309 | 0.1200 | sqlite/search opaque | 0.00 | 144.25 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `candidates_requested`: `32`
- `sqlite-async` `candidates_evaluated`: `11`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1407 | 0.1407 | 0.1300 | sqlite/search opaque | 0.03 | 144.28 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `12`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.2234 | 0.2234 | 0.2200 | sqlite/search opaque | 0.00 | 144.31 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `exact_fallback_reason`: `candidate-prefilter-underflow`
- `sqlite-async` `candidates_requested`: `10`
- `sqlite-async` `candidates_evaluated`: `0`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-async | 1 | 0.1407 | 0.1407 | 0.1300 | sqlite/search opaque | 0.03 | 144.38 |

- `sqlite-async` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `sqlite-async` `streaming_batch_execution`: `False`
- `sqlite-async` `remaining_stage_count`: `0`
- `sqlite-async` `planning_mode`: `strict`
- `sqlite-async` `query_operator`: `vectorSearch`
- `sqlite-async` `similarity`: `cosine`
- `sqlite-async` `mode`: `ann`
- `sqlite-async` `filter_mode`: `candidate-prefilter`
- `sqlite-async` `candidates_requested`: `24`
- `sqlite-async` `candidates_evaluated`: `16`
