# Benchmark Report

## Environment

- Generated at: 2026-11-02T23:11:37.223550+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 1
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: stdlib
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:df42746bcc2361660d2498b901fd308006d07ab0a40254147146e1b1533ca552`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.13.0`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.1839 | 0.1839 | 0.1600 | memory/python scan>filter>slice | 0.03 | 84.95 |

- `memory-async` `query_shape`: `username equality`
- `memory-async` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0357 | 0.0357 | 0.0300 | memory/python scan>filter | 0.00 | 95.56 |

- `memory-async` `query_shape`: `city equality`
- `memory-async` `consumption_mode`: `first`
- `memory-async` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.4917 | 0.4917 | 0.4900 | memory/python scan>filter | 3.89 | 99.45 |

- `memory-async` `query_shape`: `city equality`
- `memory-async` `consumption_mode`: `materialized`
- `memory-async` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0054 | 0.0054 | 0.0100 | memory/python scan>filter>sort>project>slice | 0.02 | 100.92 |

- `memory-async` `pipeline_shape`: `match-sort-limit-project`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2298 | 0.2298 | 0.2200 | memory/python scan>filter>sort>slice | 0.02 | 105.95 |

- `memory-async` `query_shape`: `sort score desc + limit 10`
- `memory-async` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2290 | 0.2290 | 0.2200 | memory/python scan>filter>sort>slice | 0.00 | 107.08 |

- `memory-async` `query_shape`: `sort score desc + limit 10`
- `memory-async` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.3881 | 0.3881 | 0.3900 | memory/search opaque | 0.00 | 113.36 |

- `memory-async` `query_shape`: `$search.text title/body ada`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.3436 | 0.3436 | 0.3400 | memory/search opaque | 0.00 | 113.36 |

- `memory-async` `query_shape`: `$search.autocomplete title/body alg`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2220 | 0.2220 | 0.2200 | memory/search opaque | 0.00 | 113.36 |

- `memory-async` `query_shape`: `$search.wildcard body *vector*`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.2036 | 0.2036 | 0.2000 | memory/search opaque | 0.00 | 113.42 |

- `memory-async` `query_shape`: `$search.regex title Ada.*algorithms`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.4590 | 0.4590 | 0.4600 | memory/search opaque | 0.00 | 113.42 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.4552 | 0.4552 | 0.4500 | memory/search opaque | 0.00 | 113.44 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 1.2938 | 1.2938 | 1.2900 | memory/search opaque | 0.00 | 113.66 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 1.0188 | 1.0188 | 1.0200 | memory/search opaque | 0.00 | 113.66 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `2`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.5120 | 0.5120 | 0.5100 | memory/search opaque | 0.00 | 113.66 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `2`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 1.0821 | 1.0821 | 1.0700 | memory/search opaque | 0.12 | 113.83 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.4144 | 0.4144 | 0.4000 | memory/search opaque | 0.00 | 113.83 |

- `memory-async` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0805 | 0.0805 | 0.0800 | memory/search opaque | 0.14 | 165.08 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0784 | 0.0784 | 0.0700 | memory/search opaque | 0.00 | 165.09 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `10`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0776 | 0.0776 | 0.0700 | memory/search opaque | 0.00 | 165.14 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `48`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0801 | 0.0801 | 0.0700 | memory/search opaque | 0.00 | 179.84 |

- `memory-async` `query_shape`: `$vectorSearch dotProduct topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `dotProduct`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0794 | 0.0794 | 0.0800 | memory/search opaque | 0.00 | 189.41 |

- `memory-async` `query_shape`: `$vectorSearch euclidean topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `euclidean`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0800 | 0.0800 | 0.0800 | memory/search opaque | 0.00 | 189.41 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `334`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0843 | 0.0843 | 0.0900 | memory/search opaque | 0.00 | 189.41 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `454`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0840 | 0.0840 | 0.0800 | memory/search opaque | 0.00 | 189.41 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `10`
- `memory-async` `candidates_evaluated`: `61`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 1 | 0.0824 | 0.0824 | 0.0800 | memory/search opaque | 0.00 | 189.42 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `666`
