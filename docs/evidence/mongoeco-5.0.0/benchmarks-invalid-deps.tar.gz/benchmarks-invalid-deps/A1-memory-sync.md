# Benchmark Report

## Environment

- Generated at: 2026-11-02T19:23:03.572306+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 5
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: unset
- Git revision: `bb0597c1b42d4228b547a8eec87ce704489bcb7b`
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:4a6949d179df72d2c7de595975c08afc7819619cb1bbaa37e3c286ab29df827f`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.11.9`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1528 | 0.1532 | 0.1260 | memory/python scan>filter>slice | 0.05 | 100.42 |

- `memory-sync` `query_shape`: `username equality`
- `memory-sync` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0294 | 0.0284 | 0.0240 | memory/python scan>filter | 0.01 | 113.42 |

- `memory-sync` `query_shape`: `city equality`
- `memory-sync` `consumption_mode`: `first`
- `memory-sync` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.2819 | 0.2790 | 0.2540 | memory/python scan>filter | 0.11 | 113.42 |

- `memory-sync` `query_shape`: `city equality`
- `memory-sync` `consumption_mode`: `materialized`
- `memory-sync` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0034 | 0.0033 | 0.0040 | memory/python scan>filter>sort>project>slice | 0.00 | 114.34 |

- `memory-sync` `pipeline_shape`: `match-sort-limit-project`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.2139 | 0.2122 | 0.1920 | memory/python scan>filter>sort>slice | 0.00 | 115.75 |

- `memory-sync` `query_shape`: `sort score desc + limit 10`
- `memory-sync` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.2156 | 0.2141 | 0.1940 | memory/python scan>filter>sort>slice | 0.01 | 115.75 |

- `memory-sync` `query_shape`: `sort score desc + limit 10`
- `memory-sync` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.3802 | 0.3752 | 0.3760 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.text title/body ada`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.3380 | 0.3364 | 0.3320 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.autocomplete title/body alg`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.2175 | 0.2146 | 0.2120 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.wildcard body *vector*`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.1935 | 0.1937 | 0.1900 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.regex title Ada.*algorithms`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.4334 | 0.4355 | 0.4320 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.4215 | 0.4203 | 0.4180 | memory/search opaque | 0.01 | 117.58 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 1.2784 | 1.2697 | 1.2740 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.9961 | 0.9960 | 0.9940 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `2`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.4916 | 0.4927 | 0.4880 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `2`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 1.0022 | 0.9974 | 0.9960 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.3589 | 0.3586 | 0.3560 | memory/search opaque | 0.00 | 117.58 |

- `memory-sync` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `1`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0694 | 0.0694 | 0.0680 | memory/search opaque | 0.00 | 237.09 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0685 | 0.0686 | 0.0660 | memory/search opaque | 0.00 | 237.09 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `10`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0682 | 0.0681 | 0.0660 | memory/search opaque | 0.00 | 237.09 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `48`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0688 | 0.0685 | 0.0640 | memory/search opaque | 0.00 | 237.09 |

- `memory-sync` `query_shape`: `$vectorSearch dotProduct topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `dotProduct`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0688 | 0.0685 | 0.0680 | memory/search opaque | 0.05 | 236.50 |

- `memory-sync` `query_shape`: `$vectorSearch euclidean topk`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `euclidean`
- `memory-sync` `mode`: `exact`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `1000`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0686 | 0.0687 | 0.0660 | memory/search opaque | 0.01 | 236.50 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `334`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0723 | 0.0722 | 0.0700 | memory/search opaque | 0.02 | 236.50 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `454`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0718 | 0.0716 | 0.0700 | memory/search opaque | 0.01 | 236.50 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `10`
- `memory-sync` `candidates_evaluated`: `61`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-sync | 5 | 0.0704 | 0.0703 | 0.0680 | memory/search opaque | 0.03 | 236.52 |

- `memory-sync` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `memory-sync` `streaming_batch_execution`: `False`
- `memory-sync` `remaining_stage_count`: `0`
- `memory-sync` `planning_mode`: `strict`
- `memory-sync` `query_operator`: `vectorSearch`
- `memory-sync` `similarity`: `cosine`
- `memory-sync` `mode`: `exact`
- `memory-sync` `filter_mode`: `candidate-prefilter`
- `memory-sync` `candidates_requested`: `24`
- `memory-sync` `candidates_evaluated`: `666`
