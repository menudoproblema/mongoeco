# Benchmark Report

## Environment

- Generated at: 2026-11-02T19:41:07.140421+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 5
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: unset
- Git revision: `bb0597c1b42d4228b547a8eec87ce704489bcb7b`
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:4a6949d179df72d2c7de595975c08afc7819619cb1bbaa37e3c286ab29df827f`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.11.9`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.3570 | -3.6% | 0.2240 | sqlite/sql opaque | 0.19 | 93.91 |

- `sqlite-sync` `query_shape`: `username equality`
- `sqlite-sync` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.0706 | -1.3% | 0.0420 | sqlite/sql opaque | 0.00 | 137.69 |

- `sqlite-sync` `query_shape`: `city equality`
- `sqlite-sync` `consumption_mode`: `first`
- `sqlite-sync` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.4634 | +0.5% | 0.3760 | sqlite/sql opaque | 0.21 | 137.69 |

- `sqlite-sync` `query_shape`: `city equality`
- `sqlite-sync` `consumption_mode`: `materialized`
- `sqlite-sync` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.0029 | +0.0% | 0.0060 | sqlite/sql scan>filter>sort>slice>project | 0.02 | 139.88 |

- `sqlite-sync` `pipeline_shape`: `match-sort-limit-project`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.3528 | -0.4% | 0.2940 | sqlite/sql scan>filter>sort>slice | 0.16 | 141.23 |

- `sqlite-sync` `query_shape`: `sort score desc + limit 10`
- `sqlite-sync` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.3162 | -0.2% | 0.2620 | sqlite/sql scan>filter>sort>slice | 0.02 | 141.36 |

- `sqlite-sync` `query_shape`: `sort score desc + limit 10`
- `sqlite-sync` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.9511 | +0.1% | 0.9440 | sqlite/search opaque | 0.00 | 144.55 |

- `sqlite-sync` `query_shape`: `$search.text title/body ada`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.9493 | -1.0% | 0.9420 | sqlite/search opaque | 0.00 | 144.55 |

- `sqlite-sync` `query_shape`: `$search.autocomplete title/body alg`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.9436 | -2.7% | 0.9320 | sqlite/search opaque | 0.00 | 144.55 |

- `sqlite-sync` `query_shape`: `$search.wildcard body *vector*`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 3.7304 | -0.3% | 3.7080 | sqlite/search opaque | 0.01 | 144.55 |

- `sqlite-sync` `query_shape`: `$search.regex title Ada.*algorithms`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 1.2362 | -0.7% | 1.2260 | sqlite/search opaque | 0.04 | 144.55 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 1.2638 | -1.0% | 1.2560 | sqlite/search opaque | 0.01 | 144.61 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.4371 | -0.2% | 0.4280 | sqlite/search opaque | 0.01 | 144.61 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.5353 | +0.9% | 0.5280 | sqlite/search opaque | 0.01 | 144.67 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `2`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.5210 | +0.7% | 0.5120 | sqlite/search opaque | 0.00 | 144.67 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `2`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.4473 | -0.8% | 0.4420 | sqlite/search opaque | 0.03 | 144.67 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.4043 | +0.9% | 0.3940 | sqlite/search opaque | 0.00 | 144.67 |

- `sqlite-sync` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `1`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1146 | +1.1% | 0.1080 | sqlite/search opaque | 0.00 | 148.28 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.0949 | +0.7% | 0.0860 | sqlite/search opaque | 0.00 | 148.34 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `10`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1448 | +0.8% | 0.1360 | sqlite/search opaque | 0.00 | 148.34 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `48`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1152 | +2.2% | 0.1080 | sqlite/search opaque | 0.00 | 148.48 |

- `sqlite-sync` `query_shape`: `$vectorSearch dotProduct topk`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `dotProduct`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1170 | +4.5% | 0.1060 | sqlite/search opaque | 0.00 | 148.62 |

- `sqlite-sync` `query_shape`: `$vectorSearch euclidean topk`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `euclidean`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1079 | +1.8% | 0.1000 | sqlite/search opaque | 0.00 | 148.62 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `candidates_requested`: `32`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1167 | -0.1% | 0.1080 | sqlite/search opaque | 0.00 | 148.62 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1926 | +2.3% | 0.1840 | sqlite/search opaque | 0.00 | 148.62 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `exact_fallback_reason`: `candidate-prefilter-underflow`
- `sqlite-sync` `candidates_requested`: `10`
- `sqlite-sync` `candidates_evaluated`: `0`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall delta vs baseline | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| sqlite-sync | 5 | 0.1154 | +2.9% | 0.1080 | sqlite/search opaque | 0.00 | 148.62 |

- `sqlite-sync` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `sqlite-sync` `streaming_batch_execution`: `False`
- `sqlite-sync` `remaining_stage_count`: `0`
- `sqlite-sync` `planning_mode`: `strict`
- `sqlite-sync` `query_operator`: `vectorSearch`
- `sqlite-sync` `similarity`: `cosine`
- `sqlite-sync` `mode`: `ann`
- `sqlite-sync` `filter_mode`: `candidate-prefilter`
- `sqlite-sync` `candidates_requested`: `24`
- `sqlite-sync` `candidates_evaluated`: `10`
