# Benchmark Report

## Environment

- Generated at: 2026-11-02T19:24:12.057766+00:00
- Python: 3.14.5
- Platform: macOS-15.6-arm64-arm-64bit-Mach-O
- Dataset size: 1000
- Warmup runs: 1
- Measured repetitions: 5
- Workloads: secondary_lookup_indexed, cursor_consumption, simple_aggregation, sort_limit, search_diagnostics, vector_search_diagnostics
- JSON backend: stdlib
- MONGOECO_JSON_BACKEND: unset
- Git revision: `bb0597c1b42d4228b547a8eec87ce704489bcb7b`
- Git worktree dirty: `False`
- Report schema: `mongoeco-benchmark-report/v2`
- Harness SHA-256: `sha256:4a6949d179df72d2c7de595975c08afc7819619cb1bbaa37e3c286ab29df827f`
- Dataset SHA-256: `sha256:c2b95c2ef946b1eee07d3311fedac30f6712de6ff7668d0f095f4ba705f4df63`
- RSS peak sampling interval: `5.0 ms`
- psutil: `7.2.2`
- mongomock: `4.3.0`
- orjson: `3.11.9`

## secondary_lookup_indexed

### secondary_lookup_indexed_1k

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.1249 | 0.1243 | 0.0960 | memory/python scan>filter>slice | 0.02 | 88.58 |

- `memory-async` `query_shape`: `username equality`
- `memory-async` `planning_mode`: `strict`

## cursor_consumption

### cursor_consumption_first_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0239 | 0.0238 | 0.0160 | memory/python scan>filter | 0.01 | 102.58 |

- `memory-async` `query_shape`: `city equality`
- `memory-async` `consumption_mode`: `first`
- `memory-async` `planning_mode`: `strict`

### cursor_consumption_materialized_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.2452 | 0.2423 | 0.2400 | memory/python scan>filter | 2.00 | 103.81 |

- `memory-async` `query_shape`: `city equality`
- `memory-async` `consumption_mode`: `materialized`
- `memory-async` `planning_mode`: `strict`

## simple_aggregation

### simple_aggregation_topk

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0037 | 0.0036 | 0.0020 | memory/python scan>filter>sort>project>slice | 0.00 | 105.77 |

- `memory-async` `pipeline_shape`: `match-sort-limit-project`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`

## sort_limit

### sort_limit_indexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.1863 | 0.1864 | 0.1800 | memory/python scan>filter>sort>slice | 0.00 | 107.73 |

- `memory-async` `query_shape`: `sort score desc + limit 10`
- `memory-async` `planning_mode`: `strict`

### sort_limit_unindexed_200

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.1951 | 0.1905 | 0.1880 | memory/python scan>filter>sort>slice | 0.00 | 107.73 |

- `memory-async` `query_shape`: `sort score desc + limit 10`
- `memory-async` `planning_mode`: `strict`

## search_diagnostics

### search_text_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.3742 | 0.3717 | 0.3700 | memory/search opaque | 0.00 | 119.23 |

- `memory-async` `query_shape`: `$search.text title/body ada`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `text`

### search_autocomplete_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.3336 | 0.3322 | 0.3300 | memory/search opaque | 0.00 | 119.23 |

- `memory-async` `query_shape`: `$search.autocomplete title/body alg`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `autocomplete`

### search_wildcard_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.2061 | 0.2058 | 0.2040 | memory/search opaque | 0.00 | 119.23 |

- `memory-async` `query_shape`: `$search.wildcard body *vector*`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `wildcard`

### search_regex_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.1895 | 0.1888 | 0.1860 | memory/search opaque | 0.00 | 119.23 |

- `memory-async` `query_shape`: `$search.regex title Ada.*algorithms`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `regex`

### search_compound_hybrid_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.4330 | 0.4301 | 0.4280 | memory/search opaque | 0.00 | 119.23 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+filter(exists,wildcard)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_should_near_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.4101 | 0.4093 | 0.4060 | memory/search opaque | 0.01 | 119.23 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+filter(wildcard)+should(exists,near)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 1.2724 | 1.2729 | 1.2660 | memory/search opaque | 0.00 | 119.23 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_matched_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.9996 | 1.0039 | 0.9940 | memory/search opaque | 0.01 | 119.25 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(kind=note)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `2`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_title_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.4859 | 0.4841 | 0.4820 | memory/search opaque | 0.00 | 119.25 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+match(title=Ada algorithms)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `2`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_msm2_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.9831 | 0.9771 | 0.9740 | memory/search opaque | 0.00 | 119.25 |

- `memory-async` `query_shape`: `$search.compound must(text=report 0)+should(exists,wildcard,autocomplete)+minimumShouldMatch(2)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

### search_compound_candidateable_should_tie_heavy_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.3607 | 0.3598 | 0.3540 | memory/search opaque | 0.01 | 119.25 |

- `memory-async` `query_shape`: `$search.compound must(text=vector)+should(exists(title),exists(body),wildcard(body=*vector*))`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `1`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `compound`

## vector_search_diagnostics

### vector_search_ann_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0723 | 0.0668 | 0.0700 | memory/search opaque | 0.04 | 227.69 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_cosine_low_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0704 | 0.0673 | 0.0660 | memory/search opaque | 0.00 | 227.91 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(10)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `10`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_cosine_high_candidates_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0688 | 0.0675 | 0.0660 | memory/search opaque | 0.00 | 227.92 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + numCandidates(48)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `48`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_dot_product_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0710 | 0.0685 | 0.0680 | memory/search opaque | 0.00 | 235.73 |

- `memory-async` `query_shape`: `$vectorSearch dotProduct topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `dotProduct`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_euclidean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0712 | 0.0685 | 0.0680 | memory/search opaque | 0.00 | 239.22 |

- `memory-async` `query_shape`: `$vectorSearch euclidean topk`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `euclidean`
- `memory-async` `mode`: `exact`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `1000`

### vector_search_filtered_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0707 | 0.0677 | 0.0680 | memory/search opaque | 0.00 | 239.66 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + post-filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `334`

### vector_search_filtered_boolean_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0727 | 0.0724 | 0.0680 | memory/search opaque | 0.00 | 239.69 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + boolean candidate filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `454`

### vector_search_filtered_underflow_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0712 | 0.0703 | 0.0640 | memory/search opaque | 0.00 | 239.69 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + rare boolean candidate filter`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `10`
- `memory-async` `candidates_evaluated`: `61`

### vector_search_filtered_min_score_topk_100

| Engine | Runs | Wall mean (s) | Wall median (s) | CPU user mean (s) | Plan | RSS delta mean (MB) | RSS peak max (MB) |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| memory-async | 5 | 0.0738 | 0.0689 | 0.0680 | memory/search opaque | 0.00 | 239.70 |

- `memory-async` `query_shape`: `$vectorSearch cosine topk + filter(kind=note) + minScore(0.999)`
- `memory-async` `streaming_batch_execution`: `False`
- `memory-async` `remaining_stage_count`: `0`
- `memory-async` `planning_mode`: `strict`
- `memory-async` `query_operator`: `vectorSearch`
- `memory-async` `similarity`: `cosine`
- `memory-async` `mode`: `exact`
- `memory-async` `filter_mode`: `candidate-prefilter`
- `memory-async` `candidates_requested`: `24`
- `memory-async` `candidates_evaluated`: `666`
