import os,subprocess,sys
from pathlib import Path
v=os.environ['MONGOECO_REAL_MONGODB_TARGET']; suffix=v.replace('.','_')
for case_set,key in [('bson-dispatch','bson_dispatch')]:
 reference=f'tests/fixtures/semantic_{key}_{suffix}.json'
 if key=='bson_dispatch':
  subprocess.run([sys.executable,'scripts/capture_differential_replay_golden.py','--target',v,'--case-set',case_set,'--output',reference],check=True)
 subprocess.run([sys.executable,'scripts/capture_differential_replay_golden.py','--target',v,'--case-set',case_set,'--output',f'/tmp/mongoeco-dispatch-native-v10/{v}/{key}-check.json','--check',reference],check=True)
