import json,math,statistics,hashlib
from pathlib import Path
import numpy as np
P=Path('/tmp/mongoeco-f11-b837-cost-samples.json');records=json.loads(P.read_text());key='SQLiteEngine-standard-aggregate-first-page'
def matrix(records):
 names=list(records[0]['results']['consumption'])+list(records[0]['results']['binary'])
 def value(r,k):
  if k in r['results']['consumption']:return r['results']['consumption'][k]['cpu_ns']
  return statistics.median(r['results']['binary'][k]['cpu_seconds'])
 return names,np.array([[(math.log(value(records[4*b+1],k))+math.log(value(records[4*b+2],k))-math.log(value(records[4*b],k))-math.log(value(records[4*b+3],k)))/2 for b in range(6)] for k in names])
names,X=matrix(records);j=names.index(key);stats={}
for n,t in ((3,4.303),(6,2.571)):
 look=json.loads(Path(f'/tmp/mongoeco-f11-b837-cost-look{n}.json').read_text());hits={v:0 for v in ('accepted','regression','inconclusive')}
 for k,x in zip(names,X[:,:n]):
  m=float(x.mean());s=float(x.std(ddof=1));lo,hi=math.exp(m-t*s/math.sqrt(n)),math.exp(m+t*s/math.sqrt(n));c='accepted' if hi<=1.05 else 'regression' if lo>1.05 else 'inconclusive';hits[c]+=1
  row=look['cases'][k];assert abs(lo-row['lower'])<1e-12 and abs(hi-row['upper'])<1e-12 and c==row['classification']
 stats[str(n)]={'counts':hits,'pending_mean':float(X[j,:n].mean()),'pending_sd':float(X[j,:n].std(ddof=1))}
# Descriptive common component. Leave target out: do not count it as its own predictor.
cons=[i for i,k in enumerate(names) if k in records[0]['results']['consumption']]
common=X[cons].mean(axis=0);without=X[[i for i in cons if i!=j]].mean(axis=0)
beta=float(np.cov(X[j],without,ddof=1)[0,1]/without.var(ddof=1));res=X[j]-beta*without
noise={}
for label,prefix in (('e4eb','/tmp/mongoeco-f11-cost-eof-bounded'),('b936','/tmp/mongoeco-f11-ba-cost'),('b837','/tmp/mongoeco-f11-b837-cost')):
 ns,x=matrix(json.loads(Path(prefix+'-samples.json').read_text()));noise[label]={'median_sd_all':float(np.median(x.std(axis=1,ddof=1))),'common_mean_sd':float(x.mean(axis=0).std(ddof=1))}
# Proof of overlap for nested looks under iid N(mu,sigma^2), at mu=threshold.
# Z1,Z2 are sqrt(3) times means of two triples; U,V are independent chi-square(2).
# Polar integration yields f(theta)=m/(1+m)-m/(1+h)^2, where m=min(a,h).
# On [0,pi/2], a decreases; h=5 cos^2(phi)/b^2 - sin^2(phi) decreases with |phi|.
# f increases in m,h when 0<=m<=h. These are interval LOWER sums, not MC calibration.
a,b=4.303,2.571;half=math.atan(math.sqrt(5)/b);left,right=math.pi/4-half,math.pi/4+half
bounds=[]
for n in (1000,10000,100000):
 step=(right-left)/n;terms=[]
 for i in range(n):
  l,r=left+i*step,left+(i+1)*step
  far=max(abs(l-math.pi/4),abs(r-math.pi/4));h=max(0,5*math.cos(far)**2/b**2-math.sin(far)**2-1e-12)
  amin=max(0,2*math.cos(r)**2/a**2-1e-12);m=min(amin,h)
  terms.append(max(0,m/(1+m)-m/(1+h)**2-1e-12))
 lower=math.fsum(terms)*step/(2*math.pi);bounds.append({'intervals':n,'overlap_lower_sum':lower})
 assert lower>.005
# Integer degrees-of-freedom t tails, evaluated by positive sin-power integrals.
# t tail = C * integral_0^atan(sqrt(df)/t) sin(u)^(df-1) du.
def sf(t,df):
 if df==2:return .5-t/(2*math.sqrt(t*t+2))
 u=math.atan(math.sqrt(df)/t);I=u
 for k in range(2,df,2):I=(k-1)/k*I-math.sin(u)**(k-1)*math.cos(u)/k
 return math.gamma((df+1)/2)/(math.sqrt(math.pi)*math.gamma(df/2))*I
old_marginals=[sf(a,2),sf(b,5)];overlap_bound=bounds[-1]['overlap_lower_sum'];old_upper=sum(old_marginals)-overlap_bound
assert old_upper<.045
assert sf(4.033,5)<.005 and sf(3.500,7)<.005
# Sanity-check only; not proof or precision/power promise for the workstation.
rng=np.random.default_rng(20261102);R=400000;chunk=20000;mc={}
for scale in (.5,1.,2.):
 hits={k:0 for k in ('old','fresh_025','fresh_005','pooled_249','pooled_285')}
 for _ in range(R//chunk):
  x=rng.normal(size=(chunk,6));y=scale*rng.normal(size=(chunk,6));z=np.concatenate([x,y],axis=1)
  def T(v):return -v.mean(axis=1)*np.sqrt(v.shape[1])/v.std(axis=1,ddof=1)
  prior=(T(x[:,:3])>=a)|(T(x)>=b);fresh=T(y);pooled=T(z)
  for k,event in [('old',prior),('fresh_025',prior|(fresh>=b)),('fresh_005',prior|(fresh>=4.033)),('pooled_249',prior|(pooled>=2.49)),('pooled_285',prior|(pooled>=2.85))]:hits[k]+=int(event.sum())
 mc[str(scale)]={k:v/R for k,v in hits.items()}
power={};threshold=math.log(1.05);target=float(X[j].mean())
for sd in (.034,.018):
 hits=0
 for _ in range(R//chunk):
  v=rng.normal(target,sd,size=(chunk,6));hits+=int((v.mean(axis=1)+4.033*v.std(axis=1,ddof=1)/math.sqrt(6)<=threshold).sum())
 power[str(sd)]=hits/R
wall=[r['worker_wall_seconds']['consumption'] for r in records]
out={'raw_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'recalculation':stats,'common_log_mean_40':common.tolist(),'target_leave_one_out_correlation':float(np.corrcoef(X[j],without)[0,1]),'target_leave_one_out_residual_sd':float(res.std(ddof=1)),'campaign_noise_descriptive':noise,'old_look_marginal_type_I':old_marginals,'overlap_lower_bounds':bounds,'old_union_error_upper':old_upper,'new_only_alpha':.005,'df5_multiplier':4.033,'df5_actual_tail':sf(4.033,5),'combined_error_bound':old_upper+.005,'model_assumptions':'iid normal blocks within original campaign and within future stage; same target mean; future stage independent of old. Future sigma may differ. No uniform guarantee for nonnormal/dependent blocks.','simulation_only':{'repetitions':R,'seed':20261102,'null_error':mc,'new_only_6_block_power_at_observed_mean':power},'historical_wall_estimates_seconds':{'six_new_blocks_consumption':24*statistics.mean(wall),'eight_new_blocks_consumption':32*statistics.mean(wall),'eight_using_slowest_arm':32*max(wall)}}
Path('/tmp/mongoeco-f11-report-review.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
