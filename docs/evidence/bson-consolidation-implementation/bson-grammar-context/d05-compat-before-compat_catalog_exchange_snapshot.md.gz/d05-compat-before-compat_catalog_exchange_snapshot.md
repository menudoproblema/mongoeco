# Compat Catalog

## Defaults
- `mongodb_dialect`: `7.0`
- `pymongo_profile`: `4.9`
- `pymongo_auto_profile`: `auto-installed`
- `pymongo_strict_auto_profile`: `strict-auto-installed`

## Hooks
- `mongodb_dialect`: `supports_dynamic_get_field`, `supports_now_in_read_command_let`, `uses_distinct_command_request_field_name`, `null_query_matches_undefined`, `rejects_empty_group_fields`, `validates_densify_partition_paths`, `validates_aggregation_syntax_early`, `documents_join_omits_collection_namespace`, `supports_array_index_variables`, `uses_extended_conversions`, `uses_server_densify_bounds`, `densify_equal_bounds_are_empty`, `densify_full_nonadvancing_step_errors`, `densify_empty_partition_generates_values`, `supports_date_range_windows`, `limits_trim_chars`, `rejects_cluster_time_expression`, `list_indexes_includes_simple_collation`, `rejects_unimplemented_wildcard_projection`, `merge_insert_preserves_incoming_field_order`
- `pymongo_profile`: `supports_update_one_sort`, `rejects_reserved_aggregation_keywords`

## Supported Majors
- `mongodb`: 7, 8, 9
- `pymongo`: 4

## MongoDB Dialects
### `7.0`
- `server_version`: `7.0`
- `label`: `MongoDB 7.0`
- `aliases`: `7`, `7.0`
- `behavior_flags`: `{'uses_distinct_command_request_field_name': False, 'supports_now_in_read_command_let': True, 'supports_dynamic_get_field': False, 'null_query_matches_undefined': True, 'uses_server_densify_bounds': True, 'densify_equal_bounds_are_empty': False, 'densify_full_nonadvancing_step_errors': False, 'densify_empty_partition_generates_values': True, 'documents_join_omits_collection_namespace': False}`
- `policy_spec`: `{'null_query_matches_undefined': True, 'expression_truthiness': 'mongo-default', 'projection_flag_mode': 'bool-or-binary-int', 'update_path_sort_mode': 'numeric-then-lex', 'equality_mode': 'bson-structural', 'comparison_mode': 'bson-total-order'}`
- `capabilities`: `query.null_matches_undefined`
- `query_field_operators`: `$all`, `$bitsAllClear`, `$bitsAllSet`, `$bitsAnyClear`, `$bitsAnySet`, `$cmp`, `$elemMatch`, `$eq`, `$exists`, `$geoIntersects`, `$geoWithin`, `$gt`, `$gte`, `$in`, `$lt`, `$lte`, `$mod`, `$ne`, `$near`, `$nearSphere`, `$nin`, `$not`, `$options`, `$regex`, `$size`, `$type`
- `query_top_level_operators`: `$and`, `$comment`, `$expr`, `$jsonSchema`, `$nor`, `$or`, `$text`, `$where`
- `update_operators`: `$addToSet`, `$bit`, `$currentDate`, `$inc`, `$max`, `$min`, `$mul`, `$pop`, `$pull`, `$pullAll`, `$push`, `$rename`, `$set`, `$setOnInsert`, `$unset`
- `system_variables`: `$$NOW`
- `aggregation_expression_operators`: `$abs`, `$add`, `$allElementsTrue`, `$and`, `$anyElementTrue`, `$arrayElemAt`, `$arrayToObject`, `$avg`, `$binarySize`, `$bitAnd`, `$bitNot`, `$bitOr`, `$bitXor`, `$bsonSize`, `$ceil`, `$cmp`, `$concat`, `$concatArrays`, `$cond`, `$convert`, `$dateAdd`, `$dateDiff`, `$dateFromParts`, `$dateFromString`, `$dateSubtract`, `$dateToParts`, `$dateToString`, `$dateTrunc`, `$dayOfMonth`, `$dayOfWeek`, `$dayOfYear`, `$divide`, `$eq`, `$exp`, `$filter`, `$first`, `$firstN`, `$floor`, `$getField`, `$gt`, `$gte`, `$hour`, `$ifNull`, `$in`, `$indexOfArray`, `$indexOfBytes`, `$indexOfCP`, `$isArray`, `$isNumber`, `$isoDayOfWeek`, `$isoWeek`, `$isoWeekYear`, `$last`, `$lastN`, `$let`, `$literal`, `$ln`, `$log`, `$log10`, `$lt`, `$lte`, `$ltrim`, `$map`, `$max`, `$maxN`, `$median`, `$mergeObjects`, `$millisecond`, `$min`, `$minN`, `$minute`, `$mod`, `$month`, `$multiply`, `$ne`, `$not`, `$objectToArray`, `$or`, `$percentile`, `$pow`, `$rand`, `$range`, `$reduce`, `$regexFind`, `$regexFindAll`, `$regexMatch`, `$replaceAll`, `$replaceOne`, `$reverseArray`, `$round`, `$rtrim`, `$second`, `$setDifference`, `$setEquals`, `$setField`, `$setIntersection`, `$setIsSubset`, `$setUnion`, `$size`, `$slice`, `$sortArray`, `$split`, `$sqrt`, `$stdDevPop`, `$stdDevSamp`, `$strLenBytes`, `$strLenCP`, `$strcasecmp`, `$substr`, `$substrBytes`, `$substrCP`, `$subtract`, `$sum`, `$switch`, `$toBool`, `$toDate`, `$toDecimal`, `$toDouble`, `$toInt`, `$toLong`, `$toLower`, `$toObjectId`, `$toString`, `$toUUID`, `$toUpper`, `$trim`, `$trunc`, `$type`, `$unsetField`, `$week`, `$year`, `$zip`
- `aggregation_stages`: `$addFields`, `$bucket`, `$bucketAuto`, `$collStats`, `$count`, `$currentOp`, `$densify`, `$documents`, `$facet`, `$fill`, `$geoNear`, `$group`, `$indexStats`, `$limit`, `$listSessions`, `$lookup`, `$match`, `$merge`, `$planCacheStats`, `$project`, `$redact`, `$replaceRoot`, `$replaceWith`, `$sample`, `$set`, `$setWindowFields`, `$skip`, `$sort`, `$sortByCount`, `$unionWith`, `$unset`, `$unwind`
- `group_accumulators`: `$addToSet`, `$avg`, `$bottom`, `$bottomN`, `$count`, `$first`, `$firstN`, `$last`, `$lastN`, `$max`, `$maxN`, `$median`, `$mergeObjects`, `$min`, `$minN`, `$percentile`, `$push`, `$stdDevPop`, `$stdDevSamp`, `$sum`, `$top`, `$topN`
- `window_accumulators`: `$addToSet`, `$avg`, `$bottom`, `$bottomN`, `$count`, `$denseRank`, `$derivative`, `$documentNumber`, `$expMovingAvg`, `$first`, `$firstN`, `$integral`, `$last`, `$lastN`, `$linearFill`, `$locf`, `$max`, `$maxN`, `$median`, `$min`, `$minN`, `$percentile`, `$push`, `$rank`, `$shift`, `$stdDevPop`, `$stdDevSamp`, `$sum`, `$top`, `$topN`

### `8.0`
- `server_version`: `8.0`
- `label`: `MongoDB 8.0`
- `aliases`: `8`, `8.0`
- `behavior_flags`: `{'uses_distinct_command_request_field_name': True, 'supports_now_in_read_command_let': False, 'supports_dynamic_get_field': True, 'null_query_matches_undefined': False, 'uses_server_densify_bounds': True, 'densify_equal_bounds_are_empty': True, 'densify_full_nonadvancing_step_errors': True, 'densify_empty_partition_generates_values': False, 'documents_join_omits_collection_namespace': True}`
- `policy_spec`: `{'null_query_matches_undefined': False, 'expression_truthiness': 'mongo-default', 'projection_flag_mode': 'bool-or-binary-int', 'update_path_sort_mode': 'numeric-then-lex', 'equality_mode': 'bson-structural', 'comparison_mode': 'bson-total-order'}`
- `capabilities`: _empty_
- `query_field_operators`: `$all`, `$bitsAllClear`, `$bitsAllSet`, `$bitsAnyClear`, `$bitsAnySet`, `$cmp`, `$elemMatch`, `$eq`, `$exists`, `$geoIntersects`, `$geoWithin`, `$gt`, `$gte`, `$in`, `$lt`, `$lte`, `$mod`, `$ne`, `$near`, `$nearSphere`, `$nin`, `$not`, `$options`, `$regex`, `$size`, `$type`
- `query_top_level_operators`: `$and`, `$comment`, `$expr`, `$jsonSchema`, `$nor`, `$or`, `$text`, `$where`
- `update_operators`: `$addToSet`, `$bit`, `$currentDate`, `$inc`, `$max`, `$min`, `$mul`, `$pop`, `$pull`, `$pullAll`, `$push`, `$rename`, `$set`, `$setOnInsert`, `$unset`
- `system_variables`: `$$NOW`
- `aggregation_expression_operators`: `$abs`, `$add`, `$allElementsTrue`, `$and`, `$anyElementTrue`, `$arrayElemAt`, `$arrayToObject`, `$avg`, `$binarySize`, `$bitAnd`, `$bitNot`, `$bitOr`, `$bitXor`, `$bsonSize`, `$ceil`, `$cmp`, `$concat`, `$concatArrays`, `$cond`, `$convert`, `$dateAdd`, `$dateDiff`, `$dateFromParts`, `$dateFromString`, `$dateSubtract`, `$dateToParts`, `$dateToString`, `$dateTrunc`, `$dayOfMonth`, `$dayOfWeek`, `$dayOfYear`, `$divide`, `$eq`, `$exp`, `$filter`, `$first`, `$firstN`, `$floor`, `$getField`, `$gt`, `$gte`, `$hour`, `$ifNull`, `$in`, `$indexOfArray`, `$indexOfBytes`, `$indexOfCP`, `$isArray`, `$isNumber`, `$isoDayOfWeek`, `$isoWeek`, `$isoWeekYear`, `$last`, `$lastN`, `$let`, `$literal`, `$ln`, `$log`, `$log10`, `$lt`, `$lte`, `$ltrim`, `$map`, `$max`, `$maxN`, `$median`, `$mergeObjects`, `$millisecond`, `$min`, `$minN`, `$minute`, `$mod`, `$month`, `$multiply`, `$ne`, `$not`, `$objectToArray`, `$or`, `$percentile`, `$pow`, `$rand`, `$range`, `$reduce`, `$regexFind`, `$regexFindAll`, `$regexMatch`, `$replaceAll`, `$replaceOne`, `$reverseArray`, `$round`, `$rtrim`, `$second`, `$setDifference`, `$setEquals`, `$setField`, `$setIntersection`, `$setIsSubset`, `$setUnion`, `$size`, `$slice`, `$sortArray`, `$split`, `$sqrt`, `$stdDevPop`, `$stdDevSamp`, `$strLenBytes`, `$strLenCP`, `$strcasecmp`, `$substr`, `$substrBytes`, `$substrCP`, `$subtract`, `$sum`, `$switch`, `$toBool`, `$toDate`, `$toDecimal`, `$toDouble`, `$toInt`, `$toLong`, `$toLower`, `$toObjectId`, `$toString`, `$toUUID`, `$toUpper`, `$trim`, `$trunc`, `$type`, `$unsetField`, `$week`, `$year`, `$zip`
- `aggregation_stages`: `$addFields`, `$bucket`, `$bucketAuto`, `$collStats`, `$count`, `$currentOp`, `$densify`, `$documents`, `$facet`, `$fill`, `$geoNear`, `$group`, `$indexStats`, `$limit`, `$listSessions`, `$lookup`, `$match`, `$merge`, `$planCacheStats`, `$project`, `$redact`, `$replaceRoot`, `$replaceWith`, `$sample`, `$set`, `$setWindowFields`, `$skip`, `$sort`, `$sortByCount`, `$unionWith`, `$unset`, `$unwind`
- `group_accumulators`: `$addToSet`, `$avg`, `$bottom`, `$bottomN`, `$count`, `$first`, `$firstN`, `$last`, `$lastN`, `$max`, `$maxN`, `$median`, `$mergeObjects`, `$min`, `$minN`, `$percentile`, `$push`, `$stdDevPop`, `$stdDevSamp`, `$sum`, `$top`, `$topN`
- `window_accumulators`: `$addToSet`, `$avg`, `$bottom`, `$bottomN`, `$count`, `$denseRank`, `$derivative`, `$documentNumber`, `$expMovingAvg`, `$first`, `$firstN`, `$integral`, `$last`, `$lastN`, `$linearFill`, `$locf`, `$max`, `$maxN`, `$median`, `$min`, `$minN`, `$percentile`, `$push`, `$rank`, `$shift`, `$stdDevPop`, `$stdDevSamp`, `$sum`, `$top`, `$topN`

### `9.0`
- `server_version`: `9.0`
- `label`: `MongoDB 9.0`
- `aliases`: `9`, `9.0`
- `behavior_flags`: `{'uses_distinct_command_request_field_name': False, 'supports_now_in_read_command_let': False, 'supports_dynamic_get_field': True, 'null_query_matches_undefined': False, 'rejects_empty_group_fields': True, 'validates_densify_partition_paths': True, 'validates_aggregation_syntax_early': True, 'documents_join_omits_collection_namespace': True, 'supports_array_index_variables': True, 'uses_extended_conversions': True, 'uses_server_densify_bounds': True, 'densify_equal_bounds_are_empty': True, 'densify_full_nonadvancing_step_errors': True, 'densify_empty_partition_generates_values': False, 'supports_date_range_windows': True, 'limits_trim_chars': True, 'rejects_cluster_time_expression': True, 'list_indexes_includes_simple_collation': True, 'rejects_unimplemented_wildcard_projection': True, 'merge_insert_preserves_incoming_field_order': True}`
- `policy_spec`: `{'null_query_matches_undefined': False, 'expression_truthiness': 'mongo-default', 'projection_flag_mode': 'bool-or-binary-int', 'update_path_sort_mode': 'numeric-then-lex', 'equality_mode': 'bson-structural', 'comparison_mode': 'bson-total-order'}`
- `capabilities`: `aggregation.array_index_variables`, `aggregation.convert.base`, `aggregation.date_range_windows`, `aggregation.to_string.extended`, `indexes.simple_collation_metadata`
- `query_field_operators`: `$all`, `$bitsAllClear`, `$bitsAllSet`, `$bitsAnyClear`, `$bitsAnySet`, `$cmp`, `$elemMatch`, `$eq`, `$exists`, `$geoIntersects`, `$geoWithin`, `$gt`, `$gte`, `$in`, `$lt`, `$lte`, `$mod`, `$ne`, `$near`, `$nearSphere`, `$nin`, `$not`, `$options`, `$regex`, `$size`, `$type`
- `query_top_level_operators`: `$and`, `$comment`, `$expr`, `$jsonSchema`, `$nor`, `$or`, `$text`, `$where`
- `update_operators`: `$addToSet`, `$bit`, `$currentDate`, `$inc`, `$max`, `$min`, `$mul`, `$pop`, `$pull`, `$pullAll`, `$push`, `$rename`, `$set`, `$setOnInsert`, `$unset`
- `system_variables`: `$$NOW`
- `aggregation_expression_operators`: `$abs`, `$add`, `$allElementsTrue`, `$and`, `$anyElementTrue`, `$arrayElemAt`, `$arrayToObject`, `$avg`, `$binarySize`, `$bitAnd`, `$bitNot`, `$bitOr`, `$bitXor`, `$bsonSize`, `$ceil`, `$cmp`, `$concat`, `$concatArrays`, `$cond`, `$convert`, `$dateAdd`, `$dateDiff`, `$dateFromParts`, `$dateFromString`, `$dateSubtract`, `$dateToParts`, `$dateToString`, `$dateTrunc`, `$dayOfMonth`, `$dayOfWeek`, `$dayOfYear`, `$divide`, `$eq`, `$exp`, `$filter`, `$first`, `$firstN`, `$floor`, `$getField`, `$gt`, `$gte`, `$hour`, `$ifNull`, `$in`, `$indexOfArray`, `$indexOfBytes`, `$indexOfCP`, `$isArray`, `$isNumber`, `$isoDayOfWeek`, `$isoWeek`, `$isoWeekYear`, `$last`, `$lastN`, `$let`, `$literal`, `$ln`, `$log`, `$log10`, `$lt`, `$lte`, `$ltrim`, `$map`, `$max`, `$maxN`, `$median`, `$mergeObjects`, `$millisecond`, `$min`, `$minN`, `$minute`, `$mod`, `$month`, `$multiply`, `$ne`, `$not`, `$objectToArray`, `$or`, `$percentile`, `$pow`, `$rand`, `$range`, `$reduce`, `$regexFind`, `$regexFindAll`, `$regexMatch`, `$replaceAll`, `$replaceOne`, `$reverseArray`, `$round`, `$rtrim`, `$second`, `$setDifference`, `$setEquals`, `$setField`, `$setIntersection`, `$setIsSubset`, `$setUnion`, `$size`, `$slice`, `$sortArray`, `$split`, `$sqrt`, `$stdDevPop`, `$stdDevSamp`, `$strLenBytes`, `$strLenCP`, `$strcasecmp`, `$substr`, `$substrBytes`, `$substrCP`, `$subtract`, `$sum`, `$switch`, `$toBool`, `$toDate`, `$toDecimal`, `$toDouble`, `$toInt`, `$toLong`, `$toLower`, `$toObjectId`, `$toString`, `$toUUID`, `$toUpper`, `$trim`, `$trunc`, `$type`, `$unsetField`, `$week`, `$year`, `$zip`
- `aggregation_stages`: `$addFields`, `$bucket`, `$bucketAuto`, `$collStats`, `$count`, `$currentOp`, `$densify`, `$documents`, `$facet`, `$fill`, `$geoNear`, `$group`, `$indexStats`, `$limit`, `$listSessions`, `$lookup`, `$match`, `$merge`, `$planCacheStats`, `$project`, `$redact`, `$replaceRoot`, `$replaceWith`, `$sample`, `$set`, `$setWindowFields`, `$skip`, `$sort`, `$sortByCount`, `$unionWith`, `$unset`, `$unwind`
- `group_accumulators`: `$addToSet`, `$avg`, `$bottom`, `$bottomN`, `$count`, `$first`, `$firstN`, `$last`, `$lastN`, `$max`, `$maxN`, `$median`, `$mergeObjects`, `$min`, `$minN`, `$percentile`, `$push`, `$stdDevPop`, `$stdDevSamp`, `$sum`, `$top`, `$topN`
- `window_accumulators`: `$addToSet`, `$avg`, `$bottom`, `$bottomN`, `$count`, `$denseRank`, `$derivative`, `$documentNumber`, `$expMovingAvg`, `$first`, `$firstN`, `$integral`, `$last`, `$lastN`, `$linearFill`, `$locf`, `$max`, `$maxN`, `$median`, `$min`, `$minN`, `$percentile`, `$push`, `$rank`, `$shift`, `$stdDevPop`, `$stdDevSamp`, `$sum`, `$top`, `$topN`

## PyMongo Profiles
### `4.9`
- `driver_series`: `4.x`
- `label`: `PyMongo 4.9`
- `aliases`: `4`, `4.9`
- `behavior_flags`: `{'supports_update_one_sort': False}`
- `capabilities`: _empty_

### `4.11`
- `driver_series`: `4.x`
- `label`: `PyMongo 4.11`
- `aliases`: `4.11`
- `behavior_flags`: `{'supports_update_one_sort': True}`
- `capabilities`: `update_one.sort`

### `4.13`
- `driver_series`: `4.x`
- `label`: `PyMongo 4.13`
- `aliases`: `4.13`
- `behavior_flags`: `{'supports_update_one_sort': True}`
- `capabilities`: `update_one.sort`

### `4.17`
- `driver_series`: `4.x`
- `label`: `PyMongo 4.17`
- `aliases`: `4.17`
- `behavior_flags`: `{'supports_update_one_sort': True}`
- `capabilities`: `update_one.sort`

### `4.18`
- `driver_series`: `4.x`
- `label`: `PyMongo 4.18`
- `aliases`: `4.18`
- `behavior_flags`: `{'supports_update_one_sort': True, 'rejects_reserved_aggregation_keywords': True}`
- `capabilities`: `aggregate.reserved_keywords_validation`, `update_one.sort`, `uri.srv_allowed_hosts_suffix`

### `4.19`
- `driver_series`: `4.x`
- `label`: `PyMongo 4.19`
- `aliases`: `4.19`
- `behavior_flags`: `{'supports_update_one_sort': True, 'rejects_reserved_aggregation_keywords': True}`
- `capabilities`: `aggregate.reserved_keywords_validation`, `update_one.sort`, `uri.rejects_percent_encoded_hostnames`, `uri.srv_allowed_hosts_suffix`, `uri.srv_host_validator`

## Database Commands
### `aggregate`
- `family`: `admin_read`
- `supports_wire`: `True`
- `supports_explain`: `True`
- `supports_comment`: `True`
- `supported_options`: `allowDiskUse`, `batchSize`, `comment`, `hint`, `let`, `maxTimeMS`
- `note`: `Compiled through database admin routing and exposed by API and wire. Top-level batchSize limits wire firstBatch only; database.command(...) uses cursor.batchSize for local prefetch and returns the full result.`

### `buildInfo`
- `family`: `admin_introspection`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Static local metadata sourced from the dialect/runtime descriptor.`

### `collMod`
- `family`: `admin_write`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Validation options only; other collMod features are unsupported.`

### `collStats`
- `family`: `admin_stats`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: `scale`
- `note`: `Served from local collection stats snapshots.`

### `configureFailPoint`
- `family`: `admin_control`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Local test-only failCommand control; no general MongoDB failpoint or distributed server behavior is claimed.`

### `connectionStatus`
- `family`: `admin_status`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: `showPrivileges`
- `note`: `Static local auth/runtime shape, with wire auth info patched from the active connection.`

### `count`
- `family`: `admin_read`
- `supports_wire`: `True`
- `supports_explain`: `True`
- `supports_comment`: `True`
- `supported_options`: `comment`, `hint`, `limit`, `maxTimeMS`, `query`, `skip`
- `note`: `Compiled through the same find-selection path used by direct count command routing.`

### `create`
- `family`: `admin_namespace`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Namespace administration routed through database admin services.`

### `createIndexes`
- `family`: `admin_index`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `comment`, `maxTimeMS`
- `note`: `Index administration routed through local collection/index services, including local-only per-index metadata such as hidden indexes.`

### `currentOp`
- `family`: `admin_control`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `comment`
- `note`: `Exposes the local active-operation registry for embedded-runtime API and wire parity; no distributed semantics are attempted.`

### `dbHash`
- `family`: `admin_introspection`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `collections`, `comment`
- `note`: `Computes stable local collection hashes for embedded-runtime verification across documents, indexes and collection options.`

### `dbStats`
- `family`: `admin_stats`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: `scale`
- `note`: `Served from local database stats snapshots.`

### `delete`
- `family`: `admin_write`
- `supports_wire`: `True`
- `supports_explain`: `True`
- `supports_comment`: `True`
- `supported_options`: `comment`, `let`, `ordered`
- `note`: `Write command orchestration routes each delete spec through the same write semantics as the public API.`

### `distinct`
- `family`: `admin_read`
- `supports_wire`: `True`
- `supports_explain`: `True`
- `supports_comment`: `True`
- `supported_options`: `comment`, `hint`, `maxTimeMS`, `query`
- `note`: `Compiled through the same read-selection path used by direct distinct execution.`

### `drop`
- `family`: `admin_namespace`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Namespace administration routed through database admin services.`

### `dropDatabase`
- `family`: `admin_namespace`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Implemented as local namespace lifecycle cleanup plus runtime invalidation.`

### `dropIndexes`
- `family`: `admin_index`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `comment`
- `note`: `Index administration routed through local collection/index services.`

### `explain`
- `family`: `admin_explain`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `comment`, `maxTimeMS`, `verbosity`
- `note`: `Delegates to routed find/aggregate/update/delete/count/distinct/findAndModify explain builders and preserves the explained command shape.`

### `find`
- `family`: `admin_read`
- `supports_wire`: `True`
- `supports_explain`: `True`
- `supports_comment`: `True`
- `supported_options`: `batchSize`, `comment`, `filter`, `hint`, `let`, `limit`, `maxTimeMS`, `projection`, `skip`, `sort`
- `note`: `Compiled through the collection find path. batchSize limits wire firstBatch; database.command(...) uses it for local prefetch but returns the full result.`

### `findAndModify`
- `family`: `admin_find_and_modify`
- `supports_wire`: `True`
- `supports_explain`: `True`
- `supports_comment`: `True`
- `supported_options`: `arrayFilters`, `bypassDocumentValidation`, `comment`, `hint`, `let`, `maxTimeMS`, `sort`
- `note`: `Routes through explicit find-and-modify orchestration shared by database.command(...) and wire passthrough.`

### `getCmdLineOpts`
- `family`: `admin_introspection`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Static local process metadata.`

### `hello`
- `family`: `admin_status`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Static local handshake metadata.`

### `hostInfo`
- `family`: `admin_introspection`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Static local host/process metadata.`

### `insert`
- `family`: `admin_write`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `bypassDocumentValidation`, `comment`, `ordered`
- `note`: `Write command orchestration routes each insert batch through the same collection semantics as the public API.`

### `isMaster`
- `family`: `admin_status`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Legacy handshake alias sharing the local hello metadata source of truth.`

### `ismaster`
- `family`: `admin_status`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Legacy handshake alias sharing the local hello metadata source of truth.`

### `listCollections`
- `family`: `admin_namespace`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `authorizedCollections`, `comment`, `filter`, `nameOnly`
- `note`: `Namespace listing routed through local snapshots with filter/nameOnly support.`

### `listCommands`
- `family`: `admin_introspection`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Static inventory of the supported raw command surface, including admin family, wire availability and explain availability metadata.`

### `listDatabases`
- `family`: `admin_namespace`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `comment`, `filter`, `nameOnly`
- `note`: `Database listing routed through local snapshots with filter/nameOnly support.`

### `listIndexes`
- `family`: `admin_index`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `comment`
- `note`: `Index metadata surfaced through local collection/index services.`

### `killOp`
- `family`: `admin_control`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `comment`, `op`
- `note`: `Best-effort local cancellation over operations registered as killable in the embedded runtime; no remote or cluster cancellation exists.`

### `ping`
- `family`: `admin_status`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Static local health/availability response.`

### `profile`
- `family`: `admin_control`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: `slowms`
- `note`: `Local profiling control and introspection routed through engine profiling support, including current level and recorded entry counts.`

### `renameCollection`
- `family`: `admin_namespace`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Namespace administration routed through database admin services.`

### `serverStatus`
- `family`: `admin_status`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Static local runtime metadata enriched with engine information, embedded-runtime counters and profiling summary.`

### `update`
- `family`: `admin_write`
- `supports_wire`: `True`
- `supports_explain`: `True`
- `supports_comment`: `True`
- `supported_options`: `arrayFilters`, `bypassDocumentValidation`, `comment`, `let`, `ordered`
- `note`: `Write command orchestration routes each update spec through the same write semantics as the public API.`

### `validate`
- `family`: `admin_validate`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `True`
- `supported_options`: `background`, `comment`, `full`, `scandata`
- `note`: `Validation snapshots routed through local collection validation support.`

### `whatsmyuri`
- `family`: `admin_introspection`
- `supports_wire`: `True`
- `supports_explain`: `False`
- `supports_comment`: `False`
- `supported_options`: _empty_
- `note`: `Static local connection metadata.`

## Operation Options
### `insert_one`
- `comment`: `status`="effective", `note`="Preserved in insert profiling, active operations and session metadata."

### `insert_many`
- `comment`: `status`="effective", `note`="Preserved in batch insert profiling, active operations and session metadata."

### `find`
- `hint`: `status`="effective", `note`="Validated against existing indexes and applied to read planning/explain where engines can honor it."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata and surfaced by explain()."
- `max_time_ms`: `status`="effective", `note`="Enforced as a local deadline during read execution and explain()."
- `batch_size`: `status`="effective", `note`="Async and sync find cursors now fetch local batches before yielding results, even though engines remain in-process."
- `let`: `status`="effective", `note`="Command-level let variables are available through $expr in find filters and cursor execution."

### `count_documents`
- `hint`: `status`="effective", `note`="Applied through the underlying find() path used to count matching documents."
- `comment`: `status`="effective", `note`="Propagated through the underlying read path and session metadata."
- `max_time_ms`: `status`="effective", `note`="Enforced through the underlying find() path used to count documents."
- `let`: `status`="effective", `note`="Propagated into the find-selection path used to count matching documents."

### `distinct`
- `hint`: `status`="effective", `note`="Applied through the underlying find() path used to enumerate distinct values."
- `comment`: `status`="effective", `note`="Propagated through the underlying read path and session metadata."
- `max_time_ms`: `status`="effective", `note`="Enforced through the underlying find() path used to enumerate distinct values."

### `estimated_document_count`
- `comment`: `status`="effective", `note`="Propagated through the underlying full-collection read path and session metadata."
- `max_time_ms`: `status`="effective", `note`="Enforced through the underlying full-collection read path."

### `aggregate`
- `hint`: `status`="effective", `note`="Applied through the pushdown find() path used by aggregate() and surfaced in explain()."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata and propagated through aggregate explain/materialization."
- `max_time_ms`: `status`="effective", `note`="Applied to referenced collection loads, pushdown reads and final pipeline materialization."
- `batch_size`: `status`="effective", `note`="Positive batch sizes trigger chunked execution for streamable aggregate pipelines; global stages still fall back to full materialization."
- `allow_disk_use`: `status`="effective", `note`="Controls whether the aggregation cursor may use the configured spill-to-disk policy for blocking stages."
- `let`: `status`="effective", `note`="Propagated into aggregate expression evaluation and subpipelines."

### `update_one`
- `array_filters`: `status`="effective", `note`="Applied during update execution for supported filtered positional paths."
- `hint`: `status`="effective", `note`="Applied through hinted document selection before single-document update execution."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the write operation."
- `let`: `status`="effective", `note`="Command-level let variables are available through $expr in write filters and selection paths."
- `sort`: `status`="effective", `note`="Implemented with profile-aware validation since PyMongo 4.11."

### `update_many`
- `array_filters`: `status`="effective", `note`="Applied during per-document update execution for supported filtered positional paths."
- `hint`: `status`="effective", `note`="Applied through hinted _id preselection before per-document updates."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the write operation."
- `let`: `status`="effective", `note`="Command-level let variables are available through $expr in write filters and selection paths."

### `replace_one`
- `hint`: `status`="effective", `note`="Applied through hinted document selection before replacement."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the write operation."
- `let`: `status`="effective", `note`="Command-level let variables are available through $expr in write filters and selection paths."
- `sort`: `status`="effective", `note`="Implemented with profile-aware validation since PyMongo 4.11."

### `delete_one`
- `hint`: `status`="effective", `note`="Applied through hinted document selection before delete."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the write operation."
- `let`: `status`="effective", `note`="Command-level let variables are available through $expr in write filters and selection paths."

### `delete_many`
- `hint`: `status`="effective", `note`="Applied through hinted _id preselection before per-document deletes."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the write operation."
- `let`: `status`="effective", `note`="Command-level let variables are available through $expr in write filters and selection paths."

### `find_one_and_update`
- `array_filters`: `status`="effective", `note`="Propagated to the underlying update_one() execution for supported filtered positional paths."
- `hint`: `status`="effective", `note`="Applied through hinted document selection and post-update fetch."
- `comment`: `status`="effective", `note`="Propagated through the underlying read selection path and session metadata."
- `max_time_ms`: `status`="effective", `note`="Propagated through the underlying read selection path and enforced there."
- `let`: `status`="effective", `note`="Command-level let variables are available through $expr in write filters and selection paths."
- `sort`: `status`="effective", `note`="Implemented through update_one()/find semantics with profile-aware validation."

### `find_one_and_replace`
- `hint`: `status`="effective", `note`="Applied through hinted document selection and post-replacement fetch."
- `comment`: `status`="effective", `note`="Propagated through the underlying read selection path and session metadata."
- `max_time_ms`: `status`="effective", `note`="Propagated through the underlying read selection path and enforced there."
- `let`: `status`="effective", `note`="Command-level let variables are available through $expr in write filters and selection paths."
- `sort`: `status`="effective", `note`="Implemented through replace_one()/find semantics with profile-aware validation."

### `find_one_and_delete`
- `sort`: `status`="effective", `note`="Implemented through find() selection semantics before delete."
- `hint`: `status`="effective", `note`="Applied through hinted document selection before delete."
- `comment`: `status`="effective", `note`="Propagated through the underlying read selection path and session metadata."
- `max_time_ms`: `status`="effective", `note`="Propagated through the underlying read selection path and enforced there."
- `let`: `status`="effective", `note`="Command-level let variables are available through $expr in write filters and selection paths."

### `bulk_write`
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the batch write operation."
- `let`: `status`="effective", `note`="Command-level let variables flow into per-operation write filters through $expr when requests do not override them."

### `list_indexes`
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for index administration."

### `create_index`
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for index administration."
- `max_time_ms`: `status`="effective", `note`="Enforced as a local deadline during index build and multikey backfill."
- `background`: `status`="accepted-noop", `note`="Accepted and type-checked for API parity; it does not schedule a background index build."
- `wildcard_projection`: `status`="accepted-noop", `note`="Accepted and type-checked for API parity in dialects 7.0/8.0; the projection is not passed to the engine. Mongoeco's supported subset under dialect 9.0 rejects it before index creation; MongoDB itself supports wildcardProjection."

### `create_indexes`
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for index administration."
- `max_time_ms`: `status`="effective", `note`="Enforced as a local deadline across the whole index batch."

### `drop_index`
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for index administration."

### `drop_indexes`
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for index administration."

## Database Command Options
### `aggregate`
- `hint`: `status`="effective", `note`="Propagated through command routing into aggregate pushdown/explain."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata and surfaced through explain/materialization."
- `maxTimeMS`: `status`="effective", `note`="Enforced against local aggregate execution and explain paths."
- `allowDiskUse`: `status`="effective", `note`="Applied to blocking aggregate stages through the same local spill policy as the public API."
- `let`: `status`="effective", `note`="Propagated into aggregate expression evaluation and subpipelines."
- `batchSize`: `status`="effective", `note`="Top-level batchSize limits the wire firstBatch; database.command() ignores it and uses cursor.batchSize for local prefetch."

### `collStats`
- `scale`: `status`="effective", `note`="Applied to size-oriented metrics in the local collection stats snapshot."

### `connectionStatus`
- `showPrivileges`: `status`="effective", `note`="Controls whether the local auth status document includes the privileges array."

### `count`
- `query`: `status`="effective", `note`="Compiled into the same local find-selection path used to execute the count command."
- `skip`: `status`="effective", `note`="Applied before materializing the local count result."
- `limit`: `status`="effective", `note`="Applied before materializing the local count result."
- `hint`: `status`="effective", `note`="Applied through the compiled selection path used by the count command."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the command execution."
- `maxTimeMS`: `status`="effective", `note`="Enforced through the compiled selection path used by the count command."

### `createIndexes`
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for index administration."
- `maxTimeMS`: `status`="effective", `note`="Enforced as a local deadline across the command index batch."

### `currentOp`
- `comment`: `status`="effective", `note`="Accepted for command parity and recorded in local admin profiling metadata when supplied."

### `dbHash`
- `collections`: `status`="effective", `note`="Limits hashing to the selected local collections while preserving a stable collection-order contract."
- `comment`: `status`="effective", `note`="Accepted for command parity and recorded in command profiling metadata."

### `dbStats`
- `scale`: `status`="effective", `note`="Applied to size-oriented metrics in the local database stats snapshot."

### `delete`
- `ordered`: `status`="effective", `note`="Controls short-circuiting when one delete specification fails."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the write command."
- `let`: `status`="effective", `note`="Command-level bindings are propagated into every delete filter through $expr."

### `distinct`
- `query`: `status`="effective", `note`="Compiled into the same local selection path used to enumerate distinct values."
- `hint`: `status`="effective", `note`="Applied through the underlying read selection path used by the command."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the command execution."
- `maxTimeMS`: `status`="effective", `note`="Enforced through the underlying distinct selection path."

### `dropIndexes`
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for index administration."

### `explain`
- `verbosity`: `status`="effective", `note`="Accepted and surfaced in explain responses for supported routed commands, including find/aggregate/update/delete/count/distinct/findAndModify."
- `comment`: `status`="effective", `note`="Propagated into the explained command where that command supports comment."
- `maxTimeMS`: `status`="effective", `note`="Propagated into the explained command where that command supports maxTimeMS."

### `find`
- `filter`: `status`="effective", `note`="Compiled into the same local find operation shape as the collection API."
- `projection`: `status`="effective", `note`="Applied to command cursor materialization using the same projection semantics as the collection API."
- `sort`: `status`="effective", `note`="Applied to command read planning and result materialization."
- `skip`: `status`="effective", `note`="Applied before command cursor materialization."
- `limit`: `status`="effective", `note`="Applied before command cursor materialization."
- `hint`: `status`="effective", `note`="Applied to command read planning and surfaced in explain."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the command execution."
- `maxTimeMS`: `status`="effective", `note`="Enforced during command read execution and explain."
- `batchSize`: `status`="effective", `note`="Limits the wire firstBatch; database.command() uses it for local prefetch but materializes the full command result."
- `let`: `status`="effective", `note`="Propagated into command-level $expr evaluation."

### `findAndModify`
- `arrayFilters`: `status`="effective", `note`="Applied through the underlying write path for supported filtered positional updates."
- `hint`: `status`="effective", `note`="Applied through hinted selection and post-write fetch."
- `maxTimeMS`: `status`="effective", `note`="Propagated through the underlying selection path and enforced there."
- `let`: `status`="effective", `note`="Propagated into command-level $expr evaluation for the write filter."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the command execution."
- `bypassDocumentValidation`: `status`="effective", `note`="Validated and propagated through replacement/update command routing."
- `sort`: `status`="effective", `note`="Applied through the underlying find-and-modify selection path."

### `insert`
- `ordered`: `status`="effective", `note`="Controls short-circuiting when one insert document fails."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the write command."
- `bypassDocumentValidation`: `status`="effective", `note`="Validated and propagated through command routing."

### `listCollections`
- `filter`: `status`="effective", `note`="Applied to the local namespace snapshot before cursor materialization."
- `nameOnly`: `status`="effective", `note`="Controls the fields exposed by the listCollections cursor."
- `authorizedCollections`: `status`="accepted-noop", `note`="Accepted and type-checked for wire/API parity; local namespace listing does not apply an authorization filter."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the admin read command."

### `listDatabases`
- `filter`: `status`="effective", `note`="Applied to the local database snapshot before materialization."
- `nameOnly`: `status`="effective", `note`="Controls the fields exposed by the listDatabases response."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the admin read command."

### `listIndexes`
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for index administration."

### `killOp`
- `op`: `status`="effective", `note`="Identifies the locally registered operation to cancel on a best-effort basis."
- `comment`: `status`="effective", `note`="Accepted for command parity and recorded in local admin profiling metadata when supplied."

### `profile`
- `slowms`: `status`="effective", `note`="Propagated through the local profiling control path when a profiling level update is requested; status queries also surface current level and entry counts."

### `update`
- `ordered`: `status`="effective", `note`="Controls short-circuiting when one update specification fails."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the write command."
- `let`: `status`="effective", `note`="Command-level bindings are propagated into every update filter through $expr."
- `bypassDocumentValidation`: `status`="effective", `note`="Validated and propagated through replacement/update command routing."
- `arrayFilters`: `status`="effective", `note`="Applied through per-update write execution for supported filtered positional paths."

### `validate`
- `scandata`: `status`="accepted-noop", `note`="Accepted and type-checked; validation reports a warning and performs the same local scan."
- `full`: `status`="accepted-noop", `note`="Accepted and type-checked; validation reports a warning and performs the same local pass."
- `background`: `status`="accepted-noop", `note`="Accepted and type-checked; validation reports a warning and runs synchronously."
- `comment`: `status`="effective", `note`="Recorded in engine session metadata for the validation command."

## CXP Exchange
- `catalog`: `org.mongoeco:mongodb:1.2.0`
- `sha256`: `f2b3d7c51846a00858b4d7c17ae1b439adc0b7285df11f67c291302c0f7013b9`
- `profiles`: `mongodb-core`, `mongodb-text-search`, `mongodb-search`, `mongodb-platform`, `mongodb-aggregate-rich`, `mongodb-mock-safe`

## Mock Safe Profile
- `name`: `mongoeco-mock-safe`
- `description`: `Strict profile for mock/test runtime usage with deterministic local contract expectations for read/write/search/platform tooling.`
- `supported`: `True`
- `recommendedFor`: `mock-runtime-tests`, `contract-gated-tooling`
### Requirements
- `read`: ops=['find', 'find_one', 'count_documents', 'distinct'] metadata=['operationMetadata', 'queryFieldOperators']
- `write`: ops=['insert_one', 'update_one', 'delete_one', 'bulk_write'] metadata=['operationMetadata', 'supportsPipelineUpdate']
- `aggregation`: ops=['aggregate'] metadata=['operationMetadata', 'supportedStages']
- `search`: ops=['aggregate'] metadata=['fieldMappings', 'operationMetadata', 'operators', 'stageOptions']
- `vector_search`: ops=['aggregate'] metadata=['explainFeatures', 'operationMetadata', 'similarities']
- `collation`: ops=[] metadata=['backend', 'capabilities', 'operationMetadata']
- `persistence`: ops=[] metadata=['operationMetadata', 'persistent', 'storageEngine']
- `topology_discovery`: ops=[] metadata=['operationMetadata', 'sdam', 'serverCount', 'topologyType']
### Validation
- `messages`: _empty_
- `findings`: _empty_

## Local Runtime Subsets
### `vectorSearch`
- `similarities`: `cosine`, `dotProduct`, `euclidean`
- `aggregateStage`: `$vectorSearch`
- `backend`: `usearch`
- `mode`: `local-ann-with-exact-baseline`
- `filterMode`: `post-candidate-with-adaptive-candidate-expansion`
- `fallback`: `exact`
- `hybridFilterModes`: `candidate-prefilter`, `candidate-prefilter+post-candidate`, `post-candidate`
- `explainFeatures`: `pathSummary`, `resolvedLeafPaths`, `querySemantics`, `scoreBreakdown`, `candidatePlan`, `hybridRetrieval`, `vectorBackend`
- `operationMetadata`: `{'aggregate': {'supportedOptions': ['allow_disk_use', 'batch_size', 'comment', 'hint', 'let', 'max_time_ms'], 'acceptedNoopOptions': [], 'unsupportedOptions': [], 'supportsExplain': True, 'resultType': 'cursor', 'supportsCollectionScope': True, 'supportsDatabaseScope': False, 'supportsSession': True, 'acceptsPipeline': True, 'aggregateStage': '$vectorSearch', 'similarities': ['cosine', 'dotProduct', 'euclidean'], 'scoreField': 'vectorSearchScore', 'hybridFilterModes': ['candidate-prefilter', 'candidate-prefilter+post-candidate', 'post-candidate'], 'explainFeatures': ['pathSummary', 'resolvedLeafPaths', 'querySemantics', 'scoreBreakdown', 'candidatePlan', 'hybridRetrieval', 'vectorBackend'], 'requiresLeadingStage': True}}`
- `note`: `SQLiteEngine uses a local usearch ANN backend when the vector index is materialized; MemoryEngine remains the exact semantic baseline.`

### `search`
- `operators`: `text`, `phrase`, `autocomplete`, `wildcard`, `exists`, `in`, `equals`, `range`, `near`, `compound`, `regex`
- `aggregateStage`: `$search`
- `fieldMappings`: `autocomplete`, `boolean`, `date`, `document`, `embeddedDocuments`, `number`, `objectId`, `string`, `token`, `uuid`
- `structuredFieldMappings`: `document`, `embeddedDocuments`
- `textualFieldMappings`: `autocomplete`, `string`, `token`
- `exactFilterFieldMappings`: `boolean`, `date`, `number`, `objectId`, `uuid`
- `structuredParentPathOperators`: `text`, `phrase`, `autocomplete`, `wildcard`, `regex`, `exists`
- `explainFeatures`: `pathSummary`, `resolvedLeafPaths`, `structuredParentPathResolution`, `querySemantics`, `stageOptions`, `countPreview`, `highlightPreview`, `facetPreview`
- `operatorSemantics`: `{'text': {'matchingMode': 'tokenized-any-term', 'scope': 'local-text-tier'}, 'phrase': {'matchingMode': 'ordered-token-window', 'supportsSlop': True, 'scope': 'local-text-tier'}, 'autocomplete': {'matchingMode': 'token-prefix', 'tokenization': 'classic-text-local', 'tokenOrder': ['any', 'sequential'], 'scoreModes': ['frequency', 'binary'], 'supportsFuzzy': True, 'fuzzy': {'maxEdits': [1, 2], 'supportsPrefixLength': True, 'supportsMaxExpansions': True}, 'atlasParity': 'subset', 'scope': 'local-text-tier'}, 'wildcard': {'matchingMode': 'glob-local', 'patternSyntax': 'fnmatch-like', 'allowAnalyzedField': True, 'tokenFallbackOnAnalyzedField': True, 'atlasParity': 'subset', 'scope': 'local-text-tier'}, 'regex': {'matchingMode': 'python-regex-local', 'supportsFlags': True, 'supportsOptionsAlias': True, 'supportedFlags': ['a', 'i', 'm', 's', 'u', 'x'], 'allowAnalyzedField': True, 'tokenFallbackOnAnalyzedField': True, 'atlasParity': 'subset', 'scope': 'local-text-tier'}, 'exists': {'matchingMode': 'field-presence', 'scope': 'local-text-tier'}, 'in': {'matchingMode': 'exact-membership', 'scope': 'local-filter-tier'}, 'equals': {'matchingMode': 'exact-equality', 'scope': 'local-filter-tier'}, 'range': {'matchingMode': 'range-comparison', 'scope': 'local-filter-tier'}, 'near': {'matchingMode': 'distance-ranking', 'scope': 'local-filter-tier'}}`
- `textSearchTier`: `closed-local-tier`
- `stageOptions`: `{'count': ['total', 'lowerBound'], 'countOptions': {'supportsThreshold': True, 'thresholdMode': 'lowerBound'}, 'highlight': {'supportsPath': True, 'supportsMaxChars': True, 'supportsMaxNumPassages': True, 'resultField': 'searchHighlights'}, 'facet': {'supportsPath': True, 'supportsNumBuckets': True, 'supportsType': True, 'supportsIncludeMeta': True, 'supportedTypes': ['string', 'number', 'date', 'boolean', 'objectId', 'uuid'], 'supportsCollectorOperator': True, 'collectorOperatorSupports': ['text', 'phrase', 'autocomplete', 'wildcard', 'regex', 'exists', 'in', 'equals', 'range', 'near', 'compound'], 'previewOnly': True}}`
- `advancedAtlasLikeGaps`: `fullFacetCollectorParity`, `fullHighlightParity`, `countMetaParity`, `advancedAutocompleteSemantics`, `advancedWildcardSemantics`, `advancedRegexOptions`
- `sqliteBackends`: `fts5`, `fts5-glob`, `fts5-path`, `fts5-prefilter`, `python`
- `operationMetadata`: `{'aggregate': {'supportedOptions': ['allow_disk_use', 'batch_size', 'comment', 'hint', 'let', 'max_time_ms'], 'acceptedNoopOptions': [], 'unsupportedOptions': [], 'supportsExplain': True, 'resultType': 'cursor', 'supportsCollectionScope': True, 'supportsDatabaseScope': False, 'supportsSession': True, 'acceptsPipeline': True, 'aggregateStage': '$search', 'operators': ['text', 'phrase', 'autocomplete', 'wildcard', 'exists', 'in', 'equals', 'range', 'near', 'compound', 'regex'], 'stageOptions': {'count': ['total', 'lowerBound'], 'countOptions': {'supportsThreshold': True, 'thresholdMode': 'lowerBound'}, 'highlight': {'supportsPath': True, 'supportsMaxChars': True, 'supportsMaxNumPassages': True, 'resultField': 'searchHighlights'}, 'facet': {'supportsPath': True, 'supportsNumBuckets': True, 'supportsType': True, 'supportsIncludeMeta': True, 'supportedTypes': ['string', 'number', 'date', 'boolean', 'objectId', 'uuid'], 'previewOnly': True}}, 'requiresLeadingStage': True}}`
- `note`: `The local textual $search tier is closed in its documented subset; remaining gaps are advanced Atlas-like features.`

### `classicText`
- `supportsTextScore`: `True`
- `supportsMetaProjection`: `True`
- `supportsSortByTextScore`: `True`
- `projectsFromCapability`: `search`
- `note`: `The classic $text subset remains local, token-based and intentionally lighter than MongoDB server full-text behavior.`

### `geospatial`
- `semantics`: `planar-local`
- `storedGeometries`: `Point`, `LineString`, `Polygon`, `MultiPoint`, `MultiLineString`, `MultiPolygon`, `GeometryCollection`, `legacy [x, y]`
- `queryOperators`: `$geoWithin`, `$geoIntersects`, `$near`, `$nearSphere`
- `aggregationStages`: `$geoNear`
- `projectsFromCapability`: `read`
- `note`: `The embedded runtime uses planar local geometry operations. $nearSphere and 2dsphere remain Mongo-like names over local planar distance.`
