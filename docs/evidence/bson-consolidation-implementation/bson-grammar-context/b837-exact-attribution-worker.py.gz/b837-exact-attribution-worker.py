import cProfile
import gc
import hashlib
import json
import os
import pstats
import sys
import threading
import time
from collections import Counter
from pathlib import Path

site, label, output, deadline = sys.argv[1:]
site, output, deadline = Path(site).resolve(), Path(output), float(deadline)
sys.path.insert(0, str(site))
import mongoeco
from bson import BSON, Binary
from mongoeco import MongoClient, SearchIndexModel
from mongoeco.engines import SQLiteEngine
from mongoeco.api.operations import AggregateOperation

assert Path(mongoeco.__file__).resolve().is_relative_to(site)
assert gc.isenabled() and gc.get_threshold() == (2000, 10, 10)
main_thread = threading.get_ident()
reads = 0
results = {}

def check_deadline():
    if time.monotonic() >= deadline:
        raise TimeoutError('60-second global attribution budget exhausted')

def normalize(path):
    return 'mongoeco/' + path.split('/mongoeco/', 1)[1] if '/mongoeco/' in path else path

def profile_case(name, read, expected):
    global reads
    check_deadline()
    assert reads < 300
    actual = read()
    reads += 1
    assert actual == expected
    jobs = Counter()
    worker_cpu = Counter()
    pending = {}
    gc_pending = {}
    gc_events = []
    bind_code = AggregateOperation.bind.__code__

    def observe(frame, event, arg):
        if threading.get_ident() == main_thread:
            return
        code = frame.f_code
        qual = code.co_qualname
        path = code.co_filename
        selected = (
            path.endswith('/engines/_sqlite_reader.py')
            and qual in ('SQLiteScanReader.fetch', 'SQLiteScanReader.close')
        ) or (
            path.endswith('/engines/sqlite.py')
            and qual in ('SQLiteEngine._collection_options_sync', 'SQLiteEngine._search_documents_sync')
        )
        if not selected:
            return
        key = (threading.get_ident(), id(frame))
        if event == 'call':
            jobs[qual] += 1
            pending[key] = (qual, time.thread_time_ns())
        elif event == 'return' and key in pending:
            phase, start = pending.pop(key)
            worker_cpu[phase] += time.thread_time_ns() - start

    def gc_observer(phase, info):
        key = (threading.get_ident(), info['generation'])
        if phase == 'start':
            gc_pending[key] = time.thread_time_ns()
        elif key in gc_pending:
            gc_events.append({
                'generation': info['generation'], 'thread': key[0],
                'thread_cpu_ns': time.thread_time_ns() - gc_pending.pop(key),
                'collected': info['collected'], 'uncollectable': info['uncollectable'],
            })

    profiler = cProfile.Profile(timer=time.process_time_ns, timeunit=1e-9)
    gc.callbacks.append(gc_observer)
    threading.setprofile_all_threads(observe)
    wall, process, main = time.monotonic(), time.process_time_ns(), time.thread_time_ns()
    try:
        profiler.enable()
        for _ in range(99):
            check_deadline()
            assert reads < 300
            actual = read()
            reads += 1
            assert actual == expected
    finally:
        profiler.disable()
        main_ns = time.thread_time_ns() - main
        process_ns = time.process_time_ns() - process
        elapsed = time.monotonic() - wall
        threading.setprofile_all_threads(None)
        gc.callbacks.remove(gc_observer)
    profiler.dump_stats(str(output / (label + '-' + name + '.pstats')))
    functions = []
    selected = Counter()
    bind_key = (bind_code.co_filename, bind_code.co_firstlineno, bind_code.co_name)
    for key, value in pstats.Stats(profiler).stats.items():
        path, line, function = key
        primitive, calls, own, total, _ = value
        functions.append({'path': normalize(path), 'line': line, 'function': function,
                          'primitive_calls': primitive, 'calls_or_resumptions': calls,
                          'self_cpu_seconds': own, 'inclusive_cpu_seconds': total})
        if key == bind_key:
            selected['AggregateOperation.bind'] += calls
        if function in ('_scan_with_effective_collation', '_open_source', '_resolve_operation_context', '_run_once', 'prepare_pipeline', 'score_vector_document', 'deepcopy', '_close_retired_sources', 'finish_cleanup'):
            selected[function] += calls
    functions.sort(key=lambda row: row['self_cpu_seconds'], reverse=True)
    (output / (label + '-' + name + '-functions.json')).write_text(json.dumps(functions, indent=2))
    assert not pending and not gc_pending
    assert gc.isenabled()
    results[name] = {
        'reads': 100, 'preparation_reads': 1, 'profiled_reads': 99,
        'process_cpu_ns': process_ns, 'main_thread_cpu_ns': main_ns,
        'wall_seconds': elapsed, 'jobs': dict(jobs),
        'worker_selected_inclusive_cpu_ns': dict(worker_cpu),
        'gc_events': gc_events, 'gc_thread_cpu_ns': sum(e['thread_cpu_ns'] for e in gc_events),
        'gc_enabled_after': gc.isenabled(), 'pending_phase_entries': len(pending),
        'actual_bson_sha256': hashlib.sha256(BSON.encode({'rows': actual})).hexdigest(),
        'selected_profile_calls_or_resumptions': dict(selected),
    }
    (output / ('result-' + label + '.json')).write_text(json.dumps({
        'label': label, 'source_root': str(site), 'mongoeco_file': mongoeco.__file__,
        'python': sys.version, 'gc_enabled': gc.isenabled(), 'gc_thresholds': gc.get_threshold(),
        'clock': {'profile': 'time.process_time_ns, scale 1e-9', 'main_and_worker': 'time.thread_time_ns', 'deadline': 'time.monotonic'},
        'reads': reads, 'cases': results,
    }, indent=2))

from mongoeco.types import CodecOptions, UuidRepresentation
with MongoClient(SQLiteEngine()) as client:
    collection = client.cost.rows
    collection.insert_many([{'_id': n, 'n': n, 'p': 'x' * 4096} for n in range(200)])
    c = collection.with_options(codec_options=CodecOptions(uuid_representation=UuidRepresentation.STANDARD))
    def aggregate_page():
        cursor = c.aggregate([{'$sort': {'_id': 1}}])
        try:
            return cursor.to_list(1)
        finally:
            cursor.close()
    profile_case('standard-aggregate-first-page', aggregate_page, [{'_id': 0, 'n': 0, 'p': 'x' * 4096}])
assert reads == 100
check_deadline()
