import os,subprocess,sys
from pathlib import Path
v=os.environ['MONGOECO_REAL_MONGODB_TARGET']; suffix=v.replace('.','_')
for case_set,key in [('bson-grammar-context','bson_grammar_context'),('dbref-grammar','dbref_grammar')]:
 reference=f'tests/fixtures/semantic_{key}_{suffix}.json'
 if key=='bson_grammar_context':
  subprocess.run([sys.executable,'scripts/capture_differential_replay_golden.py','--target',v,'--case-set',case_set,'--output',reference],check=True)
 subprocess.run([sys.executable,'scripts/capture_differential_replay_golden.py','--target',v,'--case-set',case_set,'--output',f'/tmp/mongoeco-grammar-native-final/{v}/{key}-check.json','--check',reference],check=True)
