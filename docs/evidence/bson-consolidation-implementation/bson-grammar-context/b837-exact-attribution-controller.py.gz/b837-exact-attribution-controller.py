import os,sys,time,json,subprocess,tempfile,hashlib
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='mongoeco-f11-exact-attribution-'));Path('/tmp/mongoeco-f11-exact-attribution-location.txt').write_text(str(root))
roots={'A':Path('/var/folders/gh/m3pllfqn6m14srd4s448b0zw0000gn/T/mongoeco-dispatch-wheel-hbjagp_l'),'D':Path('/var/folders/gh/m3pllfqn6m14srd4s448b0zw0000gn/T/mongoeco-f11-b837-hy0s32_m')}
worker=Path('/tmp/mongoeco-f11-exact-attribution-worker.py');before={}
for r in roots.values():
 info=json.loads((r/'wheel.json').read_text());site=Path(info['site_packages'])
 for p,h in json.loads((r/'runtime.json').read_text()).items():
  path=site/p.removeprefix('src/');assert hashlib.sha256(path.read_bytes()).hexdigest()==h;before[str(path)]=h
result={'max_reads':200,'wall_budget_seconds':60,'workers_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'comparison':'installed 2fa637f6 versus installed b83789bc; exact standard aggregate-first-page, isolated fresh collection per revision; no prior mode warmups','returncodes':{},'results':{}}
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0');env.pop('PYTHONPATH',None);tick=time.monotonic();deadline=tick+60
try:
 for label,r in roots.items():
  site=json.loads((r/'wheel.json').read_text())['site_packages']
  with (root/f'stderr-{label}.txt').open('w') as err:
   rc=subprocess.run([sys.executable,str(worker),site,label,str(root),str(deadline)],cwd='/tmp',env=env,stdout=subprocess.DEVNULL,stderr=err,timeout=max(.001,deadline-time.monotonic())).returncode
  result['returncodes'][label]=rc;assert rc==0,label
  result['results'][label]=json.loads((root/f'result-{label}.json').read_text())
finally:
 result['elapsed_wall_seconds']=time.monotonic()-tick;result['reads']=sum(v['reads'] for v in result['results'].values());result['frozen_modules_unchanged']=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items());(root/'execution.json').write_text(json.dumps(result,indent=2));print(json.dumps({'root':str(root),'elapsed':result['elapsed_wall_seconds'],'reads':result['reads'],'unchanged':result['frozen_modules_unchanged']}))
assert result['reads']==200 and result['elapsed_wall_seconds']<60 and result['frozen_modules_unchanged']
