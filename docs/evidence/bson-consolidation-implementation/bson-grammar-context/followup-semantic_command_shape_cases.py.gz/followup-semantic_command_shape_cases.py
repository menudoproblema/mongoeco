"""Native disposition of the command shapes retained by the final gate."""

SEED = [{"_id": 0}]
COMMANDS = [
    {"createIndexes": "events", "indexes": ()},
    {"distinct": "events", "key": 1},
    {"dropIndexes": "events", "index": 1.5},
    {"listDatabases": 1, "nameOnly": 1},
    {"listCollections": 1, "nameOnly": 1},
    {"listCollections": 1, "authorizedCollections": 1},
    {"count": "events", "skip": -1},
    {"count": "events", "limit": -1},
    {"dbStats": 1, "scale": 0},
    {"collStats": "events", "scale": -1},
    {"insert": "events", "documents": {}},
    {"update": "events", "updates": {}},
    {"delete": "events", "deletes": {}},
    {"find": "events", "batchSize": -1},
    {"aggregate": "events", "pipeline": [], "cursor": 1},
    {"aggregate": "events", "pipeline": [], "allowDiskUse": 1},
    {"aggregate": "events", "pipeline": [], "let": 1},
    {"explain": 1},
    {"explain": {"find": "events"}, "verbosity": 1},
    {"connectionStatus": 1, "showPrivileges": 1},
    {"find": "events", "projection": 1},
    {"find": "events", "sort": 1},
    {"count": "events", "query": 1},
    {"distinct": "events", "key": ""},
    {"listCollections": 1, "comment": 1},
    {"listIndexes": "events", "comment": 1},
    {"validate": "events", "comment": 1},
    {"validate": "events", "background": "yes"},
    {
        "findAndModify": "events",
        "query": {},
        "update": {"$set": {"done": True}},
        "let": 1,
    },
    {"findAndModify": "events"},
    {"explain": {"distinct": "events", "key": ""}},
    {"explain": {"update": "events", "updates": []}},
]


def command_shape_contract(collection):
    output = {}
    # These shapes originally target an absent namespace. Keep it independent
    # of the capturer's seed and compare operation identity without volatile data.
    for index, spec in enumerate(COMMANDS):
        try:
            collection.database.command(spec)
            output[str(index)] = {"ok": True}
        except Exception as error:
            output[str(index)] = {
                "ok": False,
                "family": type(error).__name__,
                "code": getattr(error, "code", None),
            }
    output["recovery"] = collection.database.command({"ping": 1})["ok"]
    return output


SEMANTIC_COMMAND_SHAPE_CASES = (
    ("semantic_command_shape_contract", command_shape_contract),
)
