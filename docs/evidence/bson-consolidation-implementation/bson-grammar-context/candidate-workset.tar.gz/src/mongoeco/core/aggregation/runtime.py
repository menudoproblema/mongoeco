import base64
import datetime
import decimal
import math
import re
import uuid

from collections.abc import Callable, Mapping
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from mongoeco.compat import MONGODB_DIALECT_70, MongoDialect
from mongoeco.core.aggregation.accumulators import _evaluate_pick_n_input
from mongoeco.core.aggregation.array_string_expressions import (
    ARRAY_STRING_EXPRESSION_OPERATORS,
    evaluate_array_string_expression,
)
from mongoeco.core.aggregation.control_object_expressions import (
    CONTROL_OBJECT_EXPRESSION_OPERATORS,
    evaluate_control_object_expression,
)
from mongoeco.core.aggregation.date_expressions import (
    DATE_EXPRESSION_OPERATORS,
    evaluate_date_expression,
)
from mongoeco.core.aggregation.evaluation_environment import (
    aggregation_environment,
    environment_for_document,
)
from mongoeco.core.aggregation.expression_values import (
    MISSING as _MISSING,
    compare_expression_values,
    expression_values_equal,
    null_if_missing,
)
from mongoeco.core.aggregation.extensions import (
    AggregationExpressionExtensionContext,
    get_registered_aggregation_expression_operator,
)
from mongoeco.core.aggregation.numeric_expressions import (
    NUMERIC_EXPRESSION_OPERATORS,
    _add_milliseconds as _add_milliseconds,  # noqa: PLC0414 - private compatibility export
    _subtract_values as _subtract_values,  # noqa: PLC0414 - private compatibility export
    evaluate_numeric_expression,
)
from mongoeco.core.aggregation.planning import Pipeline
from mongoeco.core.aggregation.scalar_expressions import (
    SCALAR_EXPRESSION_OPERATORS,
    evaluate_scalar_expression,
)
from mongoeco.core.aggregation.spill import AggregationSpillPolicy
from mongoeco.core.bson_ordering import Code, bson_engine_key, bson_equality_key
from mongoeco.core.bson_values import is_bson_string
from mongoeco.core.bson_scalars import (
    BsonInt64,
    bson_numeric_alias,
    is_bson_numeric,
)
from mongoeco.core.bson_size import (
    bson_cstring_size as _bson_cstring_size,  # noqa: F401 - private compatibility export
    bson_document_size as _bson_document_size,
    bson_element_size as _bson_element_size,  # noqa: F401 - private compatibility export
    bson_string_size as _bson_string_size,  # noqa: F401 - private compatibility export
    bson_value_size as _bson_value_size,  # noqa: F401 - private compatibility export
)
from mongoeco.core.collation import (
    CollationSpec,
    string_equality_key,
)
from mongoeco.core.filtering import QueryEngine
from mongoeco.core.paths import (
    delete_document_value,
    get_document_value,
    set_document_value,
)
from mongoeco.core.runtime_metadata import (
    RuntimeDocumentState,
    RuntimeMetadataKey,
)
from mongoeco.core.search import (
    SEARCH_HIGHLIGHTS_METADATA_FIELD,
    TEXT_SCORE_FIELD,
    VECTOR_SEARCH_SCORE_FIELD,
)
from mongoeco.core.server_errors import server_error
from mongoeco.core.work_control import DeadlineCheckpoint
from mongoeco.errors import OperationFailure
from mongoeco.types import (
    Binary,
    DBRef,
    Decimal128,
    Document,
    ObjectId,
    Regex,
    Timestamp,
)


type AggregationStageHandler = Callable[
    [list[Document], object, "AggregationStageContext"],
    list[Document],
]

_CURRENT_COLLECTION_RESOLVER_KEY = "__mongoeco_current_collection__"


def _aggregation_key(value: Any) -> Any:
    if value is None:
        return ("none", None)
    if isinstance(value, bool):
        return ("bool", value)
    numeric_alias = bson_numeric_alias(value)
    if numeric_alias == "int":
        return ("int", value)
    if numeric_alias == "long":
        return ("long", value)
    if numeric_alias == "double":
        return ("float", value)
    if numeric_alias == "decimal":
        return ("decimal", value)
    if isinstance(value, Code):
        return bson_engine_key(value)
    if isinstance(value, str):
        return ("str", value)
    if isinstance(value, (bytes, Binary)):
        return ("bytes", value)
    if isinstance(value, uuid.UUID):
        return ("uuid", value)
    if isinstance(value, ObjectId):
        return ("objectid", value)
    if isinstance(value, datetime.datetime):
        return ("datetime", value)
    if isinstance(value, Timestamp):
        return ("timestamp", value)
    if isinstance(value, dict):
        return (
            "dict",
            tuple((key, _aggregation_key(item)) for key, item in value.items()),
        )
    if isinstance(value, list):
        return ("list", tuple(_aggregation_key(item) for item in value))
    try:
        hash(value)
        return (value.__class__, value)
    except TypeError:
        raise OperationFailure(
            "$group _id must resolve to BSON-compatible values",
        )


@dataclass(frozen=True, slots=True)
class AggregationStageContext:
    stage_index: int
    collection_resolver: Callable[[str], list[Document]] | None = None
    collection_stats_resolver: Callable[[int], Document] | None = None
    index_stats_resolver: Callable[[], list[Document]] | None = None
    current_op_resolver: Callable[[], list[Document]] | None = None
    plan_cache_stats_resolver: Callable[[], list[Document]] | None = None
    list_sessions_resolver: Callable[[], list[Document]] | None = None
    variables: Mapping[str, Any] | None = None
    dialect: MongoDialect = MONGODB_DIALECT_70
    collation: CollationSpec | None = None
    spill_policy: AggregationSpillPolicy | None = None
    lookup_hash_max_associations: int | None = None
    deadline: float | None = None

    group_average_uses_sum: bool = False

def aggregation_equality_key(value: Any, collation: CollationSpec | None = None) -> Any:
    """Semantic group identity, independent of physical numeric representation."""
    value = null_if_missing(value)
    if is_bson_numeric(value):
        return bson_equality_key(value)
    if isinstance(value, Code):
        return bson_engine_key(value)
    if isinstance(value, str):
        return ("str", string_equality_key(value, collation))
    if isinstance(value, dict):
        return (
            "dict",
            tuple(
                (key, aggregation_equality_key(item, collation))
                for key, item in value.items()
            ),
        )
    if isinstance(value, list):
        return (
            "list",
            tuple(aggregation_equality_key(item, collation) for item in value),
        )
    _aggregation_key(value)  # Preserve rejection of non-BSON, unhashable scalars.
    return bson_equality_key(value)


def _require_unwind_spec(spec: object) -> tuple[str, bool, str | None]:
    if isinstance(spec, str):
        path = spec
        preserve = False
        include_array_index = None
    elif isinstance(spec, dict):
        path = spec.get("path")
        preserve = bool(spec.get("preserveNullAndEmptyArrays", False))
        include_array_index = spec.get("includeArrayIndex")
        if include_array_index is not None and not isinstance(
            include_array_index,
            str,
        ):
            raise OperationFailure(
                "$unwind includeArrayIndex must be a string",
            )
    else:
        raise OperationFailure("$unwind requires a path string or document")

    if not isinstance(path, str) or not path.startswith("$") or path == "$":
        raise OperationFailure(
            "$unwind path must be a string starting with '$'",
        )

    if include_array_index is not None and include_array_index.startswith("$"):
        raise OperationFailure(
            "$unwind includeArrayIndex must be a field name, not a path expression",
        )

    return path[1:], preserve, include_array_index


def _require_lookup_spec(spec: object) -> dict[str, Any]:
    if not isinstance(spec, dict):
        raise OperationFailure("$lookup requires a document specification")
    if set(spec) - {"from", "as", "localField", "foreignField", "let", "pipeline"}:
        raise OperationFailure("$lookup contains unsupported arguments")
    documents_source = (
        isinstance(spec.get("pipeline"), list)
        and bool(spec["pipeline"])
        and isinstance(spec["pipeline"][0], dict)
        and "$documents" in spec["pipeline"][0]
    )
    if ("from" not in spec and not documents_source) or "as" not in spec:
        raise OperationFailure("$lookup requires from and as")
    from_collection = spec.get("from")
    if "from" in spec and from_collection is None:
        raise OperationFailure("$lookup from and as must be non-empty strings")
    output_field = spec["as"]
    if not all(
        isinstance(value, str) and value
        for value in (
            (from_collection, output_field)
            if from_collection is not None
            else (output_field,)
        )
    ):
        raise OperationFailure("$lookup from and as must be non-empty strings")
    if from_collection is not None and from_collection.startswith("$"):
        raise OperationFailure(
            "$lookup from must be a collection name, not a path expression",
        )
    if output_field.startswith("$"):
        raise OperationFailure(
            "$lookup as must be a field name, not a path expression",
        )

    if "pipeline" in spec:
        let_spec = spec.get("let", {})
        if not isinstance(let_spec, dict):
            raise OperationFailure("$lookup let must be a document")
        for name in let_spec:
            if not isinstance(name, str) or not re.fullmatch(
                r"(?:[a-z]|[^\x00-\x7f])(?:[A-Za-z0-9_]|[^\x00-\x7f])*", name
            ):
                message = (
                    "$lookup let variable names must begin with a lowercase "
                    "letter or non-ascii character"
                )
                raise OperationFailure(message)
        lookup = {
            "from": from_collection,
            "as": output_field,
            "pipeline": _require_pipeline_spec("$lookup", spec["pipeline"]),
            "let": let_spec,
        }
        has_local = "localField" in spec
        has_foreign = "foreignField" in spec
        if has_local != has_foreign:
            raise OperationFailure(
                "$lookup localField and foreignField must be provided together",
            )
        if has_local:
            local_field, foreign_field = _require_lookup_fields(spec)
            lookup["localField"] = local_field
            lookup["foreignField"] = foreign_field
        return lookup

    required = {"from", "localField", "foreignField", "as"}
    if not required <= set(spec):
        raise OperationFailure(
            "$lookup requires from, localField, foreignField and as",
        )
    if "let" in spec:
        message = "$lookup let requires pipeline form"
        raise OperationFailure(message)
    local_field, foreign_field = _require_lookup_fields(spec)
    return {
        "from": from_collection,
        "as": output_field,
        "localField": local_field,
        "foreignField": foreign_field,
    }


def _require_lookup_fields(spec):
    local_field = spec["localField"]
    foreign_field = spec["foreignField"]
    if not all(
        isinstance(value, str) and value for value in (local_field, foreign_field)
    ):
        message = "$lookup fields must be non-empty strings"
        raise OperationFailure(message)
    if local_field.startswith("$") or foreign_field.startswith("$"):
        message = (
            "$lookup localField and foreignField must be field paths, "
            "not path expressions"
        )
        raise OperationFailure(message)
    return local_field, foreign_field


def _require_union_with_spec(spec: object) -> dict[str, Any]:
    if isinstance(spec, str):
        if not spec:
            raise OperationFailure(
                "$unionWith collection name must be a non-empty string",
            )
        spec = {"coll": spec}
    if not isinstance(spec, dict):
        raise OperationFailure(
            "$unionWith requires a collection name string or a document specification",
        )
    pipeline = spec.get("pipeline", [])
    if "pipeline" in spec:
        pipeline = _require_pipeline_spec("$unionWith", pipeline)
    coll = spec.get("coll")
    if coll is not None:
        if not isinstance(coll, str) or not coll:
            raise OperationFailure(
                "$unionWith coll must be a non-empty string",
            )
        if coll.startswith("$"):
            raise OperationFailure(
                "$unionWith coll must be a collection name, not a path expression",
            )
    elif "pipeline" not in spec:
        raise OperationFailure("$unionWith requires coll or pipeline")
    if set(spec) - {"coll", "pipeline"}:
        raise OperationFailure("$unionWith only supports coll and pipeline")
    return {"coll": coll, "pipeline": pipeline}


def _require_pipeline_spec(operator: str, spec: object) -> Pipeline:
    if not isinstance(spec, list):
        raise OperationFailure(f"{operator} requires a pipeline list")
    return spec


def _apply_unwind(
    documents: list[Document],
    spec: object,
    *,
    deadline: float | None = None,
) -> list[Document]:
    path, preserve, include_array_index = _require_unwind_spec(spec)
    result: list[Document] = []
    checkpoint = DeadlineCheckpoint(deadline)
    for document in documents:
        checkpoint()
        found, value = get_document_value(document, path)
        if not found or value is None:
            if preserve:
                preserved = deepcopy(document)
                if include_array_index is not None:
                    preserved[include_array_index] = None
                result.append(preserved)
            continue

        if isinstance(value, list):
            if not value:
                if preserve:
                    preserved = deepcopy(document)
                    delete_document_value(preserved, path)
                    if include_array_index is not None:
                        preserved[include_array_index] = None
                    result.append(preserved)
                continue
            for index, item in enumerate(value):
                checkpoint()
                unwound = deepcopy(document)
                set_document_value(unwound, path, item)
                if include_array_index is not None:
                    unwound[include_array_index] = BsonInt64(index)
                result.append(unwound)
            continue

        unwound = deepcopy(document)
        if include_array_index is not None:
            unwound[include_array_index] = None
        result.append(unwound)
    return result


def _lookup_matches(
    local_values: list[Any],
    foreign_values: list[Any],
    *,
    dialect: MongoDialect = MONGODB_DIALECT_70,
    collation: CollationSpec | None = None,
) -> bool:
    left = local_values or [None]
    right = foreign_values or [None]
    return any(
        QueryEngine._query_equality_matches(
            local_value,
            foreign_value,
            null_matches_undefined=dialect.policy.null_query_matches_undefined(),
            dialect=dialect,
            collation=collation,
        )
        for local_value in left
        for foreign_value in right
    )


def _require_expression_args(
    operator: str,
    spec: object,
    *,
    min_args: int,
    max_args: int | None = None,
) -> list[object]:
    args = spec if isinstance(spec, list) else [spec]
    count = len(args)
    if count < min_args or (max_args is not None and count > max_args):
        if operator == "$ifNull":
            message = f"$ifNull needs at least two arguments, had: {count}"
            raise server_error(message, code=1257300, reason="expression_arity")
        if min_args == max_args:
            requirement = f"exactly {min_args}"
        elif max_args is None:
            requirement = f"at least {min_args}"
        else:
            requirement = f"at least {min_args} and at most {max_args}"
        message = (
            f"Expression {operator} takes {requirement} arguments. "
            f"{count} were passed in."
        )
        raise server_error(message, code=16020, reason="expression_arity")
    return args


def _compare_values(
    left: Any,
    right: Any,
    operator: str,
    *,
    dialect: MongoDialect = MONGODB_DIALECT_70,
    collation: CollationSpec | None = None,
) -> bool:
    if operator in {"$eq", "$ne"}:
        equal = expression_values_equal(
            left, right, dialect=dialect, collation=collation
        )
        return equal if operator == "$eq" else not equal
    comparison = compare_expression_values(
        left, right, dialect=dialect, collation=collation
    )
    return {
        "$gt": comparison > 0,
        "$gte": comparison >= 0,
        "$lt": comparison < 0,
        "$lte": comparison <= 0,
    }[operator]


def _require_array(operator: str, value: object) -> list[Any]:
    if not isinstance(value, list):
        message = f"{operator} requires array arguments"
        raise server_error(
            message,
            code=40081 if operator == "$in" else 28664,
        )
    return value


def _expression_truthy(value: Any, *, dialect: MongoDialect) -> bool:
    return value is not _MISSING and dialect.policy.expression_truthy(value)


def _append_unique_values(
    target: list[Any],
    values: list[Any],
    *,
    dialect: MongoDialect = MONGODB_DIALECT_70,
    collation: CollationSpec | None = None,
) -> None:
    for value in values:
        if any(
            QueryEngine._values_equal(
                value,
                existing,
                dialect=dialect,
                collation=collation,
            )
            for existing in target
        ):
            continue
        target.append(deepcopy(value))


def _parse_variable_reference(expression: str) -> tuple[str, str]:
    name, _, path = expression[2:].partition(".")
    if not name:
        message = "empty variable names are not allowed"
        raise OperationFailure(
            message,
            code=9,
            details={"codeName": "FailedToParse"},
        )
    if not ((name[0].isascii() and name[0].isalpha()) or not name[0].isascii()):
        message = f"'{name}' starts with an invalid character for a variable name"
        raise OperationFailure(
            message,
            code=9,
            details={"codeName": "FailedToParse"},
        )
    for character in name:
        if character.isascii() and not (character.isalnum() or character == "_"):
            message = f"'{name}' contains an invalid character for a variable name"
            raise OperationFailure(
                message,
                code=9,
                details={"codeName": "FailedToParse"},
            )
    return name, path


def _validate_variable_path(expression, path):
    # Undefined variables fail before their path is parsed by the server.
    if "." not in expression:
        return
    if expression.endswith("."):
        code, message = 40353, "FieldPath must not end with a '.'"
    elif any(not part for part in path.split(".")):
        code, message = 15998, "FieldPath field names may not be empty strings"
    elif any(part.startswith("$") for part in path.split(".")):
        code, message = 16410, "FieldPath field names may not start with '$'"
    elif "\x00" in path:
        code, message = 16411, "FieldPath field names may not contain null bytes"
    else:
        return
    raise server_error(message, code=code)


def _resolve_variable_expression(
    expression: str,
    variables: Mapping[str, Any],
    *,
    dialect: MongoDialect = MONGODB_DIALECT_70,
) -> Any:
    name, path = _parse_variable_reference(expression)
    if name in getattr(variables, "unavailable_system_variables", ()):
        message = f"Builtin variable '$${name}' is not available"
        raise server_error(message, code=51144)
    if name == "CLUSTER_TIME":
        message = (
            "Builtin variable '$$CLUSTER_TIME' is not available on a standalone runtime"
        )
        code = (
            10071200
            if dialect.behavior_flag("rejects_cluster_time_expression", default=False)
            else 51144
        )
        raise server_error(message, code=code, reason="cluster_time_unavailable")
    if name != "REMOVE" and name not in variables:
        raise OperationFailure(
            f"Use of undefined variable: {name}",
            code=17276,
            details={
                "ok": 0.0,
                "code": 17276,
                "codeName": "Location17276",
                "errmsg": f"Use of undefined variable: {name}",
            },
        )
    _validate_variable_path(expression, path)
    if name == "REMOVE":
        return _REMOVE if not path else _MISSING
    value = variables[name]
    if not path:
        return value
    return _resolve_aggregation_field_path(value, path)


def _variables_for_document(
    document: Document | RuntimeDocumentState,
    variables: Mapping[str, Any] | None,
) -> dict[str, Any]:
    return environment_for_document(
        document.public_document()
        if isinstance(document, RuntimeDocumentState)
        else document,
        variables,
    )


# $$REMOVE evaluates to the same missing value as an absent field.
_REMOVE = _MISSING


def _resolve_aggregation_field_path(value: Any, path: str) -> Any:
    if not path:
        return value

    if isinstance(value, DBRef):
        return _resolve_aggregation_field_path(value.as_document(), path)

    if isinstance(value, RuntimeDocumentState):
        found, resolved = value.resolve(path)
        return resolved if found else _MISSING

    if isinstance(value, list):
        head, _, tail = path.partition(".")
        if head.startswith("-") and head[1:].isdigit():
            return _MISSING
        if head.isdigit():
            index = int(head)
            if index >= len(value):
                return _MISSING
            next_value = value[index]
            return _resolve_aggregation_field_path(next_value, tail)

        resolved_items: list[Any] = []
        for item in value:
            resolved = _resolve_aggregation_field_path(item, path)
            if resolved is _MISSING:
                continue
            resolved_items.append(resolved)
        return resolved_items

    if not isinstance(value, dict):
        return _MISSING

    head, _, tail = path.partition(".")
    if head not in value:
        return _MISSING
    field_value = value[head]
    return _resolve_aggregation_field_path(field_value, tail)


def _mongo_mod(left: float, right: float) -> int | float:
    if not math.isfinite(left) or not math.isfinite(right):
        return math.nan
    quotient = int(left / right)
    return left - right * quotient


def _stringify_aggregation_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, Decimal128):
        return str(value)
    if isinstance(value, decimal.Decimal):
        return format(value, "f")
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN"
        if math.isinf(value):
            return "Infinity" if value > 0 else "-Infinity"
    if isinstance(value, datetime.datetime):
        normalized = (
            value.astimezone(datetime.UTC) if value.tzinfo is not None else value
        )
        return normalized.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    if isinstance(value, (bytes, bytearray, Binary)):
        return base64.b64encode(bytes(value)).decode("ascii")
    if isinstance(value, Regex):
        return f"/{value.pattern}/{value.flags}"
    if isinstance(value, Timestamp):
        return f"Timestamp({value.time}, {value.inc})"
    return str(value)


def _normalize_numeric_place(operator: str, place: Any) -> int:
    if not isinstance(place, int) or isinstance(place, bool):
        raise OperationFailure(f"{operator} place must be an integer")
    if place < -20 or place > 100:
        raise OperationFailure(f"{operator} place must be between -20 and 100")
    return place


def _round_numeric(value: float, place: int) -> int | float:
    if isinstance(value, int) and place >= 0:
        return value
    quantizer = decimal.Decimal(f"1e{-place}")
    rounded = decimal.Decimal(str(value)).quantize(
        quantizer,
        rounding=decimal.ROUND_HALF_EVEN,
    )
    return int(rounded) if place <= 0 else float(rounded)


def _trunc_numeric(value: float, place: int) -> int | float:
    if isinstance(value, int) and place >= 0:
        return value
    factor = 10**place if place >= 0 else 10 ** (-place)
    if place >= 0:
        truncated = math.trunc(value * factor) / factor
        return int(truncated) if place == 0 else truncated
    truncated = math.trunc(value / factor) * factor
    return int(truncated)


def _evaluate_expression_with_missing(
    document: Document,
    expression: object,
    variables: Mapping[str, Any] | None = None,
    *,
    dialect: MongoDialect = MONGODB_DIALECT_70,
) -> Any:
    return evaluate_expression(document, expression, variables, dialect=dialect)


def _evaluate_nullable_expression(document, expression, variables=None, *, dialect):
    return null_if_missing(
        evaluate_expression(document, expression, variables, dialect=dialect)
    )


def evaluate_expression(
    document: Document | RuntimeDocumentState,
    expression: object,
    variables: Mapping[str, Any] | None = None,
    *,
    dialect: MongoDialect = MONGODB_DIALECT_70,
    collation: CollationSpec | None = None,
) -> Any:
    if collation is not None:
        variables = aggregation_environment(variables, collation)
    variables = _variables_for_document(document, variables)

    if is_bson_string(expression):
        if expression.startswith("$$"):
            return _resolve_variable_expression(expression, variables, dialect=dialect)
        if expression.startswith("$"):
            return _resolve_aggregation_field_path(variables["CURRENT"], expression[1:])
        return expression

    if isinstance(expression, list):
        return [
            null_if_missing(evaluate_expression(document, item, variables, dialect=dialect))
            for item in expression
        ]

    if not isinstance(expression, dict):
        return expression

    if len(expression) > 1 and any(
        isinstance(key, str) and key.startswith("$") for key in expression
    ):
        message = "An expression specification must contain exactly one field"
        raise server_error(message, code=40181)

    if len(expression) == 1:
        operator, spec = next(iter(expression.items()))
        if isinstance(operator, str) and operator.startswith("$"):
            extension_handler = get_registered_aggregation_expression_operator(
                operator,
            )
            if extension_handler is not None:
                return extension_handler(
                    document,
                    spec,
                    variables,
                    dialect,
                    AggregationExpressionExtensionContext(
                        evaluate_expression=lambda current_document, current_expression, current_variables=None: (
                            evaluate_expression(
                                current_document,
                                current_expression,
                                current_variables,
                                dialect=dialect,
                            )
                        ),
                        evaluate_expression_with_missing=lambda current_document, current_expression, current_variables=None: (
                            _evaluate_expression_with_missing(
                                current_document,
                                current_expression,
                                current_variables,
                                dialect=dialect,
                            )
                        ),
                        require_expression_args=lambda current_operator, current_spec, current_min_args, current_max_args=None: (
                            _require_expression_args(
                                current_operator,
                                current_spec,
                                min_args=current_min_args,
                                max_args=current_max_args,
                            )
                        ),
                        missing_sentinel=_MISSING,
                    ),
                )
            if operator == "$meta":
                if isinstance(document, RuntimeDocumentState):
                    metadata_keys = {
                        "textScore": RuntimeMetadataKey.TEXT_SCORE,
                        "vectorSearchScore": RuntimeMetadataKey.VECTOR_SEARCH_SCORE,
                        "searchHighlights": RuntimeMetadataKey.SEARCH_HIGHLIGHTS,
                    }
                    key = metadata_keys.get(spec)
                    if key is not None:
                        found, value = document.metadata_value(key)
                        return None if not found else value
                if spec == "textScore":
                    found, value = get_document_value(
                        document,
                        TEXT_SCORE_FIELD,
                    )
                    return None if not found else deepcopy(value)
                if spec == "vectorSearchScore":
                    found, value = get_document_value(
                        document,
                        VECTOR_SEARCH_SCORE_FIELD,
                    )
                    return None if not found else deepcopy(value)
                if spec == "searchHighlights":
                    found, value = get_document_value(
                        document,
                        SEARCH_HIGHLIGHTS_METADATA_FIELD,
                    )
                    return None if not found else deepcopy(value)
                raise OperationFailure(
                    "$meta aggregation expression only supports "
                    "searchHighlights, textScore or vectorSearchScore",
                )
            if operator not in {"$literal", "$const"} and not dialect.supports_aggregation_expression_operator(operator):
                raise server_error(
                    f"Unrecognized expression '{operator}'",
                    code=168,
                )
            if operator in {"$literal", "$const"}:
                return deepcopy(spec)
            if operator in SCALAR_EXPRESSION_OPERATORS:
                return evaluate_scalar_expression(
                    operator,
                    document,
                    spec,
                    variables,
                    dialect=dialect,
                    evaluate_expression=lambda d, e, v=None: (
                        _evaluate_nullable_expression(d, e, v, dialect=dialect)
                    ),
                    evaluate_expression_with_missing=lambda current_document, current_expression, current_variables=None: (
                        _evaluate_expression_with_missing(
                            current_document,
                            current_expression,
                            current_variables,
                            dialect=dialect,
                        )
                    ),
                    require_expression_args=lambda current_operator, current_spec, current_min_args, current_max_args=None: (
                        _require_expression_args(
                            current_operator,
                            current_spec,
                            min_args=current_min_args,
                            max_args=current_max_args,
                        )
                    ),
                    stringify_value=_stringify_aggregation_value,
                    bson_document_size=_bson_document_size,
                    missing_sentinel=_MISSING,
                )
            if operator in ARRAY_STRING_EXPRESSION_OPERATORS:
                return evaluate_array_string_expression(
                    operator,
                    document,
                    spec,
                    variables,
                    dialect=dialect,
                    evaluate_expression=lambda d, e, v=None: (
                        _evaluate_nullable_expression(d, e, v, dialect=dialect)
                    ),
                    evaluate_expression_with_missing=lambda current_document, current_expression, current_variables=None: (
                        _evaluate_expression_with_missing(
                            current_document,
                            current_expression,
                            current_variables,
                            dialect=dialect,
                        )
                    ),
                    require_expression_args=lambda current_operator, current_spec, current_min_args, current_max_args=None: (
                        _require_expression_args(
                            current_operator,
                            current_spec,
                            min_args=current_min_args,
                            max_args=current_max_args,
                        )
                    ),
                    missing_sentinel=_MISSING,
                )
            if operator in CONTROL_OBJECT_EXPRESSION_OPERATORS:
                return evaluate_control_object_expression(
                    operator,
                    document,
                    spec,
                    variables,
                    dialect=dialect,
                    evaluate_expression=lambda current_document, current_expression, current_variables=None: (
                        evaluate_expression(
                            current_document,
                            current_expression,
                            current_variables,
                            dialect=dialect,
                        )
                    ),
                    evaluate_expression_with_missing=lambda current_document, current_expression, current_variables=None: (
                        _evaluate_expression_with_missing(
                            current_document,
                            current_expression,
                            current_variables,
                            dialect=dialect,
                        )
                    ),
                    require_expression_args=lambda current_operator, current_spec, current_min_args, current_max_args=None: (
                        _require_expression_args(
                            current_operator,
                            current_spec,
                            min_args=current_min_args,
                            max_args=current_max_args,
                        )
                    ),
                    compare_values=lambda left, right, comparison_operator: (
                        _compare_values(
                            left,
                            right,
                            comparison_operator,
                            dialect=dialect,
                            collation=getattr(variables, "collation", None),
                        )
                    ),
                    expression_truthy=lambda value: _expression_truthy(
                        value,
                        dialect=dialect,
                    ),
                    require_array=_require_array,
                    evaluate_pick_n_input=lambda current_operator, current_document, current_spec, current_variables=None: (
                        _evaluate_pick_n_input(
                            current_operator,
                            current_document,
                            current_spec,
                            current_variables,
                            dialect=dialect,
                            evaluate_expression=lambda nested_document, nested_expression, nested_variables=None: (
                                evaluate_expression(
                                    nested_document,
                                    nested_expression,
                                    nested_variables,
                                    dialect=dialect,
                                )
                            ),
                            evaluate_expression_with_missing=lambda nested_document, nested_expression, nested_variables=None: (
                                _evaluate_expression_with_missing(
                                    nested_document,
                                    nested_expression,
                                    nested_variables,
                                    dialect=dialect,
                                )
                            ),
                            missing_sentinel=_MISSING,
                        )
                    ),
                    missing_sentinel=_MISSING,
                )
            if operator in NUMERIC_EXPRESSION_OPERATORS:
                return evaluate_numeric_expression(
                    operator,
                    document,
                    spec,
                    variables,
                    dialect=dialect,
                    evaluate_expression=lambda d, e, v=None: (
                        _evaluate_nullable_expression(d, e, v, dialect=dialect)
                    ),
                    evaluate_expression_with_missing=lambda current_document, current_expression, current_variables=None: (
                        _evaluate_expression_with_missing(
                            current_document,
                            current_expression,
                            current_variables,
                            dialect=dialect,
                        )
                    ),
                    require_expression_args=lambda current_operator, current_spec, current_min_args, current_max_args=None: (
                        _require_expression_args(
                            current_operator,
                            current_spec,
                            min_args=current_min_args,
                            max_args=current_max_args,
                        )
                    ),
                    missing_sentinel=_MISSING,
                )
            if operator in DATE_EXPRESSION_OPERATORS:
                return evaluate_date_expression(
                    operator,
                    document,
                    spec,
                    variables,
                    dialect=dialect,
                    evaluate_expression=lambda d, e, v=None: (
                        _evaluate_nullable_expression(d, e, v, dialect=dialect)
                    ),
                    evaluate_expression_with_missing=lambda *args: (
                        _evaluate_expression_with_missing(*args, dialect=dialect)
                    ),
                    missing_sentinel=_MISSING,
                )
            raise server_error(
                f"Unrecognized expression '{operator}'",
                code=168,
            )

    rendered: dict[str, Any] = {}
    for key, value in expression.items():
        resolved = evaluate_expression(
            document,
            value,
            variables,
            dialect=dialect,
        )
        if resolved is _MISSING:
            continue
        rendered[key] = resolved
    return rendered


_COMPAT_EXPORT_MODULES = {
    "_apply_bucket": "mongoeco.core.aggregation.grouping_stages",
    "_apply_bucket_auto": "mongoeco.core.aggregation.grouping_stages",
    "_apply_count": "mongoeco.core.aggregation.grouping_stages",
    "_apply_group": "mongoeco.core.aggregation.grouping_stages",
    "_apply_set_window_fields": "mongoeco.core.aggregation.grouping_stages",
    "_apply_sort_by_count": "mongoeco.core.aggregation.grouping_stages",
    "_apply_facet": "mongoeco.core.aggregation.join_stages",
    "_apply_lookup": "mongoeco.core.aggregation.join_stages",
    "_apply_union_with": "mongoeco.core.aggregation.join_stages",
    "_apply_add_fields": "mongoeco.core.aggregation.transform_stages",
    "_apply_match": "mongoeco.core.aggregation.transform_stages",
    "_apply_project": "mongoeco.core.aggregation.transform_stages",
    "_apply_replace_root": "mongoeco.core.aggregation.transform_stages",
    "_apply_sample": "mongoeco.core.aggregation.transform_stages",
    "_apply_unset": "mongoeco.core.aggregation.transform_stages",
    "AGGREGATION_STAGE_HANDLERS": "mongoeco.core.aggregation.stages",
    "AggregationStageHandler": "mongoeco.core.aggregation.stages",
    "apply_pipeline": "mongoeco.core.aggregation.stages",
}


def __getattr__(name: str):
    module_name = _COMPAT_EXPORT_MODULES.get(name)
    if module_name is None:
        raise AttributeError(name)
    from importlib import import_module

    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value
