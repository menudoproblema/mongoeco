from __future__ import annotations

import datetime
import decimal
import json
import math
import random
import re
import uuid

from collections.abc import Callable, Mapping
from copy import deepcopy
from typing import Any

from mongoeco.compat import MONGODB_DIALECT_70, MongoDialect
from mongoeco.compat._catalog_operators import SCALAR_EXPRESSION_ARGUMENTS
from mongoeco.core.aggregation.date_expressions import _to_utc_naive
from mongoeco.core.aggregation.expression_values import compare_expression_values
from mongoeco.core.bson_scalars import (
    INT32_MAX,
    INT32_MIN,
    INT64_MAX,
    INT64_MIN,
    BsonDecimal128,
    BsonDouble,
    BsonInt32,
    BsonInt64,
    bson_datetime_from_milliseconds,
    bson_datetime_milliseconds,
    bson_numeric_alias,
    is_bson_numeric,
    unwrap_bson_numeric,
    validate_bson_value,
    wrap_bson_numeric,
)
from mongoeco.core.bson_values import code_parts, document_mapping
from mongoeco.core.codec import DocumentCodec
from mongoeco.core.collation import compare_with_collation
from mongoeco.core.server_errors import server_error
from mongoeco.errors import OperationFailure
from mongoeco.types import (
    Binary,
    Decimal128,
    Document,
    ObjectId,
    Regex,
    Timestamp,
    UndefinedType,
)


type ExpressionEvaluator = Callable[[Document, object, dict[str, Any] | None], Any]
type ExpressionArgValidator = Callable[[str, object, int, int | None], list[Any]]
type Stringifier = Callable[[Any], str]
type BsonSizer = Callable[[Mapping[str, Any]], int]


SCALAR_EXPRESSION_OPERATORS = frozenset(SCALAR_EXPRESSION_ARGUMENTS) | frozenset(
    {
        "$rand",
        "$convert",
        "$bsonSize",
        "$binarySize",
        "$isNumber",
        "$type",
        "$toString",
        "$toBool",
        "$toDate",
        "$toDecimal",
        "$toInt",
        "$toDouble",
        "$toLong",
        "$toObjectId",
        "$toUUID",
        "$isArray",
        "$min",
        "$max",
    }
)


def evaluate_scalar_expression(
    operator: str,
    document: Document,
    spec: object,
    variables: dict[str, Any] | None,
    *,
    dialect: MongoDialect = MONGODB_DIALECT_70,
    evaluate_expression: ExpressionEvaluator,
    evaluate_expression_with_missing: ExpressionEvaluator,
    require_expression_args: ExpressionArgValidator,
    stringify_value: Stringifier,
    bson_document_size: BsonSizer,
    missing_sentinel: object,
) -> Any:
    if operator == "$rand":
        if spec != {}:
            raise OperationFailure("$rand does not accept arguments")
        return random.random()

    if operator == "$convert":
        extended = dialect.behavior_flag("uses_extended_conversions", default=False)
        if extended:
            validate_convert_spec(spec)
        if not isinstance(spec, dict) or "input" not in spec or "to" not in spec:
            raise OperationFailure("$convert requires input and to")
        value = evaluate_expression_with_missing(document, spec["input"], variables)
        if value is missing_sentinel or value is None:
            return (
                evaluate_expression(document, spec["onNull"], variables)
                if "onNull" in spec
                else None
            )
        target = evaluate_expression(document, spec["to"], variables)
        if extended:
            _validate_convert_target(target)
        if isinstance(target, dict):
            target = target.get("type")
        if not isinstance(target, str):
            raise OperationFailure("$convert to must resolve to a string")
        aliases = {
            "bool": "bool",
            "int": "int",
            "long": "long",
            "double": "double",
            "date": "date",
            "objectId": "objectId",
            "string": "string",
        }
        if extended:
            aliases["decimal"] = "decimal"
        base = None
        if extended and "base" in spec:
            base = _conversion_base(
                evaluate_expression(document, spec["base"], variables)
            )
        try:
            if target not in aliases:
                raise server_error("$convert target type is not supported", code=2)
            if extended:
                converted = _convert_extended_scalar(
                    value, aliases[target], base=base, stringify_value=stringify_value
                )
            else:
                converted = _convert_aggregation_scalar(
                    operator, value, aliases[target], stringify_value=stringify_value
                )
            return _typed_conversion_result(converted, aliases[target], variables)
        except Exception:
            if "onError" in spec:
                return evaluate_expression(document, spec["onError"], variables)
            raise

    if operator == "$bsonSize":
        args = require_expression_args(
            operator,
            [spec] if not isinstance(spec, list) else spec,
            1,
            1,
        )
        value = evaluate_expression_with_missing(document, args[0], variables)
        if value is missing_sentinel or value is None:
            return None
        document_value = document_mapping(value)
        if document_value is None:
            message = "$bsonSize requires an object input"
            raise OperationFailure(message, code=31393)
        return bson_document_size(document_value)

    if operator == "$binarySize":
        args = require_expression_args(
            operator,
            [spec] if not isinstance(spec, list) else spec,
            1,
            1,
        )
        value = evaluate_expression_with_missing(document, args[0], variables)
        if value is missing_sentinel or value is None:
            return None
        if isinstance(value, (bytes, bytearray, Binary)):
            return len(value)
        if isinstance(value, uuid.UUID):
            return len(value.bytes)
        raise OperationFailure("$binarySize requires a BinData argument")

    if operator == "$isNumber":
        args = require_expression_args(
            operator,
            [spec] if not isinstance(spec, list) else spec,
            1,
            1,
        )
        value = evaluate_expression_with_missing(document, args[0], variables)
        return is_bson_numeric(value) or (
            isinstance(value, (int, float)) and not isinstance(value, bool)
        )

    if operator == "$type":
        args = require_expression_args(
            operator,
            [spec] if not isinstance(spec, list) else spec,
            1,
            1,
        )
        value = evaluate_expression_with_missing(document, args[0], variables)
        return _aggregation_type_name(value, missing_sentinel=missing_sentinel)

    if operator == "$toString":
        args = require_expression_args(
            operator,
            [spec] if not isinstance(spec, list) else spec,
            1,
            1,
        )
        value = evaluate_expression(document, args[0], variables)
        if value is None:
            return None
        if dialect.behavior_flag("uses_extended_conversions", default=False):
            return _extended_string(value, stringify_value=stringify_value)
        return stringify_value(unwrap_bson_numeric(value))

    if operator in {
        "$toBool",
        "$toDate",
        "$toDecimal",
        "$toInt",
        "$toDouble",
        "$toLong",
        "$toObjectId",
        "$toUUID",
    }:
        args = require_expression_args(
            operator,
            [spec] if not isinstance(spec, list) else spec,
            1,
            1,
        )
        value = evaluate_expression_with_missing(document, args[0], variables)
        if value is missing_sentinel:
            return None
        target = {
            "$toBool": "bool",
            "$toDate": "date",
            "$toDecimal": "decimal",
            "$toInt": "int",
            "$toDouble": "double",
            "$toLong": "long",
            "$toObjectId": "objectId",
            "$toUUID": "uuid",
        }[operator]
        try:
            converted = _convert_aggregation_scalar(
                operator, value, target, stringify_value=stringify_value
            )
        except OperationFailure as error:
            if error.code is not None:
                raise
            raise server_error(str(error), code=241) from error
        return _typed_conversion_result(converted, target, variables)

    if operator == "$isArray":
        args = require_expression_args(
            operator,
            [spec] if not isinstance(spec, list) else spec,
            1,
            1,
        )
        value = evaluate_expression(document, args[0], variables)
        return isinstance(value, list)

    if operator == "$cmp":
        args = require_expression_args(
            operator, spec, *SCALAR_EXPRESSION_ARGUMENTS[operator]
        )
        left = evaluate_expression_with_missing(document, args[0], variables)
        right = evaluate_expression_with_missing(document, args[1], variables)
        comparison = compare_expression_values(
            left,
            right,
            dialect=dialect,
            collation=getattr(variables, "collation", None),
        )
        if comparison < 0:
            return -1
        if comparison > 0:
            return 1
        return 0

    if operator in {"$min", "$max"}:
        return _evaluate_min_max_expression(
            operator,
            document,
            spec,
            variables,
            dialect=dialect,
            evaluate_expression_with_missing=evaluate_expression_with_missing,
            missing_sentinel=missing_sentinel,
        )

    raise OperationFailure(f"Unsupported scalar expression operator: {operator}")


def _evaluate_min_max_expression(
    operator: str,
    document: Document,
    spec: object,
    variables: dict[str, Any] | None,
    *,
    dialect: MongoDialect,
    evaluate_expression_with_missing: ExpressionEvaluator,
    missing_sentinel: object,
) -> Any:
    if isinstance(spec, list):
        candidates = [
            evaluate_expression_with_missing(document, item, variables) for item in spec
        ]
    else:
        value = evaluate_expression_with_missing(document, spec, variables)
        if isinstance(value, list):
            candidates = [item for item in value if is_bson_numeric(item)]
        else:
            candidates = [value]

    comparable = [
        value
        for value in candidates
        if value is not missing_sentinel and value is not None
    ]
    if not comparable:
        return None

    selected = comparable[0]
    for candidate in comparable[1:]:
        comparison = compare_with_collation(
            candidate,
            selected,
            dialect=dialect,
            collation=getattr(variables, "collation", None),
        )
        if (operator == "$max" and comparison > 0) or (
            operator == "$min" and comparison < 0
        ):
            selected = candidate
    return deepcopy(selected)


def _aggregation_type_name(value: Any, *, missing_sentinel: object) -> str:
    if value is missing_sentinel:
        return "missing"
    if isinstance(value, UndefinedType):
        return "undefined"
    if value is None:
        return "null"
    numeric_alias = bson_numeric_alias(value)
    if numeric_alias is not None:
        return numeric_alias
    if isinstance(value, bool):
        return "bool"
    code = code_parts(value)
    if code is not None:
        return "javascript" if code[1] is None else "javascriptWithScope"
    if isinstance(value, str):
        return "string"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    if isinstance(value, (bytes, bytearray, uuid.UUID, Binary)):
        return "binData"
    if isinstance(value, ObjectId):
        return "objectId"
    if isinstance(value, Timestamp):
        return "timestamp"
    if isinstance(value, datetime.datetime):
        return "date"
    if isinstance(value, (re.Pattern, Regex)):
        return "regex"
    return type(value).__name__


def _datetime_to_epoch_millis(value: datetime.datetime) -> int:
    return bson_datetime_milliseconds(value)


def _parse_base10_int_string(operator: str, value: str) -> int:
    text = value.strip()
    if not text or not re.fullmatch(r"[+-]?\d+", text):
        raise OperationFailure(f"{operator} cannot convert the string value")
    return int(text, 10)


def validate_convert_spec(spec: object) -> None:
    """Reject deferred extensions before rows or onError can mask them."""
    if not isinstance(spec, dict) or not {"input", "to"} <= spec.keys():
        message = "$convert requires input and to"
        raise OperationFailure(message)
    allowed = {"input", "to", "base", "onError", "onNull"}
    for parameter in spec:
        if parameter not in allowed:
            message = (
                f"$convert parameter {parameter!r} is outside "
                "Mongoeco's supported subset"
            )
            raise OperationFailure(message)
    _validate_convert_target(spec["to"])


def _validate_convert_target(target: object) -> None:
    if isinstance(target, dict) and not any(key.startswith("$") for key in target):
        if set(target) != {"type"}:
            message = "$convert target options are outside Mongoeco's supported subset"
            raise OperationFailure(message)
        target = target["type"]
    if isinstance(target, str) and target in {"array", "object", "binData"}:
        message = f"$convert to {target!r} is outside Mongoeco's supported subset"
        raise OperationFailure(message)


def _conversion_base(value: object) -> int | None:
    value = unwrap_bson_numeric(DocumentCodec.to_internal(value))
    if isinstance(value, Decimal128):
        value = value.to_decimal()
    if value is None:
        return None
    if (
        not isinstance(value, bool)
        and isinstance(value, (int, float, decimal.Decimal))
        and value in (2, 8, 10, 16)
    ):
        return int(value)
    message = "In $convert, 'base' argument is not a valid base"
    raise OperationFailure(
        message,
        code=3501301,
        details={"codeName": "Location3501301"},
    )


def _extended_string(value: Any, *, stringify_value: Stringifier) -> str:
    value = unwrap_bson_numeric(DocumentCodec.to_internal(value))
    if isinstance(value, dict):
        return (
            "{"
            + ",".join(
                json.dumps(key, ensure_ascii=False)
                + ":"
                + _extended_json_value(item, stringify_value)
                for key, item in value.items()
            )
            + "}"
        )
    if isinstance(value, list):
        return (
            "["
            + ",".join(_extended_json_value(item, stringify_value) for item in value)
            + "]"
        )
    # MaxKey and MinKey remain optional BSON types owned by the codec.
    if type(value).__module__ in {"bson.max_key", "bson.min_key"}:
        return type(value).__name__
    return stringify_value(value)


def _extended_json_value(value: Any, stringify_value: Stringifier) -> str:
    value = unwrap_bson_numeric(value)
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (dict, list)):
        return _extended_string(value, stringify_value=stringify_value)
    if isinstance(value, (int, float, decimal.Decimal, Decimal128)):
        return stringify_value(value)
    return json.dumps(
        _extended_string(value, stringify_value=stringify_value), ensure_ascii=False
    )


def _convert_base_value(value: Any, target: str, base: int) -> Any:
    if isinstance(value, str) and target in {"int", "long", "double", "decimal"}:
        digits = {2: "01", 8: "0-7", 10: "0-9", 16: "0-9a-fA-F"}[base]
        if re.fullmatch(f"[+-]?[{digits}]+", value) is None:
            message = "$convert cannot convert the string in the specified base"
            raise OperationFailure(
                message, code=241, details={"codeName": "ConversionFailure"}
            )
        return int(value, base)
    if (
        target == "string"
        and isinstance(value, (int, float, decimal.Decimal))
        and not isinstance(value, bool)
    ):
        # The server also accepts integral double/decimal values within Int32.
        if (
            not math.isfinite(value)
            or int(value) != value
            or (not isinstance(value, int) and not INT32_MIN <= value <= INT32_MAX)
        ):
            message = "$convert base conversion to string requires an integer input"
            raise OperationFailure(
                message, code=241, details={"codeName": "ConversionFailure"}
            )
        value = int(value)
        return format(value, {2: "b", 8: "o", 10: "d", 16: "X"}[base])
    return value


def _convert_extended_scalar(
    value: Any, target: str, *, base: int | None, stringify_value: Stringifier
) -> Any:
    value = unwrap_bson_numeric(DocumentCodec.to_internal(value))
    if isinstance(value, Decimal128):
        value = value.to_decimal()
    if base is not None:
        value = _convert_base_value(value, target, base)
    if target == "string":
        return _extended_string(value, stringify_value=stringify_value)
    if isinstance(value, decimal.Decimal) and target in {"int", "long", "double"}:
        value = float(value) if target == "double" else int(value)
    return _convert_aggregation_scalar(
        "$convert", value, target, stringify_value=stringify_value
    )


def _typed_conversion_result(value: Any, target: str, variables: object) -> Any:
    if value is not None and target == "long":
        return BsonInt64(unwrap_bson_numeric(value))
    if value is None or not getattr(
        variables, "preserve_numeric_conversion_types", False
    ):
        return value
    constructors = {
        "int": int,
        "double": float,
        "decimal": Decimal128,
    }
    constructor = constructors.get(target)
    return value if constructor is None else constructor(unwrap_bson_numeric(value))


def _convert_aggregation_scalar(
    operator: str,
    value: Any,
    target: str,
    *,
    stringify_value: Stringifier,
) -> Any:
    if value is None or isinstance(value, UndefinedType):
        return None
    preserve_numeric_wrappers = isinstance(
        value, BsonInt32 | BsonInt64 | BsonDouble | BsonDecimal128
    )
    source_value = value
    value = unwrap_bson_numeric(value)

    if target == "bool":
        if isinstance(value, bool):
            return value
        numeric = wrap_bson_numeric(value)
        if numeric is not None:
            return numeric.value != 0
        if isinstance(
            value,
            (
                str,
                list,
                dict,
                bytes,
                bytearray,
                uuid.UUID,
                Binary,
                ObjectId,
                datetime.datetime,
                Timestamp,
            ),
        ):
            return True
        raise OperationFailure(f"{operator} cannot convert the value")

    if target == "int":
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            if value < INT32_MIN or value > INT32_MAX:
                raise OperationFailure(f"{operator} overflow")
            return BsonInt32(value) if preserve_numeric_wrappers else value
        if isinstance(value, float):
            if not math.isfinite(value):
                raise OperationFailure(f"{operator} cannot convert the value")
            integer = int(value)
            if integer < INT32_MIN or integer > INT32_MAX:
                raise OperationFailure(f"{operator} overflow")
            return BsonInt32(integer) if preserve_numeric_wrappers else integer
        if isinstance(value, str):
            integer = _parse_base10_int_string(operator, value)
            if integer < INT32_MIN or integer > INT32_MAX:
                raise OperationFailure(f"{operator} overflow")
            return BsonInt32(integer) if preserve_numeric_wrappers else integer
        raise OperationFailure(f"{operator} cannot convert the value")

    if target == "long":
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            if value < INT64_MIN or value > INT64_MAX:
                raise OperationFailure(f"{operator} overflow")
            return BsonInt64(value) if preserve_numeric_wrappers else value
        if isinstance(value, float):
            if not math.isfinite(value):
                raise OperationFailure(f"{operator} cannot convert the value")
            integer = int(value)
            if integer < INT64_MIN or integer > INT64_MAX:
                raise OperationFailure(f"{operator} overflow")
            return BsonInt64(integer) if preserve_numeric_wrappers else integer
        if isinstance(value, str):
            integer = _parse_base10_int_string(operator, value)
            if integer < INT64_MIN or integer > INT64_MAX:
                raise OperationFailure(f"{operator} overflow")
            return BsonInt64(integer) if preserve_numeric_wrappers else integer
        if isinstance(value, datetime.datetime):
            integer = _datetime_to_epoch_millis(value)
            return BsonInt64(integer) if preserve_numeric_wrappers else integer
        raise OperationFailure(f"{operator} cannot convert the value")

    if target == "double":
        if isinstance(value, bool):
            result = 1.0 if value else 0.0
            return BsonDouble(result) if preserve_numeric_wrappers else result
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            result = float(value)
            return BsonDouble(result) if preserve_numeric_wrappers else result
        if isinstance(value, str):
            text = value.strip()
            if not text:
                raise OperationFailure(f"{operator} cannot convert the string value")
            try:
                result = float(text)
                return BsonDouble(result) if preserve_numeric_wrappers else result
            except ValueError as exc:
                raise OperationFailure(
                    f"{operator} cannot convert the string value"
                ) from exc
        if isinstance(value, datetime.datetime):
            result = float(_datetime_to_epoch_millis(value))
            return BsonDouble(result) if preserve_numeric_wrappers else result
        raise OperationFailure(f"{operator} cannot convert the value")

    if target == "date":
        if isinstance(value, datetime.datetime):
            return _to_utc_naive(value)
        if isinstance(value, ObjectId):
            return bson_datetime_from_milliseconds(int(value.generation_time) * 1000)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if bson_numeric_alias(source_value) == "int":
                raise server_error(f"{operator} cannot convert int to date", code=241)
            if not math.isfinite(value):
                raise OperationFailure(f"{operator} cannot convert the value")
            return bson_datetime_from_milliseconds(int(value))
        if isinstance(value, str):
            try:
                return _to_utc_naive(
                    datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
                )
            except Exception as exc:
                raise OperationFailure(
                    f"{operator} cannot convert the string value"
                ) from exc
        raise OperationFailure(f"{operator} cannot convert the value")

    if target == "objectId":
        if isinstance(value, ObjectId):
            return value
        if isinstance(value, str):
            try:
                return ObjectId(value)
            except Exception as exc:
                raise OperationFailure(
                    f"{operator} cannot convert the string value"
                ) from exc
        raise OperationFailure(f"{operator} cannot convert the value")

    if target == "uuid":
        if isinstance(value, uuid.UUID):
            return value
        if isinstance(value, (bytes, bytearray, Binary)):
            if len(value) != 16:
                raise OperationFailure(f"{operator} cannot convert the value")
            try:
                return uuid.UUID(bytes=bytes(value))
            except Exception as exc:
                raise OperationFailure(f"{operator} cannot convert the value") from exc
        if isinstance(value, str):
            try:
                return uuid.UUID(value)
            except Exception as exc:
                raise OperationFailure(
                    f"{operator} cannot convert the string value"
                ) from exc
        raise OperationFailure(f"{operator} cannot convert the value")

    if target == "decimal":
        if isinstance(value, bool):
            result = decimal.Decimal(int(value))
            validate_bson_value(result)
            return BsonDecimal128(result) if preserve_numeric_wrappers else result
        if isinstance(value, int):
            result = decimal.Decimal(value)
            validate_bson_value(result)
            return BsonDecimal128(result) if preserve_numeric_wrappers else result
        if isinstance(value, float):
            if not math.isfinite(value):
                raise OperationFailure(f"{operator} cannot convert the value")
            result = decimal.Decimal(str(value))
            validate_bson_value(result)
            return BsonDecimal128(result) if preserve_numeric_wrappers else result
        if isinstance(value, Decimal128):
            result = value.to_decimal()
            validate_bson_value(result)
            return BsonDecimal128(result) if preserve_numeric_wrappers else result
        if isinstance(value, decimal.Decimal):
            validate_bson_value(value)
            return BsonDecimal128(value) if preserve_numeric_wrappers else value
        if isinstance(value, str):
            text = value.strip()
            if not text:
                raise OperationFailure(f"{operator} cannot convert the string value")
            try:
                result = decimal.Decimal(text)
                validate_bson_value(result)
                return BsonDecimal128(result) if preserve_numeric_wrappers else result
            except Exception as exc:
                raise OperationFailure(
                    f"{operator} cannot convert the string value"
                ) from exc
        raise OperationFailure(f"{operator} cannot convert the value")

    if target == "string":
        return stringify_value(value)

    raise OperationFailure(f"Unsupported conversion target for {operator}")  # noqa: EM102 - unchanged legacy emitter
