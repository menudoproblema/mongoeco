from __future__ import annotations

import binascii
import datetime
import decimal
import math
import struct
import uuid

from typing import Any, Self

from mongoeco._types.concerns import CodecOptions, UuidRepresentation


try:
    from bson.binary import Binary as BsonBinary
    from bson.code import Code as BsonCode
    from bson.dbref import DBRef as BsonDBRef
    from bson.decimal128 import Decimal128 as BsonDecimal128Public
    from bson.int64 import Int64 as BsonInt64Public
    from bson.max_key import MaxKey as BsonMaxKey
    from bson.min_key import MinKey as BsonMinKey
    from bson.objectid import ObjectId as BsonObjectId
    from bson.regex import Regex as BsonRegex
    from bson.son import SON as BsonSON
    from bson.timestamp import Timestamp as BsonTimestamp
except Exception:  # pragma: no cover - optional dependency
    BsonBinary = None
    BsonCode = None
    BsonDBRef = None
    BsonDecimal128Public = None
    BsonInt64Public = None
    BsonMaxKey = None
    BsonMinKey = None
    BsonObjectId = None
    BsonRegex = None
    BsonSON = None
    BsonTimestamp = None

from mongoeco.core.bson_values import decoded_document_reference
from mongoeco.core.bson_scalars import (
    BsonDecimal128,
    BsonDouble,
    BsonInt32,
    BsonInt64,
    normalize_utc_bson_datetime,
    unwrap_bson_numeric,
    validate_bson_value,
)
from mongoeco.core.bson_values import regex_parts
from mongoeco.types import (
    SON,
    UNDEFINED,
    Binary,
    DBRef,
    Decimal128,
    ObjectId,
    Regex,
    Timestamp,
    UndefinedType,
    is_object_id_like,
    normalize_object_id,
)


class _ImmutableInternalBson:
    """Reject mutation after a BSON value crosses the command boundary."""

    @staticmethod
    def _immutable(*_args: Any, **_kwargs: Any) -> None:
        message = 'internal BSON values are immutable'
        raise TypeError(message)

    __setitem__ = _immutable
    __delitem__ = _immutable
    clear = _immutable
    pop = _immutable
    popitem = _immutable
    setdefault = _immutable
    update = _immutable


class _InternalBsonDocument(_ImmutableInternalBson, dict[str, Any]):
    """Detached immutable BSON document owned by MongoEco."""

    __ior__ = _ImmutableInternalBson._immutable

    def __deepcopy__(self, _memo: dict[int, Any]) -> _InternalBsonDocument:
        return self


class _InternalBsonArray(_ImmutableInternalBson, list[Any]):
    """Detached immutable BSON array owned by MongoEco."""

    append = _ImmutableInternalBson._immutable
    extend = _ImmutableInternalBson._immutable
    insert = _ImmutableInternalBson._immutable
    remove = _ImmutableInternalBson._immutable
    reverse = _ImmutableInternalBson._immutable
    sort = _ImmutableInternalBson._immutable
    __iadd__ = _ImmutableInternalBson._immutable
    __imul__ = _ImmutableInternalBson._immutable

    def __deepcopy__(self, _memo: dict[int, Any]) -> _InternalBsonArray:
        return self


_MAX_BINARY_SUBTYPE = 255


class _InternalBsonBinary(Binary):
    """Binary scalar whose subtype cannot change after normalization."""

    def __new__(
        cls,
        data: bytes | bytearray | memoryview,
        subtype: int = 0,
    ) -> Self:
        if not 0 <= subtype <= _MAX_BINARY_SUBTYPE:
            message = 'binary subtype must be between 0 and 255'
            raise ValueError(message)
        instance = bytes.__new__(cls, bytes(data))
        object.__setattr__(instance, 'subtype', subtype)
        return instance

    def __setattr__(self, _name: str, _value: object) -> None:
        message = 'internal BSON values are immutable'
        raise TypeError(message)

    def __deepcopy__(self, _memo: dict[int, Any]) -> _InternalBsonBinary:
        return self


def _own_internal_bson(data: Any) -> Any:
    if isinstance(data, (_InternalBsonDocument, _InternalBsonArray)):
        return data
    if isinstance(data, dict):
        return _InternalBsonDocument(
            {key: _own_internal_bson(value) for key, value in data.items()},
        )
    if isinstance(data, list):
        return _InternalBsonArray(_own_internal_bson(value) for value in data)
    return _own_internal_bson_scalar(data)


def _own_internal_bson_scalar(data: Any) -> Any:
    if isinstance(data, DBRef):
        return DBRef(
            collection=data.collection,
            id=_own_internal_bson(data.id),
            database=data.database,
            extras=_own_internal_bson(data.extras),
        )
    if BsonCode is not None and isinstance(data, BsonCode):
        return BsonCode(
            str(data),
            (
                None
                if data.scope is None
                else _own_internal_bson(data.scope)
            ),
        )
    if isinstance(data, Binary):
        return _InternalBsonBinary(bytes(data), subtype=data.subtype)
    return data


def _materialize_public_int64(data: Any) -> Any:
    if not isinstance(data, BsonInt64):
        return data
    if BsonInt64Public is None:
        return data.value
    return BsonInt64Public(data.value)


class DocumentCodec:
    """
    Normaliza documentos usando un formato interno reversible (Extended JSON style).
    Asegura que un datetime guardado en SQLite vuelva como datetime al usuario.
    """

    _MARKER = "$mongoeco"
    _TYPE = "type"
    _VALUE = "value"
    _BSON_WRAPPER_TYPES = (BsonInt32, BsonInt64, BsonDouble, BsonDecimal128)

    @staticmethod
    def _tagged_value(value_type: str, value: Any) -> dict[str, Any]:
        return {
            DocumentCodec._MARKER: {
                DocumentCodec._TYPE: value_type,
                DocumentCodec._VALUE: value,
            }
        }

    @staticmethod
    def _is_tagged_value(data: Any) -> bool:
        if (
            not isinstance(data, dict)
            or len(data) != 1
            or DocumentCodec._MARKER not in data
        ):
            return False

        payload = data[DocumentCodec._MARKER]
        return (
            isinstance(payload, dict)
            and len(payload) == 2
            and DocumentCodec._TYPE in payload
            and DocumentCodec._VALUE in payload
            and isinstance(payload[DocumentCodec._TYPE], str)
        )

    @staticmethod
    def to_internal(data: Any) -> Any:
        """Apply the BSON command boundary before engine evaluation."""
        if isinstance(data, (_InternalBsonDocument, _InternalBsonArray)):
            return data
        normalized = DocumentCodec.decode(
            DocumentCodec.encode(data),
            preserve_bson_wrappers=True,
        )
        return _own_internal_bson(normalized)

    @staticmethod
    def is_internal(data: Any) -> bool:
        return isinstance(data, (_InternalBsonDocument, _InternalBsonArray))

    @staticmethod
    def mark_internal(data: Any) -> Any:
        return _own_internal_bson(data)

    @staticmethod
    def encode(data: Any) -> Any:
        if BsonSON is not None and isinstance(data, BsonSON):
            validate_bson_value(data)
            return DocumentCodec._tagged_value(
                "son",
                [[key, DocumentCodec.encode(value)] for key, value in data.items()],
            )
        if isinstance(data, SON):
            validate_bson_value(data)
            return DocumentCodec._tagged_value(
                "son",
                [[key, DocumentCodec.encode(value)] for key, value in data.items()],
            )
        if isinstance(data, dict):
            validate_bson_value(data)
            encoded = {k: DocumentCodec.encode(v) for k, v in data.items()}
            if DocumentCodec._is_tagged_value(encoded):
                return DocumentCodec._tagged_value("dict", encoded)
            return encoded
        if isinstance(data, (list, tuple)):
            return [DocumentCodec.encode(v) for v in data]
        if isinstance(data, bytearray):
            data = bytes(data)
        if isinstance(data, (set, frozenset)):
            raise TypeError("set values are not BSON-serializable")

        validate_bson_value(data)

        if isinstance(data, datetime.datetime):
            data = normalize_utc_bson_datetime(data)
            return DocumentCodec._tagged_value("datetime", data.isoformat())

        if BsonMinKey is not None and isinstance(data, BsonMinKey):
            return DocumentCodec._tagged_value("minkey", True)

        if BsonMaxKey is not None and isinstance(data, BsonMaxKey):
            return DocumentCodec._tagged_value("maxkey", True)

        if isinstance(data, decimal.Decimal):
            return DocumentCodec._tagged_value("decimal", str(data))

        if isinstance(data, uuid.UUID):
            return DocumentCodec._tagged_value("uuid", str(data))

        if is_object_id_like(data):
            return DocumentCodec._tagged_value(
                "objectid",
                str(normalize_object_id(data)),
            )

        if BsonBinary is not None and isinstance(data, BsonBinary):
            return DocumentCodec._tagged_value(
                "binary",
                {
                    "hex": binascii.hexlify(bytes(data)).decode("ascii"),
                    "subtype": data.subtype,
                },
            )

        if isinstance(data, Binary):
            return DocumentCodec._tagged_value(
                "binary",
                {
                    "hex": binascii.hexlify(bytes(data)).decode("ascii"),
                    "subtype": data.subtype,
                },
            )

        if (BsonRegex is not None and isinstance(data, BsonRegex)) or isinstance(data, Regex):
            parts = regex_parts(data)
            assert parts is not None  # noqa: S101 - same guarded regex families
            pattern, flags = parts
            return DocumentCodec._tagged_value(
                "regex", {"pattern": pattern, "flags": flags},
            )

        if isinstance(data, Timestamp):
            return DocumentCodec._tagged_value(
                "timestamp",
                {"time": data.time, "inc": data.inc},
            )

        if BsonTimestamp is not None and isinstance(data, BsonTimestamp):
            return DocumentCodec._tagged_value(
                "timestamp",
                {"time": data.time, "inc": data.inc},
            )

        if BsonDecimal128Public is not None and isinstance(
            data, BsonDecimal128Public
        ):
            return DocumentCodec._tagged_value(
                "decimal128_public",
                str(data),
            )

        if BsonInt64Public is not None and isinstance(data, BsonInt64Public):
            return DocumentCodec._tagged_value("int64", int(data))

        if isinstance(data, Decimal128):
            return DocumentCodec._tagged_value("decimal128_public", str(data.value))

        if BsonCode is not None and isinstance(data, BsonCode):
            return DocumentCodec._tagged_value(
                "code",
                {
                    "code": str(data),
                    "scope": DocumentCodec.encode(data.scope) if data.scope is not None else None,
                },
            )

        if isinstance(data, DBRef):
            return DocumentCodec._tagged_value(
                "dbref",
                {
                    "collection": data.collection,
                    "id": DocumentCodec.encode(data.id),
                    "database": data.database,
                    "extras": DocumentCodec.encode(data.extras),
                },
            )

        if BsonDBRef is not None and isinstance(data, BsonDBRef):
            as_document = data.as_doc()
            extras = {
                key: value
                for key, value in as_document.items()
                if key not in {"$ref", "$id", "$db"}
            }
            return DocumentCodec._tagged_value(
                "dbref",
                {
                    "collection": data.collection,
                    "id": DocumentCodec.encode(data.id),
                    "database": data.database,
                    "extras": DocumentCodec.encode(extras),
                },
            )

        if isinstance(data, bytes):
            return DocumentCodec._tagged_value(
                "bytes", binascii.hexlify(data).decode("ascii")
            )

        if isinstance(data, UndefinedType):
            return DocumentCodec._tagged_value("undefined", True)

        if isinstance(data, BsonInt32):
            return DocumentCodec._tagged_value("int32", data.value)

        if isinstance(data, BsonInt64):
            return DocumentCodec._tagged_value("int64", data.value)

        if isinstance(data, (BsonDouble, float)):
            number = data.value if isinstance(data, BsonDouble) else data
            if not math.isfinite(number):
                # JSON NaN loses payload/sign (or becomes null in some backends).
                # Keep the existing double tag and remember ownership separately
                # so legacy float storage keys retain their Python representation.
                return DocumentCodec._tagged_value("double", {
                    "bits": struct.pack("<d", number).hex(),
                    "wrapped": isinstance(data, BsonDouble),
                })
            if isinstance(data, BsonDouble):
                return DocumentCodec._tagged_value("double", number)

        if isinstance(data, BsonDecimal128):
            return DocumentCodec._tagged_value("decimal128", str(data.value))

        return data

    @staticmethod
    def decode(data: Any, *, preserve_bson_wrappers: bool = False) -> Any:
        if DocumentCodec._is_tagged_value(data):
            payload = data[DocumentCodec._MARKER]
            value_type = payload[DocumentCodec._TYPE]
            value = payload[DocumentCodec._VALUE]

            if value_type == "datetime":
                return datetime.datetime.fromisoformat(value)
            if value_type == "minkey":
                if BsonMinKey is None:
                    raise ValueError("MinKey requires bson support")
                return BsonMinKey()
            if value_type == "maxkey":
                if BsonMaxKey is None:
                    raise ValueError("MaxKey requires bson support")
                return BsonMaxKey()
            if value_type == "decimal":
                return decimal.Decimal(value)
            if value_type == "uuid":
                return uuid.UUID(value)
            if value_type == "objectid":
                return ObjectId(value)
            if value_type == "binary":
                return Binary(binascii.unhexlify(value["hex"]), subtype=int(value["subtype"]))
            if value_type == "regex":
                return Regex(value["pattern"], value["flags"])
            if value_type == "timestamp":
                return Timestamp(int(value["time"]), int(value["inc"]))
            if value_type == "decimal128_public":
                return Decimal128(value)
            if value_type == "code":
                if BsonCode is None:
                    raise ValueError("Code requires bson support")
                scope = value["scope"]
                return BsonCode(
                    value["code"],
                    DocumentCodec.decode(scope, preserve_bson_wrappers=preserve_bson_wrappers)
                    if scope is not None
                    else None,
                )
            if value_type == "dbref":
                return DBRef(
                    collection=str(value["collection"]),
                    id=DocumentCodec.decode(value["id"], preserve_bson_wrappers=preserve_bson_wrappers),
                    database=str(value["database"]) if value["database"] is not None else None,
                    extras=DocumentCodec.decode(value["extras"], preserve_bson_wrappers=preserve_bson_wrappers),
                )
            if value_type == "bytes":
                return binascii.unhexlify(value)
            if value_type == "undefined":
                return UNDEFINED
            if value_type == "int32":
                return BsonInt32(int(value)) if preserve_bson_wrappers else int(value)
            if value_type == "int64":
                return BsonInt64(int(value)) if preserve_bson_wrappers else int(value)
            if value_type == "double":
                if isinstance(value, dict):
                    number = struct.unpack("<d", bytes.fromhex(value["bits"]))[0]
                    return (
                        BsonDouble(number)
                        if value["wrapped"] and preserve_bson_wrappers else number
                    )
                return BsonDouble(float(value)) if preserve_bson_wrappers else float(value)
            if value_type == "decimal128":
                return BsonDecimal128(decimal.Decimal(value)) if preserve_bson_wrappers else decimal.Decimal(value)
            if value_type == "dict":
                return {
                    k: DocumentCodec.decode(v, preserve_bson_wrappers=preserve_bson_wrappers)
                    for k, v in value.items()
                }
            if value_type == "son":
                return SON(
                    (
                        str(key),
                        DocumentCodec.decode(item, preserve_bson_wrappers=preserve_bson_wrappers),
                    )
                    for key, item in value
                )
            raise ValueError(f"Unsupported tagged value type: {value_type}")

        if isinstance(data, dict):
            flat_dict: dict[Any, Any] = {}
            for key, value in data.items():
                if isinstance(value, dict):
                    break
                if isinstance(value, list):
                    if any(isinstance(item, dict | list) for item in value):
                        break
                    flat_dict[key] = list(value)
                    continue
                flat_dict[key] = value
            else:
                return flat_dict
            decoded: dict[Any, Any] = {}
            for key, value in data.items():
                if isinstance(value, dict):
                    decoded[key] = DocumentCodec.decode(
                        value,
                        preserve_bson_wrappers=preserve_bson_wrappers,
                    )
                    continue
                if isinstance(value, list):
                    decoded[key] = DocumentCodec._decode_list_fast(
                        value,
                        preserve_bson_wrappers=preserve_bson_wrappers,
                    )
                    continue
                decoded[key] = value
            return decoded

        if isinstance(data, list):
            return DocumentCodec._decode_list_fast(
                data,
                preserve_bson_wrappers=preserve_bson_wrappers,
            )

        return data

    @staticmethod
    def apply_codec_options(
        data: Any,
        *,
        codec_options: CodecOptions | None,
    ) -> Any:
        if codec_options is None:
            return data
        return DocumentCodec._apply_codec_options_recursive(data, codec_options=codec_options)

    @staticmethod
    def _apply_codec_options_recursive(
        data: Any,
        *,
        codec_options: CodecOptions,
    ) -> Any:
        if BsonCode is not None and isinstance(data, BsonCode):
            converted = BsonCode(
                str(data),
                DocumentCodec._apply_codec_options_recursive(
                    data.scope, codec_options=codec_options
                ) if data.scope is not None else None,
            )
            return DocumentCodec._apply_codec_scalar_options(
                converted, codec_options=codec_options
            )
        if BsonDBRef is not None and isinstance(data, BsonDBRef):
            document = DocumentCodec._apply_codec_options_recursive(
                data.as_doc(), codec_options=codec_options
            )
            return DocumentCodec._apply_codec_scalar_options(
                decoded_document_reference(document), codec_options=codec_options
            )
        if isinstance(data, dict):
            converted = {
                key: DocumentCodec._apply_codec_options_recursive(value, codec_options=codec_options)
                for key, value in data.items()
            }
            return (
                converted if codec_options.document_class is dict
                else codec_options.document_class(converted)
            )
        if isinstance(data, list):
            return [
                DocumentCodec._apply_codec_options_recursive(value, codec_options=codec_options)
                for value in data
            ]
        if isinstance(data, tuple):
            return tuple(
                DocumentCodec._apply_codec_options_recursive(value, codec_options=codec_options)
                for value in data
            )
        return DocumentCodec._apply_codec_scalar_options(data, codec_options=codec_options)

    @staticmethod
    def _apply_codec_scalar_options(
        value: Any,
        *,
        codec_options: CodecOptions,
    ) -> Any:
        transformed = value
        if isinstance(transformed, datetime.datetime):
            transformed = DocumentCodec._apply_datetime_codec_options(
                transformed,
                codec_options=codec_options,
            )
        elif isinstance(transformed, uuid.UUID):
            transformed = DocumentCodec._apply_uuid_codec_options(
                transformed,
                codec_options=codec_options,
            )

        for value_type, decoder in codec_options.type_registry:
            if isinstance(transformed, value_type):
                transformed = decoder(transformed)
        return transformed

    @staticmethod
    def _apply_datetime_codec_options(
        value: datetime.datetime,
        *,
        codec_options: CodecOptions,
    ) -> datetime.datetime:
        if value.tzinfo is None:
            if not codec_options.tz_aware:
                return value
            aware_utc = value.replace(tzinfo=datetime.timezone.utc)
        else:
            aware_utc = value.astimezone(datetime.timezone.utc)
            if not codec_options.tz_aware:
                return aware_utc.replace(tzinfo=None)
        target_tz = codec_options.tzinfo or datetime.timezone.utc
        return aware_utc.astimezone(target_tz)

    @staticmethod
    def _apply_uuid_codec_options(
        value: uuid.UUID,
        *,
        codec_options: CodecOptions,
    ) -> uuid.UUID | Binary:
        uuid_representation = codec_options.uuid_representation
        if uuid_representation is UuidRepresentation.STANDARD:
            return value
        if uuid_representation is UuidRepresentation.UNSPECIFIED:
            return Binary(value.bytes, subtype=4)
        return Binary(value.bytes, subtype=3)

    @staticmethod
    def _decode_list_fast(data: list[Any], *, preserve_bson_wrappers: bool) -> list[Any]:
        if not data:
            return []
        if not any(isinstance(value, dict | list) for value in data):
            return list(data)
        decoded_items: list[Any] = []
        for value in data:
            if isinstance(value, dict | list):
                decoded_items.append(
                    DocumentCodec.decode(
                        value,
                        preserve_bson_wrappers=preserve_bson_wrappers,
                    )
                )
                continue
            decoded_items.append(value)
        return decoded_items

    @staticmethod
    def to_public(data: Any) -> Any:
        return DocumentCodec._to_public_copy_on_write(data)

    @staticmethod
    def to_pymongo(data: Any, *, binary_subtype_zero_as_bytes: bool = False) -> Any:
        """Materialize the selected PyMongo surface.

        Decoded responses use bytes for subtype zero. Locally assigned values,
        such as insert IDs, retain their Binary wrapper unless requested here.
        """
        data = _materialize_public_int64(data)
        if BsonObjectId is None:
            return data
        if (
            binary_subtype_zero_as_bytes
            and isinstance(data, bytes)
            and getattr(data, "subtype", 0) == 0
        ):
            return bytes(data)
        if BsonCode is not None and isinstance(data, BsonCode):
            scope = data.scope
            return BsonCode(
                str(data),
                (
                    DocumentCodec.to_pymongo(
                        scope,
                        binary_subtype_zero_as_bytes=binary_subtype_zero_as_bytes,
                    )
                    if scope is not None else None
                ),
            )
        if type(data) is ObjectId:
            return BsonObjectId(data.binary)
        if isinstance(data, Binary):
            return BsonBinary(bytes(data), subtype=data.subtype)
        if type(data) is Decimal128:
            return BsonDecimal128Public(str(data.value))
        if type(data) is Regex:
            return BsonRegex(data.pattern, data.flags)
        if type(data) is Timestamp:
            return BsonTimestamp(data.time, data.inc)
        if type(data) is DBRef:
            extras = DocumentCodec.to_pymongo(
                data.extras, binary_subtype_zero_as_bytes=binary_subtype_zero_as_bytes
            )
            return BsonDBRef(
                data.collection,
                DocumentCodec.to_pymongo(
                    data.id, binary_subtype_zero_as_bytes=binary_subtype_zero_as_bytes
                ),
                data.database,
                **extras,
            )
        if type(data) is SON:
            return BsonSON(
                (key, DocumentCodec.to_pymongo(
                    value, binary_subtype_zero_as_bytes=binary_subtype_zero_as_bytes
                ))
                for key, value in data.items()
            )
        if isinstance(data, dict):
            return {
                key: DocumentCodec.to_pymongo(
                    value, binary_subtype_zero_as_bytes=binary_subtype_zero_as_bytes
                )
                for key, value in data.items()
            }
        if isinstance(data, (list, tuple)):
            converted = [
                DocumentCodec.to_pymongo(
                    value, binary_subtype_zero_as_bytes=binary_subtype_zero_as_bytes
                )
                for value in data
            ]
            return tuple(converted) if isinstance(data, tuple) else converted
        return data

    @staticmethod
    def _to_public_copy_on_write(  # noqa: PLR0911, PLR0912
        data: Any,
    ) -> Any:
        if isinstance(data, _InternalBsonDocument):
            return {
                key: DocumentCodec._to_public_copy_on_write(value)
                for key, value in data.items()
            }
        if isinstance(data, _InternalBsonArray):
            return [
                DocumentCodec._to_public_copy_on_write(value)
                for value in data
            ]
        if isinstance(data, _InternalBsonBinary):
            return Binary(bytes(data), subtype=data.subtype)
        if isinstance(data, DBRef):
            return DBRef(
                collection=data.collection,
                id=DocumentCodec._to_public_copy_on_write(data.id),
                database=data.database,
                extras=DocumentCodec._to_public_copy_on_write(data.extras),
            )
        if BsonCode is not None and isinstance(data, BsonCode):
            return BsonCode(
                str(data),
                (
                    None
                    if data.scope is None
                    else DocumentCodec._to_public_copy_on_write(data.scope)
                ),
            )
        if type(data) is SON:
            return SON(
                (
                    key,
                    DocumentCodec._to_public_copy_on_write(value),
                )
                for key, value in data.items()
            )
        if isinstance(data, dict):
            flat_changed = isinstance(data, _InternalBsonDocument)
            flat_items: list[tuple[Any, Any]] = []
            for key, value in data.items():
                if isinstance(value, DocumentCodec._BSON_WRAPPER_TYPES):
                    flat_changed = True
                    flat_items.append((key, DocumentCodec._to_public_numeric(value)))
                    continue
                if isinstance(value, list):
                    public_list, list_changed, contains_nested = DocumentCodec._to_public_flat_list(value)
                    if contains_nested:
                        break
                    if list_changed:
                        flat_changed = True
                        flat_items.append((key, public_list))
                    else:
                        flat_items.append((key, value))
                    continue
                if isinstance(value, dict):
                    break
                flat_items.append((key, value))
            else:
                if not flat_changed:
                    return data
                return {key: value for key, value in flat_items}

            converted_items: list[tuple[Any, Any]] = []
            changed = isinstance(data, _InternalBsonDocument)
            for key, value in data.items():
                public_value = DocumentCodec._to_public_copy_on_write(value)
                if public_value is not value:
                    changed = True
                converted_items.append((key, public_value))
            if not changed:
                return data
            return {key: value for key, value in converted_items}

        if isinstance(data, list):
            flat_items, flat_changed, contains_nested = DocumentCodec._to_public_flat_list(data)
            flat_changed = flat_changed or isinstance(
                data,
                _InternalBsonArray,
            )
            if not contains_nested:
                return flat_items if flat_changed else data

            converted_items: list[Any] = []
            changed = isinstance(data, _InternalBsonArray)
            for value in data:
                public_value = DocumentCodec._to_public_copy_on_write(value)
                if public_value is not value:
                    changed = True
                converted_items.append(public_value)
            if not changed:
                return data
            return converted_items

        if isinstance(data, DocumentCodec._BSON_WRAPPER_TYPES):
            return DocumentCodec._to_public_numeric(data)
        return data

    @staticmethod
    def _to_public_numeric(data: Any) -> Any:
        if isinstance(data, BsonDecimal128):
            constructor = BsonDecimal128Public or Decimal128
            return constructor(data.value)
        materialized = _materialize_public_int64(data)
        if materialized is not data:
            return materialized
        return unwrap_bson_numeric(data)

    @staticmethod
    def _to_public_flat_list(data: list[Any]) -> tuple[list[Any], bool, bool]:
        converted_items: list[Any] = []
        changed = False
        for value in data:
            if isinstance(value, DocumentCodec._BSON_WRAPPER_TYPES):
                changed = True
                converted_items.append(DocumentCodec._to_public_numeric(value))
                continue
            if isinstance(value, dict | list):
                return converted_items, changed, True
            converted_items.append(value)
        return converted_items, changed, False
