"""Registration data shared by native capture and semantic replay consumers."""

from dataclasses import dataclass

from tests.differential.semantic_absence_consumer_cases import (
    SEED as ABSENCE_SEED,
    SEMANTIC_ABSENCE_CONSUMER_CASES,
)
from tests.differential.semantic_average_route_cases import (
    SEED as AVERAGE_ROUTE_SEED,
    SEMANTIC_AVERAGE_ROUTE_CASES,
)
from tests.differential.semantic_binary_cases import (
    SEED as BINARY_SEED,
    SEMANTIC_BINARY_CASES,
)
from tests.differential.semantic_binary_edge_cases import (
    SEED as BINARY_EDGE_SEED,
    SEMANTIC_BINARY_EDGE_CASES,
)
from tests.differential.semantic_binary_surface_cases import (
    SEED as BINARY_SURFACE_SEED,
    SEMANTIC_BINARY_SURFACE_CASES,
)
from tests.differential.semantic_bson_grammar_context_cases import (
    SEED as BSON_GRAMMAR_CONTEXT_SEED,
    SEMANTIC_BSON_GRAMMAR_CONTEXT_CASES,
)
from tests.differential.semantic_bson_size_cases import (
    SEED as BSON_SIZE_SEED,
    SEMANTIC_BSON_SIZE_CASES,
)
from tests.differential.semantic_command_let_cases import (
    SEED as COMMAND_LET_SEED,
    SEMANTIC_COMMAND_LET_CASES,
)
from tests.differential.semantic_datetime_cases import (
    SEED as DATETIME_SEED,
    SEMANTIC_DATETIME_CASES,
)
from tests.differential.semantic_dbref_grammar_cases import (
    SEED as DBREF_GRAMMAR_SEED,
    SEMANTIC_DBREF_GRAMMAR_CASES,
)
from tests.differential.semantic_decimal_advanced_cases import (
    CONTROL_SEED as DECIMAL_CONTROL_SEED,
    EDGE_SEED as DECIMAL_ADVANCED_EDGE_SEED,
    GENERATED_SEED as DECIMAL_GENERATED_SEED,
    SEED as DECIMAL_ADVANCED_SEED,
    SEMANTIC_DECIMAL_ADVANCED_CASES,
    SEMANTIC_DECIMAL_ADVANCED_EDGE_CASES,
    SEMANTIC_DECIMAL_CONTROL_CASES,
    SEMANTIC_DECIMAL_GENERATED_CASES,
)
from tests.differential.semantic_decimal_cases import (
    EDGE_SEED as DECIMAL_EDGE_SEED,
    SEED as DECIMAL_SEED,
    SEMANTIC_DECIMAL_CASES,
    SEMANTIC_DECIMAL_EDGE_CASES,
)
from tests.differential.semantic_document_order_cases import (
    SEED as DOCUMENT_ORDER_SEED,
    SEMANTIC_DOCUMENT_ORDER_CASES,
)
from tests.differential.semantic_expression_grammar_cases import (
    SEED as EXPRESSION_GRAMMAR_SEED,
    SEMANTIC_EXPRESSION_GRAMMAR_CASES,
)
from tests.differential.semantic_group_cases import SEMANTIC_GROUP_CASES
from tests.differential.semantic_merge_key_cases import (
    SEED as MERGE_KEY_SEED,
    SEMANTIC_MERGE_KEY_CASES,
)
from tests.differential.semantic_missing_cases import (
    SEED as MISSING_SEED,
    SEMANTIC_MISSING_CASES,
)
from tests.differential.semantic_mod_cases import (
    SEED as MOD_SEED,
    SEMANTIC_MOD_CASES,
)
from tests.differential.semantic_numeric_cases import (
    SEED as NUMERIC_SEED,
    SEMANTIC_NUMERIC_CASES,
)
from tests.differential.semantic_numeric_predicate_cases import (
    SEED as NUMERIC_PREDICATE_SEED,
    SEMANTIC_NUMERIC_PREDICATE_CASES,
)
from tests.differential.semantic_object_grammar_cases import (
    SEED as OBJECT_GRAMMAR_SEED,
    SEMANTIC_OBJECT_GRAMMAR_CASES,
)
from tests.differential.semantic_overflow_cases import (
    NUMERIC_CONTROL_SEED,
    SEED as OVERFLOW_SEED,
    SEMANTIC_NUMERIC_CONTROL_CASES,
    SEMANTIC_OVERFLOW_CASES,
)
from tests.differential.semantic_overflow_write_cases import (
    SEMANTIC_OVERFLOW_WRITE_CASES,
    WRITE_SEED as OVERFLOW_WRITE_SEED,
)
from tests.differential.semantic_query_matching_cases import (
    SEED as QUERY_MATCHING_SEED,
    SEMANTIC_QUERY_MATCHING_CASES,
)
from tests.differential.semantic_rename_command_cases import (
    SEED as RENAME_COMMAND_SEED,
    SEMANTIC_RENAME_COMMAND_CASES,
)
from tests.differential.semantic_schema_cases import (
    SEED as SCHEMA_SEED,
    SEMANTIC_SCHEMA_CASES,
)
from tests.differential.semantic_search_eligibility_cases import (
    SEED as SEARCH_ELIGIBILITY_SEED,
    SEMANTIC_SEARCH_ELIGIBILITY_CASES,
)
from tests.differential.semantic_sum_cases import (
    SEED as SUM_SEED,
    SEMANTIC_SUM_CASES,
    SEMANTIC_SUM_STREAM_CASES,
    STREAM_SEED as SUM_STREAM_SEED,
)
from tests.differential.semantic_ttl_publication_cases import (
    SEED as TTL_PUBLICATION_SEED,
    SEMANTIC_TTL_PUBLICATION_CASES,
)
from tests.differential.semantic_type_query_cases import (
    SEED as TYPE_QUERY_SEED,
    SEMANTIC_TYPE_QUERY_CASES,
)
from tests.differential.semantic_update_entrypoint_cases import (
    SEED as UPDATE_ENTRYPOINT_SEED,
    SEMANTIC_UPDATE_ENTRYPOINT_CASES,
)
from tests.differential.semantic_update_event_cases import (
    SEED as UPDATE_EVENT_SEED,
    SEMANTIC_UPDATE_EVENT_CASES,
)
from tests.differential.semantic_update_identity_cases import (
    SEED as UPDATE_IDENTITY_SEED,
    SEMANTIC_UPDATE_IDENTITY_CASES,
)
from tests.differential.semantic_watch_batch_cases import (
    SEED as WATCH_BATCH_SEED,
    SEMANTIC_WATCH_BATCH_CASES,
)
from tests.differential.semantic_watch_cases import (
    SEED as WATCH_SEED,
    SEMANTIC_WATCH_CASES,
)
from tests.differential.semantic_watch_checkpoint_cases import (
    SEED as WATCH_CHECKPOINT_SEED,
    SEMANTIC_WATCH_CHECKPOINT_CASES,
)
from tests.differential.semantic_watch_image_cases import (
    SEED as WATCH_IMAGE_SEED,
    SEMANTIC_WATCH_IMAGE_CASES,
)
from tests.differential.semantic_watch_lifecycle_cases import (
    SEED as WATCH_LIFECYCLE_SEED,
    SEMANTIC_WATCH_LIFECYCLE_CASES,
)
from tests.differential.semantic_watch_namespace_image_cases import (
    SEED as WATCH_NAMESPACE_IMAGE_SEED,
    SEMANTIC_WATCH_NAMESPACE_IMAGE_CASES,
)
from tests.differential.semantic_watch_protocol_cases import (
    SEED as WATCH_PROTOCOL_SEED,
    SEMANTIC_WATCH_PROTOCOL_CASES,
)
from tests.differential.semantic_watch_rename_cases import (
    SEED as WATCH_RENAME_SEED,
    SEMANTIC_WATCH_RENAME_CASES,
)
from tests.differential.semantic_watch_token_cases import (
    SEED as WATCH_TOKEN_SEED,
    SEMANTIC_WATCH_TOKEN_CASES,
)
from tests.differential.semantic_write_effect_cases import (
    SEED as WRITE_EFFECT_SEED,
    SEMANTIC_WRITE_EFFECT_CASES,
)


@dataclass(frozen=True)
class SemanticCorpus:
    case_set: str
    module: str
    seed: list
    cases: tuple
    observation_encoding: str = "bson"
    surfaces: tuple[str, ...] = ("sync", "async", "wire-sync", "wire-async")
    requires_replica_set: bool = False


SEMANTIC_CORPORA = {
    "bson_grammar_context": SemanticCorpus(
        "bson-grammar-context", "semantic_bson_grammar_context_cases",
        BSON_GRAMMAR_CONTEXT_SEED, SEMANTIC_BSON_GRAMMAR_CONTEXT_CASES,
    ),
    "merge_key": SemanticCorpus(
        "merge-key", "semantic_merge_key_cases", MERGE_KEY_SEED,
        SEMANTIC_MERGE_KEY_CASES,
    ),
    "binary_surface": SemanticCorpus(
        "binary-surface", "semantic_binary_surface_cases", BINARY_SURFACE_SEED,
        SEMANTIC_BINARY_SURFACE_CASES,
    ),
    "watch_namespace_image": SemanticCorpus(
        "watch-namespace-image", "semantic_watch_namespace_image_cases",
        WATCH_NAMESPACE_IMAGE_SEED, SEMANTIC_WATCH_NAMESPACE_IMAGE_CASES,
        surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "watch_batch": SemanticCorpus(
        "watch-batch", "semantic_watch_batch_cases", WATCH_BATCH_SEED,
        SEMANTIC_WATCH_BATCH_CASES, surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "watch_checkpoint": SemanticCorpus(
        "watch-checkpoint", "semantic_watch_checkpoint_cases", WATCH_CHECKPOINT_SEED,
        SEMANTIC_WATCH_CHECKPOINT_CASES, surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "watch_protocol": SemanticCorpus(
        "watch-protocol", "semantic_watch_protocol_cases", WATCH_PROTOCOL_SEED,
        SEMANTIC_WATCH_PROTOCOL_CASES, surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "watch_token": SemanticCorpus(
        "watch-token", "semantic_watch_token_cases", WATCH_TOKEN_SEED,
        SEMANTIC_WATCH_TOKEN_CASES, surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "rename_command": SemanticCorpus(
        "rename-command", "semantic_rename_command_cases", RENAME_COMMAND_SEED,
        SEMANTIC_RENAME_COMMAND_CASES,
    ),
    "watch_rename": SemanticCorpus(
        "watch-rename", "semantic_watch_rename_cases", WATCH_RENAME_SEED,
        SEMANTIC_WATCH_RENAME_CASES, surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "watch_lifecycle": SemanticCorpus(
        "watch-lifecycle", "semantic_watch_lifecycle_cases", WATCH_LIFECYCLE_SEED,
        SEMANTIC_WATCH_LIFECYCLE_CASES, surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "watch_image": SemanticCorpus(
        "watch-image", "semantic_watch_image_cases", WATCH_IMAGE_SEED,
        SEMANTIC_WATCH_IMAGE_CASES, surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "watch": SemanticCorpus(
        "watch",
        "semantic_watch_cases",
        WATCH_SEED,
        SEMANTIC_WATCH_CASES,
        surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "update_entrypoint": SemanticCorpus(
        "update-entrypoint",
        "semantic_update_entrypoint_cases",
        UPDATE_ENTRYPOINT_SEED,
        SEMANTIC_UPDATE_ENTRYPOINT_CASES,
        surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "update_event": SemanticCorpus(
        "update-event",
        "semantic_update_event_cases",
        UPDATE_EVENT_SEED,
        SEMANTIC_UPDATE_EVENT_CASES,
        surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "bson_size": SemanticCorpus(
        "bson-size",
        "semantic_bson_size_cases",
        BSON_SIZE_SEED,
        SEMANTIC_BSON_SIZE_CASES,
    ),
    "write_effect": SemanticCorpus(
        "write-effect",
        "semantic_write_effect_cases",
        WRITE_EFFECT_SEED,
        SEMANTIC_WRITE_EFFECT_CASES,
    ),
    "type_query": SemanticCorpus(
        "type-query",
        "semantic_type_query_cases",
        TYPE_QUERY_SEED,
        SEMANTIC_TYPE_QUERY_CASES,
    ),
    "dbref_grammar": SemanticCorpus(
        "dbref-grammar",
        "semantic_dbref_grammar_cases",
        DBREF_GRAMMAR_SEED,
        SEMANTIC_DBREF_GRAMMAR_CASES,
    ),
    "binary_edges": SemanticCorpus(
        "binary-edges",
        "semantic_binary_edge_cases",
        BINARY_EDGE_SEED,
        SEMANTIC_BINARY_EDGE_CASES,
    ),
    "ttl_publication": SemanticCorpus(
        "ttl-publication",
        "semantic_ttl_publication_cases",
        TTL_PUBLICATION_SEED,
        SEMANTIC_TTL_PUBLICATION_CASES,
        surfaces=("sync", "async"),
        requires_replica_set=True,
    ),
    "datetime": SemanticCorpus(
        "datetime",
        "semantic_datetime_cases",
        DATETIME_SEED,
        SEMANTIC_DATETIME_CASES,
    ),
    "update_identity": SemanticCorpus(
        "update-identity",
        "semantic_update_identity_cases",
        UPDATE_IDENTITY_SEED,
        SEMANTIC_UPDATE_IDENTITY_CASES,
    ),
    "binary": SemanticCorpus(
        "binary",
        "semantic_binary_cases",
        BINARY_SEED,
        SEMANTIC_BINARY_CASES,
    ),
    "mod": SemanticCorpus(
        "mod",
        "semantic_mod_cases",
        MOD_SEED,
        SEMANTIC_MOD_CASES,
        observation_encoding="canonical-json",
    ),
    "search_eligibility": SemanticCorpus(
        "search-eligibility",
        "semantic_search_eligibility_cases",
        SEARCH_ELIGIBILITY_SEED,
        SEMANTIC_SEARCH_ELIGIBILITY_CASES,
    ),
    "schema": SemanticCorpus(
        "schema",
        "semantic_schema_cases",
        SCHEMA_SEED,
        SEMANTIC_SCHEMA_CASES,
        observation_encoding="canonical-json",
    ),
    "query_matching": SemanticCorpus(
        "query-matching",
        "semantic_query_matching_cases",
        QUERY_MATCHING_SEED,
        SEMANTIC_QUERY_MATCHING_CASES,
    ),
    "object_grammar": SemanticCorpus(
        "object-grammar",
        "semantic_object_grammar_cases",
        OBJECT_GRAMMAR_SEED,
        SEMANTIC_OBJECT_GRAMMAR_CASES,
    ),
    "command_let": SemanticCorpus(
        "command-let",
        "semantic_command_let_cases",
        COMMAND_LET_SEED,
        SEMANTIC_COMMAND_LET_CASES,
        observation_encoding="canonical-json",
    ),
    "expression_grammar": SemanticCorpus(
        "expression-grammar",
        "semantic_expression_grammar_cases",
        EXPRESSION_GRAMMAR_SEED,
        SEMANTIC_EXPRESSION_GRAMMAR_CASES,
    ),
    "overflow_numeric_controls": SemanticCorpus(
        "overflow-numeric-controls",
        "semantic_overflow_cases",
        NUMERIC_CONTROL_SEED,
        SEMANTIC_NUMERIC_CONTROL_CASES,
    ),
    "overflow": SemanticCorpus(
        "overflow-values",
        "semantic_overflow_cases",
        OVERFLOW_SEED,
        SEMANTIC_OVERFLOW_CASES,
    ),
    "overflow_writes": SemanticCorpus(
        "overflow-writes",
        "semantic_overflow_write_cases",
        OVERFLOW_WRITE_SEED,
        SEMANTIC_OVERFLOW_WRITE_CASES,
        observation_encoding="canonical-json",
    ),
    "average_routes": SemanticCorpus(
        "average-routes",
        "semantic_average_route_cases",
        AVERAGE_ROUTE_SEED,
        SEMANTIC_AVERAGE_ROUTE_CASES,
    ),
    "sum_stream": SemanticCorpus(
        "sum-stream",
        "semantic_sum_cases",
        SUM_STREAM_SEED,
        SEMANTIC_SUM_STREAM_CASES,
    ),
    "sum": SemanticCorpus(
        "sum-values", "semantic_sum_cases", SUM_SEED, SEMANTIC_SUM_CASES
    ),
    "decimal_controls": SemanticCorpus(
        "decimal-controls",
        "semantic_decimal_advanced_cases",
        DECIMAL_CONTROL_SEED,
        SEMANTIC_DECIMAL_CONTROL_CASES,
    ),
    "decimal_generated": SemanticCorpus(
        "decimal-generated",
        "semantic_decimal_advanced_cases",
        DECIMAL_GENERATED_SEED,
        SEMANTIC_DECIMAL_GENERATED_CASES,
    ),
    "decimal_advanced": SemanticCorpus(
        "decimal-advanced",
        "semantic_decimal_advanced_cases",
        DECIMAL_ADVANCED_SEED,
        SEMANTIC_DECIMAL_ADVANCED_CASES,
    ),
    "decimal_advanced_edges": SemanticCorpus(
        "decimal-advanced-edges",
        "semantic_decimal_advanced_cases",
        DECIMAL_ADVANCED_EDGE_SEED,
        SEMANTIC_DECIMAL_ADVANCED_EDGE_CASES,
    ),
    "decimal_edges": SemanticCorpus(
        "decimal-edges",
        "semantic_decimal_cases",
        DECIMAL_EDGE_SEED,
        SEMANTIC_DECIMAL_EDGE_CASES,
    ),
    "decimal": SemanticCorpus(
        "decimal-values",
        "semantic_decimal_cases",
        DECIMAL_SEED,
        SEMANTIC_DECIMAL_CASES,
    ),
    "document_order": SemanticCorpus(
        "document-order",
        "semantic_document_order_cases",
        DOCUMENT_ORDER_SEED,
        SEMANTIC_DOCUMENT_ORDER_CASES,
    ),
    "group_parity": SemanticCorpus(
        "semantic-fixes",
        "semantic_group_cases",
        [{"_id": 1}, {"_id": 2}],
        SEMANTIC_GROUP_CASES,
    ),
    "missing": SemanticCorpus(
        "missing-values",
        "semantic_missing_cases",
        MISSING_SEED,
        SEMANTIC_MISSING_CASES,
    ),
    "absence_consumers": SemanticCorpus(
        "absence-consumers",
        "semantic_absence_consumer_cases",
        ABSENCE_SEED,
        SEMANTIC_ABSENCE_CONSUMER_CASES,
    ),
    "numeric": SemanticCorpus(
        "numeric-values",
        "semantic_numeric_cases",
        NUMERIC_SEED,
        SEMANTIC_NUMERIC_CASES,
    ),
    "numeric_predicates": SemanticCorpus(
        "numeric-predicates",
        "semantic_numeric_predicate_cases",
        NUMERIC_PREDICATE_SEED,
        SEMANTIC_NUMERIC_PREDICATE_CASES,
    ),
}
