import asyncio
import datetime
import tempfile
import unittest

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from mongoeco import AsyncMongoClient, MongoClient
from mongoeco.api._async.aggregation_cursor import (
    AsyncAggregationCursor,
    _CursorPageSource,
    _RemainingWindow,
    _SearchOptimizationPlan,
    _SearchOptimizationStrategy,
)
from mongoeco.api._async.client import AsyncDatabase
from mongoeco.api._sync.aggregation_cursor import (
    AggregationCursor,
    _AggregationCursorIterator,
)
from mongoeco.api.operations import compile_aggregate_operation
from mongoeco.compat import MONGODB_DIALECT_70
from mongoeco.core.aggregation import (
    _CURRENT_COLLECTION_RESOLVER_KEY,
    AggregationCostPolicy,
    AggregationSpillPolicy,
    register_aggregation_stage,
    unregister_aggregation_stage,
)
from mongoeco.core.aggregation.spill import _AggregationGroupStateSerializationError
from mongoeco.core.bson_scalars import BsonInt32
from mongoeco.core.operation_context import OperationContext
from mongoeco.core.projections import apply_projection
from mongoeco.core.query_plan import MatchAll
from mongoeco.core.search import collect_search_metadata
from mongoeco.core.search_models import SearchExecutionOutcome
from mongoeco.core.sorting import sort_documents
from mongoeco.engines import EngineCapabilities, SearchEngineCapabilities
from mongoeco.engines.memory import MemoryEngine
from mongoeco.engines.sqlite import SQLiteEngine
from mongoeco.errors import (
    ExecutionTimeout,
    InvalidOperation,
    OperationFailure,
)
from mongoeco.session import ClientSession
from mongoeco.types import PlanningIssue, PlanningMode, SearchIndexModel
from tests.unit.api._collection_test_support import _SpiV2EngineStub


def _aggregation_sort_temp_paths() -> set[Path]:
    return set(Path(tempfile.gettempdir()).glob("*.mongoeco-aggsort"))


def _aggregation_group_temp_paths() -> set[Path]:
    return set(Path(tempfile.gettempdir()).glob("*.mongoeco-agggroup"))


class _FakeAsyncFindCursor:
    def __init__(self, documents):
        self._documents = documents
        self._offset = 0
        self._plan = MatchAll()
        self.to_list_lengths = []
        self.pull_chunk_sizes = []
        self.close_calls = 0

    def __aiter__(self):
        return self

    async def pull_chunk(self, length):
        self.pull_chunk_sizes.append(length)
        page = self._documents[self._offset : self._offset + length]
        self._offset += len(page)
        return list(page)

    async def to_list(self, length=None):
        self.to_list_lengths.append(length)
        if length is None:
            return list(self._documents)
        return list(self._documents[:length])

    async def close(self):
        self.close_calls += 1


class _FakeCollection:
    def __init__(self, documents):
        self._documents = documents
        self.calls = []
        self.built_operations = []
        self._engine = _FakeEngine()
        self._db_name = "db"
        self._collection_name = "coll"

    def find(
        self,
        filter_spec=None,
        projection=None,
        *,
        collation=None,
        sort=None,
        skip=0,
        limit=None,
        hint=None,
        comment=None,
        max_time_ms=None,
        batch_size=None,
        session=None,
    ):
        self.calls.append(
            {
                "filter_spec": filter_spec,
                "projection": projection,
                "sort": sort,
                "skip": skip,
                "limit": limit,
                "hint": hint,
                "comment": comment,
                "max_time_ms": max_time_ms,
                "batch_size": batch_size,
                "session": session,
            }
        )
        if collation is not None:
            self.calls[-1]["collation"] = collation
        documents = list(self._documents)
        documents = sort_documents(documents, sort)
        if skip:
            documents = documents[skip:]
        if limit is not None:
            documents = documents[:limit]
        if projection is not None:
            documents = [
                apply_projection(document, projection) for document in documents
            ]
        cursor = _FakeAsyncFindCursor(documents)
        self.last_find_cursor = cursor
        return cursor

    def _build_cursor(self, operation, *, session=None):
        self.built_operations.append((operation, session))
        return self.find(
            operation.filter_spec,
            operation.projection,
            sort=operation.sort,
            skip=operation.skip,
            limit=operation.limit,
            hint=operation.hint,
            comment=operation.comment,
            max_time_ms=operation.max_time_ms,
            batch_size=operation.batch_size,
            session=session,
        )


class _FakeEngine(_SpiV2EngineStub):
    def __init__(self):
        self.explain_semantics_calls = []
        self.scan_semantics_calls = []
        self.aggregation_spill_policy = AggregationSpillPolicy(threshold=1)
        self.aggregation_cost_policy = None

    async def explain_find_semantics(self, db_name, coll_name, semantics, **kwargs):
        self.explain_semantics_calls.append((db_name, coll_name, semantics, kwargs))
        return {"engine": "fake", "details": ["IXSCAN"]}

    def scan_find_semantics(self, db_name, coll_name, semantics, **kwargs):
        self.scan_semantics_calls.append((db_name, coll_name, semantics, kwargs))

        async def _iter():
            if coll_name == "coll":
                yield {"_id": "1", "name": "Ada"}
            elif coll_name == "roles":
                yield {"_id": "r1", "label": "admin"}

        return _iter()


def _enable_search(
    engine: _FakeEngine,
    execute,
    *,
    metadata_collectors: bool = False,
) -> None:
    engine.capabilities = EngineCapabilities(
        batch_inserts=False,
        explicit_read_snapshots=False,
        search=SearchEngineCapabilities(
            metadata_collectors=metadata_collectors,
        ),
    )
    engine.execute_search = execute


class _SyncClientStub:
    def _run(self, awaitable):
        import asyncio

        return asyncio.run(awaitable)


class _DeferredCleanupSyncClientStub(_SyncClientStub):
    def __init__(self):
        self.deferred_cleanup = []

    def _defer_cleanup(self, operation):
        self.deferred_cleanup.append(operation)
        return True

    def run_deferred_cleanup(self):
        for operation in self.deferred_cleanup:
            operation()
        self.deferred_cleanup.clear()


class _CountingSyncClientStub(_SyncClientStub):
    def __init__(self):
        self.run_calls = 0

    def _run(self, awaitable):
        self.run_calls += 1
        return super()._run(awaitable)


class _BrokenSyncClientStub:
    def _run(self, awaitable):
        close = getattr(awaitable, "close", None)
        if callable(close):
            close()
        raise RuntimeError("boom")


class _AsyncAggregationCursorStub:
    def __init__(self, documents):
        self.documents = documents
        self.to_list_calls = 0
        self.first_calls = 0
        self.close_calls = 0
        self._iterator = None

    async def to_list(self):
        self.to_list_calls += 1
        return list(self.documents)

    async def first(self):
        self.first_calls += 1
        return self.documents[0] if self.documents else None

    def __aiter__(self):
        self._iterator = iter(self.documents)
        return self

    async def __anext__(self):
        if self._iterator is None:
            self._iterator = iter(self.documents)
        try:
            return next(self._iterator)
        except StopIteration as exc:
            raise StopAsyncIteration from exc

    async def aclose(self):
        self.close_calls += 1


class _FailingAsyncAggregationCursorStub(_AsyncAggregationCursorStub):
    async def __anext__(self):
        raise InvalidOperation("foreign session")


class AsyncAggregationCursorTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        super().setUp()
        temporary = self.enterContext(
            tempfile.TemporaryDirectory(prefix="mongoeco-cursor-work-control-")
        )
        self.enterContext(patch.object(tempfile, "tempdir", temporary))

    def test_remaining_window_consumes_whole_pages_before_partial_page(self):
        window = _RemainingWindow(skip=3, limit=2)

        self.assertEqual(window.apply([{"_id": 1}, {"_id": 2}]), [])
        self.assertEqual(
            window.apply([{"_id": 3}, {"_id": 4}, {"_id": 5}]),
            [{"_id": 4}, {"_id": 5}],
        )
        self.assertFalse(window.open)

    async def test_cursor_page_source_falls_back_to_materialization_and_iterator_close(
        self,
    ):
        class Iterator:
            def __init__(self):
                self.closed = False

            async def aclose(self):
                self.closed = True

        class Cursor:
            def __init__(self):
                self.iterator = Iterator()

            def __aiter__(self):
                return self.iterator

            async def to_list(self):
                return [{"_id": 1}, {"_id": 2}, {"_id": 3}]

        cursor = Cursor()
        source = _CursorPageSource(cursor)
        await source.prepare()

        self.assertEqual(await source.pull(2), [{"_id": 1}, {"_id": 2}])
        self.assertEqual(await source.pull(2), [{"_id": 3}])
        await source.aclose()
        self.assertTrue(cursor.iterator.closed)

    def test_bound_operation_context_crosses_cursor_boundary_by_identity(self):
        context = OperationContext.create(dialect=MONGODB_DIALECT_70)
        operation = compile_aggregate_operation([]).bind(context)

        cursor = AsyncAggregationCursor(_FakeCollection([]), operation)

        self.assertIs(cursor._operation_context, context)
        self.assertIs(cursor._execution_context, context.expressions)

    async def test_search_optimization_plan_rejects_incoherent_states(self):
        invalid_plans = (
            {
                "strategy": _SearchOptimizationStrategy.DIRECT_WINDOW,
            },
            {
                "strategy": _SearchOptimizationStrategy.PREFIX_ITERATIVE,
            },
            {
                "strategy": _SearchOptimizationStrategy.EMPTY,
                "result_limit_hint": 1,
            },
            {
                "strategy": _SearchOptimizationStrategy.FULL,
                "result_limit_hint": 1,
            },
        )
        for kwargs in invalid_plans:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                _SearchOptimizationPlan(**kwargs)

        iterative = _SearchOptimizationPlan(
            strategy=_SearchOptimizationStrategy.PREFIX_ITERATIVE,
            prefix_output_limit=2,
        )
        self.assertEqual(iterative.explain_limit_hint, 2)
        self.assertEqual(
            AsyncAggregationCursor._search_runtime_spec_for_stage("$search", {}),
            {},
        )

        cursor = AsyncAggregationCursor(_FakeCollection([]), [])
        cursor._operation_context = None
        with self.assertRaisesRegex(RuntimeError, "OperationContext"):
            cursor._build_search_request(
                "$search",
                {"text": {"query": "ada", "path": "title"}},
                result_limit_hint=None,
                downstream_filter_spec=None,
            )
        with self.assertRaisesRegex(ValueError, "verbosity"):
            await cursor.explain("invalid")

    def test_cxp_projection_reports_catalog_verdicts_for_search_paths(
        self,
    ):
        collection = _FakeCollection([])

        plain = AsyncAggregationCursor(collection, [])
        text_search = AsyncAggregationCursor(
            collection,
            [{"$search": {"text": {"query": "ada", "path": "name"}}}],
        )
        vector_search = AsyncAggregationCursor(
            collection,
            [
                {
                    "$vectorSearch": {
                        "path": "embedding",
                        "queryVector": [0.1],
                        "numCandidates": 5,
                        "limit": 2,
                    }
                }
            ],
        )

        self.assertEqual(
            plain._cxp_explain_projection()["profileVerdicts"]["mongodb-core"],
            "compatible",
        )
        self.assertEqual(
            plain._cxp_explain_projection()["operationName"],
            "aggregate",
        )
        self.assertTrue(
            plain._cxp_explain_projection()["operationMetadata"][
                "supportsDatabaseScope"
            ]
        )
        self.assertEqual(
            text_search._cxp_explain_projection()["profileVerdicts"][
                "mongodb-text-search"
            ],
            "compatible",
        )
        self.assertEqual(
            text_search._cxp_explain_projection()["operationName"],
            "aggregate",
        )
        self.assertEqual(
            text_search._cxp_explain_projection()["operationMetadata"][
                "aggregateStage"
            ],
            "$search",
        )
        self.assertEqual(
            vector_search._cxp_explain_projection()["profileVerdicts"][
                "mongodb-search"
            ],
            "compatible",
        )
        self.assertEqual(
            vector_search._cxp_explain_projection()["operationName"],
            "aggregate",
        )
        self.assertEqual(
            vector_search._cxp_explain_projection()["operationMetadata"][
                "aggregateStage"
            ],
            "$vectorSearch",
        )
        self.assertEqual(
            vector_search._cxp_explain_projection()["additionalCapabilities"],
            ["vector_search"],
        )

    def test_search_result_limit_hint_is_only_exposed_for_safe_trailing_window(
        self,
    ):
        self.assertEqual(
            AsyncAggregationCursor._search_result_limit_hint(
                [{"$project": {"_id": 1}}, {"$skip": 2}, {"$limit": 3}]
            ),
            5,
        )
        self.assertIsNone(
            AsyncAggregationCursor._search_result_limit_hint(
                [{"$match": {"kind": "view"}}, {"$limit": 3}]
            )
        )
        self.assertEqual(
            AsyncAggregationCursor._search_prefix_output_limit(
                [{"$match": {"kind": "view"}}, {"$limit": 3}]
            ),
            3,
        )
        self.assertEqual(
            AsyncAggregationCursor._search_prefix_output_limit(
                [{"$limit": 5}, {"$skip": 2}, {"$project": {"_id": 1}}]
            ),
            3,
        )
        self.assertIsNone(
            AsyncAggregationCursor._search_prefix_output_limit(
                [{"$sort": {"rank": 1}}, {"$limit": 3}]
            )
        )
        self.assertEqual(
            AsyncAggregationCursor._next_search_prefix_fetch_limit(
                10,
                10,
                4,
                10,
            ),
            31,
        )
        self.assertEqual(
            AsyncAggregationCursor._next_search_prefix_fetch_limit(
                5,
                5,
                0,
                2,
            ),
            20,
        )
        self.assertIsNone(AsyncAggregationCursor._search_result_limit_hint(["bad"]))  # type: ignore[list-item]
        self.assertIsNone(AsyncAggregationCursor._search_prefix_output_limit(["bad"]))  # type: ignore[list-item]
        self.assertIsNone(
            AsyncAggregationCursor._leading_search_downstream_filter_spec(
                [{"$match": "bad"}]  # type: ignore[list-item]
            )
        )
        self.assertEqual(
            AsyncAggregationCursor._leading_search_downstream_filter_spec(
                [
                    {"$match": {"kind": "note"}},
                    {"$match": {"active": True}},
                    {"$project": {"_id": 1}},
                ]
            ),
            {"$and": [{"kind": "note"}, {"active": True}]},
        )
        self.assertIsNone(
            AsyncAggregationCursor._leading_search_downstream_filter_spec(
                [{"$match": {"$expr": {"$ne": ["$$NOW", None]}}}]
            )
        )
        self.assertIsNone(
            AsyncAggregationCursor._leading_search_downstream_filter_spec(
                [{"$match": {"kind": "note"}, "$project": {"_id": 1}}]
            )
        )

        cursor = AsyncAggregationCursor(_FakeCollection([]), [])
        collector_plan = cursor._search_optimization_plan(
            "$search",
            {"count": {"type": "total"}},
            [{"$match": {"kind": "note"}}, {"$limit": 1}],
            writeback=False,
        )
        self.assertIsNone(collector_plan.result_limit_hint)
        self.assertIsNone(collector_plan.downstream_filter_spec)
        self.assertIsNone(collector_plan.prefix_output_limit)

        highlight_plan = cursor._search_optimization_plan(
            "$search",
            {"highlight": {"path": "title"}},
            [{"$match": {"searchHighlights.0.path": "title"}}, {"$limit": 1}],
            writeback=False,
        )
        self.assertIsNone(highlight_plan.downstream_filter_spec)
        self.assertEqual(highlight_plan.prefix_output_limit, 1)

    async def test_search_helpers_cover_missing_invalid_and_engine_fallback_paths(
        self,
    ):
        collection = _FakeCollection([])
        cursor = AsyncAggregationCursor(collection, [])
        self.assertIsNone(cursor._leading_search_stage())

        with self.assertRaisesRegex(OperationFailure, "single-key document"):
            AsyncAggregationCursor(collection, ["invalid"])  # type: ignore[list-item]

        cursor = AsyncAggregationCursor(
            collection,
            [{"$search": {"text": {"query": "Ada", "path": "name"}}}],
        )
        with self.assertRaisesRegex(OperationFailure, "not supported by this engine"):
            await cursor._search_documents()

        with self.assertRaisesRegex(OperationFailure, "search stage was not present"):
            await AsyncAggregationCursor(collection, [])._search_documents()

    async def test_search_meta_helper_maps_to_search_and_returns_metadata(
        self,
    ):
        collection = _FakeCollection([])
        calls: list[str] = []

        async def _execute_search(_db_name, _coll_name, request):
            calls.append(str(request.effective_operator))
            documents = [
                {"_id": "1", "kind": "note"},
                {"_id": "2", "kind": "reference"},
            ]
            return SearchExecutionOutcome(
                metadata=collect_search_metadata(
                    documents,
                    query=request.query,
                ),
            )

        _enable_search(
            collection._engine,
            _execute_search,
            metadata_collectors=True,
        )
        cursor = AsyncAggregationCursor(
            collection,
            [
                {
                    "$searchMeta": {
                        "index": "by_text",
                        "text": {"query": "ada", "path": "name"},
                        "count": {"type": "total"},
                        "facet": {"path": "kind", "numBuckets": 2},
                    }
                }
            ],
        )

        self.assertEqual(
            await cursor._search_documents(),
            [
                {
                    "count": {"total": 2, "exact": True},
                    "facet": {
                        "type": "string",
                        "path": "kind",
                        "numBuckets": 2,
                        "buckets": [
                            {"value": "note", "count": 1},
                            {"value": "reference", "count": 1},
                        ],
                    },
                }
            ],
        )
        self.assertEqual(calls, ["$search"])

        with self.assertRaisesRegex(
            OperationFailure,
            "\\$searchMeta requires at least one of count or facet",
        ):
            await AsyncAggregationCursor(
                collection,
                [
                    {
                        "$searchMeta": {
                            "index": "by_text",
                            "text": {"query": "ada", "path": "name"},
                        }
                    }
                ],
            )._search_documents()
        with self.assertRaisesRegex(
            OperationFailure, "\\$searchMeta does not support highlight"
        ):
            await AsyncAggregationCursor(
                collection,
                [
                    {
                        "$searchMeta": {
                            "index": "by_text",
                            "text": {"query": "ada", "path": "name"},
                            "count": {"type": "total"},
                            "highlight": {"path": "name"},
                        }
                    }
                ],
            )._search_documents()

    async def test_search_meta_helper_supports_facet_operator_collector_runtime_projection(
        self,
    ):
        collection = _FakeCollection([])
        seen_specs: list[object] = []

        async def _execute_search(_db_name, _coll_name, request):
            seen_specs.append(request.effective_specification)
            return SearchExecutionOutcome(
                metadata=collect_search_metadata(
                    [{"_id": "1", "kind": "note"}],
                    query=request.query,
                ),
            )

        _enable_search(
            collection._engine,
            _execute_search,
            metadata_collectors=True,
        )
        cursor = AsyncAggregationCursor(
            collection,
            [
                {
                    "$searchMeta": {
                        "index": "by_text",
                        "facet": {
                            "operator": {"text": {"query": "ada", "path": "name"}},
                            "facets": {"kindFacet": {"path": "kind", "numBuckets": 2}},
                        },
                    }
                }
            ],
        )

        self.assertEqual(
            await cursor._search_documents(),
            [
                {
                    "facet": {
                        "facets": {
                            "kindFacet": {
                                "type": "string",
                                "path": "kind",
                                "numBuckets": 2,
                                "buckets": [{"value": "note", "count": 1}],
                            }
                        }
                    }
                }
            ],
        )
        self.assertEqual(
            seen_specs,
            [
                {
                    "index": "by_text",
                    "facet": {
                        "facets": {"kindFacet": {"path": "kind", "numBuckets": 2}}
                    },
                    "text": {"query": "ada", "path": "name"},
                }
            ],
        )

    def test_search_runtime_spec_projection_keeps_ambiguous_facet_operator_unchanged(
        self,
    ):
        original_spec = {
            "index": "by_text",
            "facet": {
                "operator": {
                    "text": {"query": "ada", "path": "name"},
                    "phrase": {"query": "ada", "path": "name"},
                },
                "facets": {"kindFacet": {"path": "kind", "numBuckets": 2}},
            },
        }

        projected_spec = AsyncAggregationCursor._search_runtime_spec_for_stage(
            "$searchMeta", original_spec
        )

        self.assertIs(projected_spec, original_spec)

    def test_build_pushdown_cursor_reraises_unrelated_type_errors_from_builder(
        self,
    ):
        class BrokenBuilderCollection(_FakeCollection):
            def _build_cursor(self, operation, *, session=None, **kwargs):  # type: ignore[override]
                del operation, session, kwargs
                raise TypeError("boom")

        collection = BrokenBuilderCollection([])
        cursor = AsyncAggregationCursor(
            collection, [{"$project": {"_id": 1}}], batch_size=2
        )
        operation = cursor._pushdown_find_operation(batch_size=2)

        with self.assertRaisesRegex(TypeError, "boom"):
            cursor._build_pushdown_cursor(operation)

    async def test_search_materialization_expands_prefix_for_match_then_limit(
        self,
    ):
        collection = _FakeCollection([])
        calls: list[int | None] = []
        search_documents = [
            {"_id": "1", "kind": "drop"},
            {"_id": "2", "kind": "drop"},
            {"_id": "3", "kind": "keep"},
        ]

        async def _execute_search(_db_name, _coll_name, request):
            calls.append(request.result_limit_hint)
            limit_hint = request.result_limit_hint
            if isinstance(limit_hint, int) and limit_hint > 0:
                documents = search_documents[:limit_hint]
            else:
                documents = list(search_documents)
            return SearchExecutionOutcome.from_documents(
                documents,
                backend="fake",
                operation_id=request.operation_context.operation_id,
            )

        _enable_search(collection._engine, _execute_search)
        cursor = AsyncAggregationCursor(
            collection,
            [
                {"$search": {"text": {"query": "keep", "path": "kind"}}},
                {"$match": {"kind": "keep"}},
                {"$limit": 1},
            ],
        )

        self.assertEqual(await cursor.to_list(), [{"_id": "3", "kind": "keep"}])
        self.assertEqual(calls, [1, 4])

    async def test_materialize_leading_search_pipeline_returns_empty_for_zero_prefix_limit(
        self,
    ):
        collection = _FakeCollection([])

        observed_limit_hints = []

        async def _execute_search(_db_name, _coll_name, request):
            observed_limit_hints.append(request.result_limit_hint)
            return SearchExecutionOutcome.from_documents(
                [],
                backend="fake",
                operation_id=request.operation_context.operation_id,
            )

        _enable_search(collection._engine, _execute_search)
        cursor = AsyncAggregationCursor(
            collection,
            [
                {"$search": {"text": {"query": "keep", "path": "kind"}}},
                {"$limit": 0},
            ],
        )

        with (
            patch.object(cursor, "_search_result_limit_hint", return_value=None),
            patch.object(cursor, "_search_prefix_output_limit", return_value=0),
        ):
            self.assertEqual(
                await cursor._materialize_leading_search_pipeline(
                    [{"$limit": 0}],
                    dialect=None,
                ),
                ([], [{"$limit": 0}]),
            )
        self.assertEqual(observed_limit_hints, [0])

    async def test_materialize_leading_search_pipeline_rejects_missing_stage_and_engine_without_search(
        self,
    ):
        collection = _FakeCollection([])
        cursor = AsyncAggregationCursor(collection, [])
        with (
            patch.object(cursor, "_search_result_limit_hint", return_value=None),
            patch.object(cursor, "_search_prefix_output_limit", return_value=1),
            patch.object(cursor, "_leading_search_stage", return_value=None),
        ):
            with self.assertRaisesRegex(
                OperationFailure, "search stage was not present"
            ):
                await cursor._materialize_leading_search_pipeline(
                    [{"$match": {"kind": "note"}}], dialect=None
                )

        cursor = AsyncAggregationCursor(
            collection,
            [{"$search": {"text": {"query": "Ada", "path": "name"}}}],
        )
        with (
            patch.object(cursor, "_search_result_limit_hint", return_value=None),
            patch.object(cursor, "_search_prefix_output_limit", return_value=1),
        ):
            with self.assertRaisesRegex(
                OperationFailure, "\\$search is not supported by this engine"
            ):
                await cursor._materialize_leading_search_pipeline(
                    [{"$match": {"kind": "note"}}], dialect=None
                )

    async def test_leading_search_downstream_filter_keeps_or_match_with_sibling_fields(
        self,
    ):
        filter_spec = {
            "$or": [
                {"planning_status": {"$exists": False}},
                {"planning_status": "active"},
            ],
            "completed_at": None,
            "task_type": {"$in": ["work_unit", "content_update"]},
        }

        for engine_cls in (MemoryEngine, SQLiteEngine):
            with self.subTest(engine=engine_cls.__name__):
                async with AsyncMongoClient(engine_cls()) as client:
                    collection = client.db.tasks
                    await collection.insert_many(
                        [
                            {
                                "_id": "task-1",
                                "title": "migration candidate",
                                "planning_status": "active",
                                "completed_at": None,
                                "task_type": "work_unit",
                            },
                            {
                                "_id": "task-2",
                                "title": "migration candidate",
                                "planning_status": "retired",
                                "completed_at": None,
                                "task_type": "work_unit",
                            },
                            {
                                "_id": "task-3",
                                "title": "migration candidate",
                                "planning_status": "active",
                                "completed_at": "done",
                                "task_type": "work_unit",
                            },
                            {
                                "_id": "task-4",
                                "title": "migration candidate",
                                "completed_at": None,
                                "task_type": "content_update",
                            },
                        ]
                    )
                    await collection.create_search_indexes(
                        [
                            SearchIndexModel(
                                {
                                    "mappings": {
                                        "dynamic": False,
                                        "fields": {
                                            "title": {"type": "string"},
                                            "planning_status": {"type": "token"},
                                            "task_type": {"type": "token"},
                                            "completed_at": {"type": "token"},
                                        },
                                    }
                                },
                                name="by_text",
                            )
                        ]
                    )

                    documents = await collection.aggregate(
                        [
                            {
                                "$search": {
                                    "index": "by_text",
                                    "text": {
                                        "query": "migration",
                                        "path": "title",
                                    },
                                }
                            },
                            {"$match": filter_spec},
                            {"$project": {"_id": 1}},
                            {"$sort": {"_id": 1}},
                        ]
                    ).to_list()

                    self.assertEqual(documents, [{"_id": "task-1"}, {"_id": "task-4"}])

    async def test_allow_disk_use_false_disables_engine_spill_policy(self):
        collection = _FakeCollection([{"_id": "1", "rank": 2}, {"_id": "2", "rank": 1}])
        cursor = AsyncAggregationCursor(
            collection,
            compile_aggregate_operation(
                [{"$sort": {"rank": 1}}],
                allow_disk_use=False,
            ),
        )

        self.assertIsNone(cursor._spill_policy())

    async def test_collection_aggregate_accepts_pymongo_allow_disk_use_alias(
        self,
    ):
        async with AsyncMongoClient(MemoryEngine()) as client:
            collection = client.db.events
            await collection.insert_many(
                [
                    {"_id": "1", "rank": 2},
                    {"_id": "2", "rank": 1},
                ],
            )

            documents = await collection.aggregate(
                [{"$sort": {"rank": 1}}],
                allowDiskUse=True,
            ).to_list()

            self.assertEqual([document["_id"] for document in documents], ["2", "1"])
            with self.assertRaisesRegex(
                TypeError,
                "cannot pass both allowDiskUse and allow_disk_use",
            ):
                collection.aggregate([], allow_disk_use=True, allowDiskUse=True)

    async def test_aggregation_cursor_converts_internal_bson_wrappers_to_public_documents(
        self,
    ):
        collection = _FakeCollection([{"_id": "1", "score": BsonInt32(1)}])
        cursor = AsyncAggregationCursor(
            collection,
            [{"$project": {"score": {"$add": ["$score", 1]}, "_id": 0}}],
        )

        self.assertEqual(await cursor.to_list(), [{"score": 2}])

    async def test_collect_lookup_names_skips_invalid_stages_and_recurses_nested_pipelines(
        self,
    ):
        cursor = AsyncAggregationCursor(
            _FakeCollection([]),
            [],
        )

        names = cursor._collect_lookup_names(
            [
                "invalid",
                {"$lookup": []},
                {
                    "$lookup": {
                        "from": "users",
                        "pipeline": [
                            {
                                "$lookup": {
                                    "from": "roles",
                                    "localField": "role_id",
                                    "foreignField": "_id",
                                    "as": "roles",
                                }
                            }
                        ],
                        "as": "users",
                    }
                },
                {"$unionWith": "archive"},
                {
                    "$unionWith": {
                        "coll": "audits",
                        "pipeline": [
                            {
                                "$lookup": {
                                    "from": "teams",
                                    "localField": "team_id",
                                    "foreignField": "_id",
                                    "as": "teams",
                                }
                            }
                        ],
                    }
                },
                {
                    "$facet": {
                        "nested": [
                            {
                                "$lookup": {
                                    "from": "teams",
                                    "localField": "team_id",
                                    "foreignField": "_id",
                                    "as": "teams",
                                }
                            }
                        ]
                    }
                },
            ]
        )

        self.assertEqual(names, {"users", "roles", "teams", "archive", "audits"})

    async def test_collect_lookup_names_skips_invalid_union_with_payloads(
        self,
    ):
        cursor = AsyncAggregationCursor(
            _FakeCollection([]),
            [],
        )

        names = cursor._collect_lookup_names(
            [
                {"$unionWith": []},
                {"$unionWith": {"pipeline": []}},
                {"$unionWith": {"coll": "archive"}},
            ]
        )

        self.assertEqual(names, {"archive"})

    async def test_split_streamable_pipeline_uses_registered_stage_execution_mode(
        self,
    ):
        register_aggregation_stage(
            "$future",
            lambda documents, _spec, _context: documents,
            execution_mode="streamable",
        )
        try:
            stream_plan = AsyncAggregationCursor._split_streamable_pipeline(
                [{"$match": {"x": 1}}, {"$future": {}}, {"$limit": 1}]
            )
        finally:
            unregister_aggregation_stage("$future")

        self.assertEqual(stream_plan, ([{"$match": {"x": 1}}, {"$future": {}}], 0, 1))

    def test_incremental_group_and_sort_splitters_reject_unstreamable_shapes(self):
        self.assertIsNone(
            AsyncAggregationCursor._split_incremental_group_pipeline(["invalid"])
        )
        self.assertIsNone(
            AsyncAggregationCursor._split_incremental_group_pipeline(
                [
                    {"$limit": 1},
                    {"$match": {"kind": "view"}},
                    {"$group": {"_id": "$kind"}},
                ]
            )
        )
        self.assertIsNone(
            AsyncAggregationCursor._split_streaming_sort_suffix(
                [{"$match": {"kind": "view"}}]
            )
        )
        self.assertIsNone(
            AsyncAggregationCursor._split_streaming_sort_suffix(
                [
                    {"$sort": {"rank": 1}},
                    {"$limit": 1},
                    {"$match": {"kind": "view"}},
                ]
            )
        )
        self.assertIsNone(
            AsyncAggregationCursor._split_incremental_sort_pipeline(["invalid"])
        )
        self.assertIsNone(
            AsyncAggregationCursor._split_incremental_sort_pipeline(
                [
                    {"$limit": 1},
                    {"$match": {"kind": "view"}},
                    {"$sort": {"rank": 1}},
                ]
            )
        )

    def test_pushdown_cursor_does_not_mask_unrelated_type_error(self):
        class BrokenCollection:
            _engine = _FakeEngine()
            _db_name = "db"
            _collection_name = "coll"

            def find(self, *_args, **_kwargs):
                message = "unrelated failure"
                raise TypeError(message)

        cursor = AsyncAggregationCursor(BrokenCollection(), [])
        operation = cursor._pushdown_find_operation()

        with self.assertRaisesRegex(TypeError, "unrelated failure"):
            cursor._build_pushdown_cursor(operation)

    async def test_source_materialization_preserves_primary_and_cleanup_errors(self):
        class BrokenSource:
            async def to_list(self, length=None):
                del length
                message = "read failure"
                raise RuntimeError(message)

            async def close(self):
                message = "close failure"
                raise RuntimeError(message)

        cursor = AsyncAggregationCursor(_FakeCollection([]), [])
        with (
            patch.object(cursor, "_build_pushdown_cursor", return_value=BrokenSource()),
            self.assertRaisesRegex(RuntimeError, "read failure") as context,
        ):
            await cursor._load_pushdown_source_documents(
                [],
                dialect=MONGODB_DIALECT_70,
            )

        self.assertIn(
            "source cursor cleanup failed: close failure", context.exception.__notes__
        )

    async def test_source_materialization_enforces_existing_document_budget_early(self):
        collection = _FakeCollection([{"_id": 1}, {"_id": 2}, {"_id": 3}])
        collection._engine.aggregation_spill_policy = None
        collection._engine.aggregation_cost_policy = AggregationCostPolicy(
            max_materialized_documents=1
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$group": {"_id": None, "count": {"$sum": 1}}}],
        )

        with self.assertRaisesRegex(OperationFailure, "materialization budget"):
            await cursor._load_pushdown_source_documents(
                cursor._effective_pipeline(),
                dialect=MONGODB_DIALECT_70,
            )

        self.assertEqual(collection.last_find_cursor.to_list_lengths, [2])
        self.assertEqual(collection.last_find_cursor.close_calls, 1)

    async def test_incremental_group_with_empty_prefix_limit_skips_source(self):
        cursor = AsyncAggregationCursor(_FakeCollection([]), [], batch_size=2)

        result = await cursor._consume_incremental_group_pages(
            SimpleNamespace(prefix_skip=0, prefix_limit=0),
            accumulator=None,
            page_size=2,
            probe_maximum=None,
            cost_policy=None,
            spill_policy=None,
            dialect=MONGODB_DIALECT_70,
            deadline=None,
        )

        self.assertIsNone(result)

    async def test_stream_helpers_short_circuit_zero_limit_and_require_batch(self):
        cursor = AsyncAggregationCursor(_FakeCollection([]), [])

        self.assertEqual(
            [
                document
                async for document in cursor._stream_group_result(
                    [],
                    ([], 0, 0),
                    spill_policy=None,
                    dialect=MONGODB_DIALECT_70,
                    deadline=None,
                )
            ],
            [],
        )
        self.assertEqual(
            [
                document
                async for document in cursor._stream_sorted_group_result(
                    [],
                    SimpleNamespace(suffix_limit=0),
                    spill_policy=AggregationSpillPolicy(threshold=1),
                    dialect=MONGODB_DIALECT_70,
                    deadline=None,
                )
            ],
            [],
        )
        self.assertEqual(
            [document async for document in cursor._stream_windowed_pipeline(
                ([], 0, None), dialect=MONGODB_DIALECT_70, deadline=None
            )],
            [],
        )

    async def test_stream_group_result_preserves_skip_across_pages_and_limit(self):
        cursor = AsyncAggregationCursor(_FakeCollection([]), [], batch_size=2)

        result = [
            document
            async for document in cursor._stream_group_result(
                ({"_id": index} for index in range(5)),
                ([], 3, 1),
                spill_policy=None,
                dialect=MONGODB_DIALECT_70,
                deadline=None,
            )
        ]

        self.assertEqual(result, [{"_id": 3}])

    async def test_cursor_terminal_and_profiled_first_paths(self):
        collection = _FakeCollection([{"_id": 1}])
        collection._profile_operation = AsyncMock()
        cursor = AsyncAggregationCursor(collection, [])

        with self.assertRaisesRegex(ValueError, "non-negative"):
            await cursor.to_list(length=-1)
        self.assertEqual(await cursor.first(), {"_id": 1})
        collection._profile_operation.assert_awaited_once()
        await cursor.close()
        await cursor.close()
        self.assertEqual(await cursor.to_list(), [])

    async def test_deferred_stream_closes_delegate_opened_during_close(self):
        class Delegate:
            def __init__(self):
                self.close_calls = 0

            async def __anext__(self):
                return {"_id": 1}

            async def aclose(self):
                self.close_calls += 1

        cursor = AsyncAggregationCursor(_FakeCollection([]), [])
        delegate = Delegate()
        opening = asyncio.Event()
        release = asyncio.Event()

        async def open_stream():
            opening.set()
            await release.wait()
            return delegate

        with patch.object(cursor, "_open_batch_stream", side_effect=open_stream):
            stream = cursor._stream_batches()
            pull = asyncio.create_task(stream.__anext__())
            await opening.wait()
            await stream.aclose()
            release.set()
            with self.assertRaises(StopAsyncIteration):
                await pull
            await stream.aclose()

        self.assertEqual(delegate.close_calls, 1)

    async def test_deferred_stream_rejects_concurrent_open(self):
        cursor = AsyncAggregationCursor(_FakeCollection([]), [])
        stream = cursor._stream_batches()
        stream._opening = True

        with self.assertRaisesRegex(RuntimeError, "cannot be opened concurrently"):
            await stream.__anext__()

        stream._opening = False
        await stream.aclose()

    async def test_deferred_stream_closes_after_open_or_pull_failure(self):
        class FailingDelegate:
            def __init__(self):
                self.close_calls = 0

            async def __anext__(self):
                message = "pull failed"
                raise RuntimeError(message)

            async def aclose(self):
                self.close_calls += 1

        cursor = AsyncAggregationCursor(_FakeCollection([]), [])
        failing_delegate = FailingDelegate()

        with patch.object(
            cursor,
            "_open_batch_stream",
            return_value=failing_delegate,
        ):
            stream = cursor._stream_batches()
            with self.assertRaisesRegex(RuntimeError, "pull failed"):
                await stream.__anext__()
            with self.assertRaises(StopAsyncIteration):
                await stream.__anext__()

        self.assertEqual(failing_delegate.close_calls, 1)

        cursor = AsyncAggregationCursor(_FakeCollection([]), [])
        with patch.object(
            cursor,
            "_open_batch_stream",
            side_effect=RuntimeError("open failed"),
        ) as open_stream:
            stream = cursor._stream_batches()
            with self.assertRaisesRegex(RuntimeError, "open failed"):
                await stream.__anext__()
            with self.assertRaises(StopAsyncIteration):
                await stream.__anext__()

        open_stream.assert_awaited_once()

    async def test_split_streamable_pipeline_returns_none_after_trailing_window_and_accumulates_skip_limit(
        self,
    ):
        self.assertIsNone(
            AsyncAggregationCursor._split_streamable_pipeline(
                [{"$skip": 1}, {"$match": {"x": 1}}],
            )
        )
        self.assertEqual(
            AsyncAggregationCursor._split_streamable_pipeline(
                [
                    {"$match": {"x": 1}},
                    {"$skip": 2},
                    {"$limit": 5},
                    {"$limit": 3},
                ],
            ),
            ([{"$match": {"x": 1}}], 2, 3),
        )

    async def test_split_streamable_pipeline_preserves_window_stage_order(self):
        cases = [
            ([{"$limit": 5}, {"$skip": 3}], ([], 3, 2)),
            (
                [{"$skip": 3}, {"$limit": 5}, {"$skip": 3}],
                ([], 6, 2),
            ),
            ([{"$limit": 5}, {"$skip": 8}], ([], 5, 0)),
        ]

        for pipeline, expected in cases:
            with self.subTest(pipeline=pipeline):
                self.assertEqual(
                    AsyncAggregationCursor._split_streamable_pipeline(pipeline),
                    expected,
                )

    async def test_streaming_window_matches_materialized_execution(self):
        documents = [{"_id": str(index), "value": index} for index in range(10)]
        windows = [
            [{"$limit": 5}, {"$skip": 3}],
            [{"$skip": 3}, {"$limit": 5}, {"$skip": 3}],
            [{"$limit": 5}, {"$skip": 8}],
        ]

        for window in windows:
            with self.subTest(window=window):
                streaming = AsyncAggregationCursor(
                    _FakeCollection(documents),
                    [{"$addFields": {"seen": True}}, *window],
                    batch_size=2,
                )
                materialized = AsyncAggregationCursor(
                    _FakeCollection(documents),
                    [{"$addFields": {"seen": True}}, *window],
                )
                self.assertEqual(
                    await streaming.to_list(),
                    await materialized.to_list(),
                )

    async def test_materialize_pushes_safe_prefix_to_find(self):
        collection = _FakeCollection(
            [
                {"_id": "1", "kind": "view", "rank": 2},
                {"_id": "2", "kind": "view", "rank": 3},
            ]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [
                {"$match": {"kind": "view"}},
                {"$sort": {"rank": 1}},
                {"$skip": 1},
                {"$limit": 1},
                {"$project": {"rank": 1, "_id": 0}},
            ],
        )

        documents = await cursor.to_list()

        self.assertEqual(
            collection.calls,
            [
                {
                    "filter_spec": {"kind": "view"},
                    "projection": {"rank": 1, "_id": 0},
                    "sort": [("rank", 1)],
                    "skip": 1,
                    "limit": 1,
                    "hint": None,
                    "comment": None,
                    "max_time_ms": None,
                    "batch_size": 256,
                    "session": None,
                }
            ],
        )
        self.assertEqual(documents, [{"rank": 3}])
        self.assertEqual(len(collection.built_operations), 1)
        self.assertEqual(collection.built_operations[0][0].sort, [("rank", 1)])

    async def test_load_referenced_collections_uses_compiled_find_operations(
        self,
    ):
        collection = _FakeCollection([])
        cursor = AsyncAggregationCursor(
            collection,
            [
                {
                    "$lookup": {
                        "from": "roles",
                        "localField": "role_id",
                        "foreignField": "_id",
                        "as": "roles",
                    }
                },
                {"$unionWith": {"pipeline": []}},
            ],
            comment="agg-trace",
            max_time_ms=15,
        )

        loaded = await cursor._load_referenced_collections()

        self.assertEqual(loaded["roles"], [{"_id": "r1", "label": "admin"}])
        self.assertEqual(
            loaded[_CURRENT_COLLECTION_RESOLVER_KEY],
            [{"_id": "1", "name": "Ada"}],
        )
        self.assertEqual(len(collection._engine.scan_semantics_calls), 2)
        for (
            db_name,
            coll_name,
            semantics,
            kwargs,
        ) in collection._engine.scan_semantics_calls:
            self.assertEqual(db_name, "db")
            self.assertIn(coll_name, {"coll", "roles"})
            self.assertEqual(semantics.filter_spec, {})
            self.assertEqual(semantics.comment, "agg-trace")
            self.assertEqual(semantics.max_time_ms, 15)
            self.assertIsNone(semantics.projection)
            self.assertEqual(kwargs["context"], None)

    async def test_incremental_sort_keeps_remaining_pipeline_when_prefix_breaks(
        self,
    ):
        collection = _FakeCollection(
            [
                {"kind": "view"},
                {"kind": "click"},
            ]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [
                {"$project": {"kind": 1, "_id": 0}},
                {"$sort": {"kind": 1}},
            ],
        )

        documents = await cursor.to_list()

        self.assertEqual(
            collection.calls,
            [
                {
                    "filter_spec": {},
                    "projection": {"kind": 1, "_id": 0},
                    "sort": None,
                    "skip": 0,
                    "limit": None,
                    "hint": None,
                    "comment": None,
                    "max_time_ms": None,
                    "batch_size": 256,
                    "session": None,
                }
            ],
        )
        self.assertEqual(documents, [{"kind": "click"}, {"kind": "view"}])

    async def test_materialize_propagates_aggregate_cursor_options_to_find(
        self,
    ):
        collection = _FakeCollection([{"_id": "1", "kind": "view"}])
        cursor = AsyncAggregationCursor(
            collection,
            [{"$match": {"kind": "view"}}],
            hint="kind_1",
            comment="trace",
            max_time_ms=5,
            batch_size=10,
            allow_disk_use=True,
            let={"tenant": "a"},
        )

        await cursor.to_list()

        self.assertEqual(collection.calls[0]["hint"], "kind_1")
        self.assertEqual(collection.calls[0]["comment"], "trace")
        self.assertEqual(collection.calls[0]["max_time_ms"], 5)
        self.assertEqual(collection.calls[0]["batch_size"], 10)

    async def test_streaming_batch_execution_uses_one_stable_find_for_streamable_pipeline(
        self,
    ):
        collection = _FakeCollection(
            [
                {"_id": "1", "kind": "view", "rank": 1},
                {"_id": "2", "kind": "view", "rank": 2},
                {"_id": "3", "kind": "view", "rank": 3},
            ]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$match": {"kind": "view"}}],
            batch_size=2,
        )

        documents = await cursor.to_list()

        self.assertEqual(documents, collection._documents)
        self.assertEqual(
            [call["skip"] for call in collection.calls],
            [0],
        )
        self.assertEqual(
            [call["limit"] for call in collection.calls],
            [None],
        )

    async def test_streaming_batch_execution_handles_trailing_skip_and_limit_globally(
        self,
    ):
        collection = _FakeCollection(
            [
                {"_id": "1", "kind": "view", "rank": 1},
                {"_id": "2", "kind": "view", "rank": 2},
                {"_id": "3", "kind": "view", "rank": 3},
                {"_id": "4", "kind": "view", "rank": 4},
            ]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$match": {"kind": "view"}}, {"$skip": 1}, {"$limit": 2}],
            batch_size=2,
        )

        documents = await cursor.to_list()

        self.assertEqual(
            documents,
            [
                {"_id": "2", "kind": "view", "rank": 2},
                {"_id": "3", "kind": "view", "rank": 3},
            ],
        )

    async def test_streaming_batch_execution_skips_full_first_page_and_honors_zero_remaining_limit(
        self,
    ):
        collection = _FakeCollection(
            [
                {"_id": "1", "kind": "view", "rank": 1},
                {"_id": "2", "kind": "view", "rank": 2},
                {"_id": "3", "kind": "view", "rank": 3},
            ]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$match": {"kind": "view"}}, {"$skip": 2}, {"$limit": 1}],
            batch_size=2,
        )

        self.assertEqual(
            await cursor.to_list(), [{"_id": "3", "kind": "view", "rank": 3}]
        )

    async def test_streaming_batch_execution_falls_back_for_global_pipeline_stages(
        self,
    ):
        collection = _FakeCollection(
            [
                {"_id": "1", "kind": "view", "rank": 2},
                {"_id": "2", "kind": "view", "rank": 1},
                {"_id": "3", "kind": "view", "rank": 3},
            ]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$group": {"_id": "$kind", "count": {"$sum": 1}}}],
            batch_size=2,
        )

        documents = await cursor.to_list()

        self.assertEqual(documents, [{"_id": "view", "count": 3}])
        self.assertEqual(len(collection.calls), 1)
        explanation = await cursor.explain()
        self.assertFalse(explanation["streaming_batch_execution"])
        self.assertEqual(explanation["pushdown"]["mode"], "pipeline-prefix")
        self.assertEqual(explanation["pushdown"]["pushedDownStages"], 0)
        self.assertEqual(explanation["pushdown"]["remainingStages"], 1)

    async def test_async_aggregation_cursor_explain_includes_engine_plan_and_options(
        self,
    ):
        collection = _FakeCollection([{"_id": "1", "kind": "view"}])
        cursor = AsyncAggregationCursor(
            collection,
            [{"$match": {"kind": "view"}}],
            hint="kind_1",
            comment="trace",
            max_time_ms=5_000,
            batch_size=10,
            allow_disk_use=True,
            let={"tenant": "a"},
        )

        explanation = await cursor.explain()

        self.assertEqual(
            explanation["engine_plan"],
            {"engine": "fake", "details": ["IXSCAN"]},
        )
        self.assertEqual(explanation["pushdown"]["mode"], "pipeline-prefix")
        self.assertEqual(explanation["pushdown"]["totalStages"], 1)
        self.assertEqual(explanation["pushdown"]["pushedDownStages"], 1)
        self.assertEqual(explanation["pushdown"]["remainingStages"], 0)
        self.assertEqual(explanation["pushdown"]["streamableStageCount"], 0)
        self.assertEqual(explanation["hint"], "kind_1")
        self.assertEqual(explanation["comment"], "trace")
        self.assertEqual(explanation["max_time_ms"], 5_000)
        self.assertEqual(explanation["batch_size"], 10)
        self.assertTrue(explanation["allow_disk_use"])
        self.assertEqual(explanation["let"], {"tenant": "a"})
        self.assertTrue(explanation["streaming_batch_execution"])
        self.assertEqual(explanation["cxp"]["interface"], "database/mongodb")
        self.assertEqual(explanation["cxp"]["provider"], "mongoeco")
        self.assertEqual(explanation["cxp"]["capability"], "aggregation")
        explain_semantics = collection._engine.explain_semantics_calls[0][2]
        self.assertEqual(explain_semantics.hint, "kind_1")
        self.assertEqual(explain_semantics.comment, "trace")
        self.assertEqual(explain_semantics.max_time_ms, 5_000)

    async def test_explain_surfaces_bounded_lookup_candidate_and_runtime_fallback(
        self,
    ):
        collection = _FakeCollection([{"_id": "1", "role": "admin"}])
        collection._engine.aggregation_cost_policy = AggregationCostPolicy(
            max_materialized_documents=100,
        )
        collection._engine.aggregation_spill_policy = AggregationSpillPolicy(
            threshold=40,
        )
        pipeline = [
            {
                "$lookup": {
                    "from": "roles",
                    "localField": "role",
                    "foreignField": "name",
                    "as": "resolved",
                },
            },
        ]

        explanation = await AsyncAggregationCursor(collection, pipeline).explain()

        self.assertEqual(
            explanation["pushdown"]["lookupPlans"],
            [
                {
                    "stagePath": [0],
                    "strategy": "bounded-hash-candidate",
                    "reason": "eligible-with-runtime-fallback",
                    "maxAssociations": 40,
                },
            ],
        )

        collated = AsyncAggregationCursor(
            collection,
            compile_aggregate_operation(
                pipeline,
                collation={"locale": "en", "strength": 2},
            ),
        )
        collated_explanation = await collated.explain()
        self.assertEqual(
            collated_explanation["pushdown"]["lookupPlans"][0],
            {
                "stagePath": [0],
                "strategy": "nested-loop",
                "reason": "collation",
            },
        )

    async def test_async_aggregation_cursor_explain_covers_search_fallback_and_first_empty_profile(
        self,
    ):
        collection = _FakeCollection([])
        collection._engine.aggregation_spill_policy = lambda: AggregationSpillPolicy(
            threshold=2
        )
        profiled = []

        async def _execute_search(_db_name, _coll_name, request):
            return SearchExecutionOutcome.from_documents(
                [],
                backend="fake",
                operation_id=request.operation_context.operation_id,
            )

        _enable_search(collection._engine, _execute_search)

        async def _profile_operation(**kwargs):
            profiled.append(kwargs)

        collection._profile_operation = _profile_operation  # type: ignore[attr-defined]
        cursor = AsyncAggregationCursor(
            collection,
            [{"$search": {"text": {"query": "Ada", "path": "name"}}}],
            batch_size=1,
        )

        explanation = await cursor.explain()
        self.assertEqual(
            explanation["engine_plan"]["plan"], "unsupported-search-engine"
        )
        self.assertEqual(explanation["pushdown"]["mode"], "search")
        self.assertEqual(explanation["pushdown"]["leadingSearchOperator"], "$search")
        self.assertEqual(explanation["pushdown"]["pushedDownStages"], 1)
        self.assertEqual(explanation["cxp"]["capability"], "aggregation")
        self.assertEqual(explanation["cxp"]["additionalCapabilities"], ["search"])
        self.assertEqual(cursor._spill_policy().threshold, 2)
        self.assertIsNone(await cursor.first())
        self.assertEqual(profiled[-1]["op"], "command")

    async def test_aggregation_cursor_profile_and_collstats_cover_no_scale_and_exception_paths(
        self,
    ):
        collection = _FakeCollection([{"_id": "1"}])
        profiled = []

        async def _profile_operation(**kwargs):
            profiled.append(kwargs)

        collection._profile_operation = _profile_operation  # type: ignore[attr-defined]
        cursor = AsyncAggregationCursor(collection, [{"$project": {"_id": 1}}])
        with patch.object(cursor, "_stream_batches", side_effect=RuntimeError("boom")):
            with self.assertRaisesRegex(RuntimeError, "boom"):
                await cursor.to_list()
        self.assertEqual(profiled[-1]["errmsg"], "boom")

        self.assertEqual(
            await cursor._load_collstats_snapshots([{"$match": {"x": 1}}]), {}
        )

    async def test_build_pushdown_cursor_uses_collection_find_when_private_builder_is_missing(
        self,
    ):
        collection = _FakeCollection([{"_id": "1"}])
        collection._build_cursor = None  # type: ignore[assignment]
        cursor = AsyncAggregationCursor(collection, [{"$match": {"_id": "1"}}])

        await cursor._build_pushdown_cursor(cursor._pushdown_find_operation()).to_list()

        self.assertEqual(collection.calls[0]["filter_spec"], {"_id": "1"})

    async def test_async_aggregation_cursor_explain_surfaces_deferred_reason_details(
        self,
    ):
        collection = _FakeCollection([{"_id": "1", "kind": "view"}])
        cursor = AsyncAggregationCursor(collection, [{"$match": {"kind": "view"}}])
        cursor._operation = cursor._operation.with_overrides(
            planning_mode=PlanningMode.RELAXED,
            planning_issues=(
                PlanningIssue(scope="aggregate", message="unsupported stage"),
            ),
        )

        explanation = await cursor.explain()

        self.assertEqual(explanation["planning_mode"], "relaxed")
        self.assertEqual(explanation["planning_issues"][0]["scope"], "aggregate")
        self.assertEqual(
            explanation["engine_plan"]["details"]["reason"],
            "operation has deferred planning issues (relaxed): aggregate: unsupported stage",
        )
        self.assertEqual(explanation["cxp"]["capability"], "aggregation")

    async def test_stream_batches_use_compiled_pushdown_operations(self):
        collection = _FakeCollection(
            [
                {"_id": "1", "kind": "view", "rank": 1},
                {"_id": "2", "kind": "view", "rank": 2},
                {"_id": "3", "kind": "view", "rank": 3},
            ]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$match": {"kind": "view"}}],
            batch_size=2,
        )

        documents = await cursor.to_list()

        self.assertEqual(len(documents), 3)
        self.assertEqual(len(collection.built_operations), 1)
        self.assertIsNone(collection.built_operations[0][0].limit)
        self.assertEqual(collection.built_operations[0][0].skip, 0)

    async def test_materialize_enforces_max_time_deadline(self):
        collection = _FakeCollection([{"_id": "1", "kind": "view"}])
        cursor = AsyncAggregationCursor(
            collection,
            [{"$match": {"kind": "view"}}],
            max_time_ms=1,
        )

        with patch(
            "mongoeco.api._async.aggregation_cursor.enforce_deadline",
            side_effect=ExecutionTimeout("operation exceeded time limit"),
        ):
            with self.assertRaises(ExecutionTimeout):
                await cursor.to_list()

    async def test_materialize_rejects_large_blocking_pipeline_without_spill_budget(
        self,
    ):
        collection = _FakeCollection(
            [{"_id": "1", "kind": "a"}, {"_id": "2", "kind": "a"}]
        )
        collection._engine.aggregation_cost_policy = AggregationCostPolicy(
            max_materialized_documents=1
        )
        cursor = AsyncAggregationCursor(
            collection,
            compile_aggregate_operation(
                [{"$group": {"_id": "$kind", "count": {"$sum": 1}}}],
                allow_disk_use=False,
            ),
        )

        referenced_loader = AsyncMock(return_value={})
        with (
            patch.object(
                cursor,
                "_load_referenced_collections",
                referenced_loader,
            ),
            self.assertRaises(OperationFailure),
        ):
            await cursor.to_list()

        self.assertEqual(collection.last_find_cursor.pull_chunk_sizes, [2])
        self.assertEqual(collection.last_find_cursor.to_list_lengths, [])
        self.assertEqual(collection.last_find_cursor.close_calls, 1)

        explanation = await AsyncAggregationCursor(
            collection,
            [{"$group": {"_id": "$kind", "count": {"$sum": 1}}}],
        ).explain()
        self.assertTrue(explanation["pushdown"]["incrementalGroupInput"])
        self.assertTrue(explanation["pushdown"]["sourceBatchExecution"])
        self.assertFalse(explanation["pushdown"]["streamingEligible"])
        self.assertFalse(explanation["pushdown"]["streamingSortOutput"])
        referenced_loader.assert_not_awaited()

    async def test_materialize_allows_large_blocking_pipeline_when_spill_is_available(
        self,
    ):
        collection = _FakeCollection(
            [{"_id": "1", "kind": "a"}, {"_id": "2", "kind": "a"}]
        )
        collection._engine.aggregation_cost_policy = AggregationCostPolicy(
            max_materialized_documents=1
        )
        cursor = AsyncAggregationCursor(
            collection,
            compile_aggregate_operation(
                [{"$group": {"_id": "$kind", "count": {"$sum": 1}}}],
                allow_disk_use=True,
            ),
        )

        self.assertEqual(await cursor.to_list(), [{"_id": "a", "count": 2}])

    async def test_group_consumes_finite_source_pages_without_materializing_input(
        self,
    ):
        collection = _FakeCollection(
            [{"_id": index, "kind": index % 2} for index in range(5)]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [
                {"$group": {"_id": "$kind", "count": {"$sum": 1}}},
                {"$sort": {"_id": 1}},
            ],
            batch_size=2,
        )

        self.assertEqual(
            await cursor.to_list(),
            [{"_id": 0, "count": 3}, {"_id": 1, "count": 2}],
        )
        self.assertEqual(collection.last_find_cursor.to_list_lengths, [])
        self.assertEqual(
            collection.last_find_cursor.pull_chunk_sizes,
            [2, 2, 2, 2],
        )
        self.assertEqual(collection.last_find_cursor.close_calls, 1)

        explanation = await AsyncAggregationCursor(
            collection,
            [
                {"$group": {"_id": "$kind", "count": {"$sum": 1}}},
                {"$sort": {"_id": 1}},
            ],
        ).explain()
        self.assertTrue(explanation["pushdown"]["streamingSortOutput"])

    async def test_unbatched_group_uses_bounded_internal_source_pages(self):
        collection = _FakeCollection(
            [{"_id": index, "kind": "same"} for index in range(300)]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$group": {"_id": "$kind", "count": {"$sum": 1}}}],
        )

        self.assertEqual(
            await cursor.to_list(),
            [{"_id": "same", "count": 300}],
        )
        self.assertEqual(collection.last_find_cursor.to_list_lengths, [])
        self.assertEqual(
            collection.last_find_cursor.pull_chunk_sizes,
            [256, 256, 256],
        )

    async def test_partial_group_sort_closes_streamed_spill_output(self):
        group_count = 70
        collection = _FakeCollection(
            [{"_id": index, "kind": index} for index in range(group_count)]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [
                {"$group": {"_id": "$kind", "count": {"$sum": 1}}},
                {"$sort": {"_id": -1}},
            ],
            batch_size=2,
            allow_disk_use=True,
        )
        before = _aggregation_sort_temp_paths()

        self.assertEqual((await anext(cursor))["_id"], group_count - 1)
        self.assertGreater(len(_aggregation_sort_temp_paths()), len(before))
        await cursor.close()

        self.assertEqual(_aggregation_sort_temp_paths(), before)

    async def test_partitioned_group_preserves_accumulators_and_first_seen_order(self):
        group_count = 17
        documents = [
            {"_id": index, "kind": index % group_count, "value": index}
            for index in range(group_count * 3)
        ]
        collection = _FakeCollection(documents)
        cursor = AsyncAggregationCursor(
            collection,
            [
                {
                    "$group": {
                        "_id": "$kind",
                        "count": {"$sum": 1},
                        "first": {"$first": "$value"},
                        "last": {"$last": "$value"},
                        "values": {"$push": "$value"},
                    }
                }
            ],
            batch_size=3,
            allow_disk_use=True,
        )

        result = await cursor.to_list()

        self.assertEqual([document["_id"] for document in result], list(range(17)))
        for group_id, document in enumerate(result):
            expected_values = [group_id, group_id + 17, group_id + 34]
            self.assertEqual(document["count"], 3)
            self.assertEqual(document["first"], expected_values[0])
            self.assertEqual(document["last"], expected_values[-1])
            self.assertEqual(document["values"], expected_values)
        explanation = await cursor.explain()
        self.assertTrue(explanation["pushdown"]["partitionedGroupStateCandidate"])
        self.assertTrue(explanation["pushdown"]["streamingGroupOutputCandidate"])

    async def test_low_cardinality_group_does_not_open_partition_spool(self):
        collection = _FakeCollection(
            [{"_id": index, "kind": "same"} for index in range(100)]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$group": {"_id": "$kind", "count": {"$sum": 1}}}],
            batch_size=3,
            allow_disk_use=True,
        )

        with patch(
            "mongoeco.core.aggregation.spill.AggregationSpillPolicy.open_group_spool",
            side_effect=AssertionError("low-cardinality group must stay in memory"),
        ):
            result = await cursor.to_list()

        self.assertEqual(result, [{"_id": "same", "count": 100}])

    async def test_unserializable_group_state_falls_back_without_new_error(self):
        collection = _FakeCollection(
            [{"_id": index, "kind": index} for index in range(3)]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$group": {"_id": "$kind", "count": {"$sum": 1}}}],
            allow_disk_use=True,
        )

        with patch(
            "mongoeco.core.aggregation.spill.AggregationGroupSpool.seed",
            side_effect=_AggregationGroupStateSerializationError("unsupported"),
        ):
            result = await cursor.to_list()

        self.assertEqual(
            result,
            [
                {"_id": 0, "count": 1},
                {"_id": 1, "count": 1},
                {"_id": 2, "count": 1},
            ],
        )

    async def test_partial_partitioned_group_output_cleans_owned_temporaries(self):
        collection = _FakeCollection(
            [{"_id": index, "kind": index} for index in range(70)]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$group": {"_id": "$kind", "count": {"$sum": 1}}}],
            batch_size=2,
            allow_disk_use=True,
        )
        before_groups = _aggregation_group_temp_paths()
        before_sorts = _aggregation_sort_temp_paths()

        self.assertEqual((await anext(cursor))["_id"], 0)
        self.assertTrue(
            len(_aggregation_group_temp_paths()) > len(before_groups)
            or len(_aggregation_sort_temp_paths()) > len(before_sorts)
        )
        await cursor.close()

        self.assertEqual(_aggregation_group_temp_paths(), before_groups)
        self.assertEqual(_aggregation_sort_temp_paths(), before_sorts)

    async def test_sort_consumes_finite_source_pages_and_preserves_global_windows(
        self,
    ):
        collection = _FakeCollection(
            [
                {"_id": "a", "values": [5, 1]},
                {"_id": "b", "values": [4, 2]},
                {"_id": "c", "values": [3, 0]},
            ]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [
                {"$unwind": "$values"},
                {"$skip": 1},
                {"$limit": 4},
                {"$sort": {"values": 1}},
                {"$project": {"_id": 0, "values": 1}},
                {"$skip": 1},
                {"$limit": 2},
            ],
            batch_size=2,
            allow_disk_use=True,
        )
        before = _aggregation_sort_temp_paths()

        self.assertEqual(await cursor.to_list(), [{"values": 2}, {"values": 3}])
        self.assertEqual(collection.last_find_cursor.to_list_lengths, [])
        self.assertEqual(collection.last_find_cursor.pull_chunk_sizes, [2, 2])
        self.assertEqual(collection.last_find_cursor.close_calls, 1)
        self.assertEqual(_aggregation_sort_temp_paths(), before)

        explanation = await AsyncAggregationCursor(
            collection,
            [{"$unwind": "$values"}, {"$sort": {"values": 1}}],
            allow_disk_use=True,
        ).explain()
        self.assertTrue(explanation["pushdown"]["incrementalSortInput"])
        self.assertTrue(explanation["pushdown"]["streamingSortOutput"])
        self.assertTrue(explanation["pushdown"]["sourceBatchExecution"])
        self.assertFalse(explanation["pushdown"]["streamingEligible"])

    async def test_partial_incremental_sort_closes_source_and_spill_output(self):
        collection = _FakeCollection(
            [{"_id": index, "values": [index]} for index in range(6)]
        )
        cursor = AsyncAggregationCursor(
            collection,
            [{"$unwind": "$values"}, {"$sort": {"values": -1}}],
            batch_size=2,
            allow_disk_use=True,
        )
        before = _aggregation_sort_temp_paths()

        self.assertEqual((await anext(cursor))["values"], 5)
        self.assertEqual(collection.last_find_cursor.to_list_lengths, [])
        self.assertEqual(collection.last_find_cursor.close_calls, 1)
        self.assertGreater(len(_aggregation_sort_temp_paths()), len(before))

        await cursor.close()

        self.assertEqual(_aggregation_sort_temp_paths(), before)

    def test_incremental_sort_split_preserves_prefix_and_suffix_windows(self):
        plan = AsyncAggregationCursor._split_incremental_sort_pipeline(
            [
                {"$unwind": "$values"},
                {"$skip": 3},
                {"$limit": 4},
                {"$sort": {"values": 1}},
                {"$project": {"values": 1}},
                {"$skip": 2},
                {"$limit": 1},
            ]
        )

        self.assertIsNotNone(plan)
        self.assertEqual(plan.prefix, [{"$unwind": "$values"}])
        self.assertEqual(plan.prefix_skip, 3)
        self.assertEqual(plan.prefix_limit, 4)
        self.assertEqual(plan.sort_spec, {"values": 1})
        self.assertEqual(plan.suffix, [{"$project": {"values": 1}}])
        self.assertEqual(plan.suffix_skip, 2)
        self.assertEqual(plan.suffix_limit, 1)

    def test_incremental_group_split_preserves_global_prefix_window(self):
        plan = AsyncAggregationCursor._split_incremental_group_pipeline(
            [
                {"$project": {"kind": 1}},
                {"$skip": 3},
                {"$limit": 4},
                {"$group": {"_id": "$kind", "count": {"$sum": 1}}},
                {"$sort": {"_id": 1}},
            ]
        )

        self.assertIsNotNone(plan)
        self.assertEqual(plan.prefix, [{"$project": {"kind": 1}}])
        self.assertEqual(plan.prefix_skip, 3)
        self.assertEqual(plan.prefix_limit, 4)
        self.assertEqual(plan.group_spec["_id"], "$kind")
        self.assertEqual(plan.suffix, [{"$sort": {"_id": 1}}])

    async def test_aggregation_cursor_merge_helpers_cover_validation_and_target_paths(
        self,
    ):
        database = AsyncDatabase(MemoryEngine(), "db")
        source = database.get_collection("source")
        cursor = AsyncAggregationCursor(source, [])

        self.assertEqual(cursor._target_database("db").name, "db")
        self.assertEqual(cursor._target_database("analytics").name, "analytics")
        self.assertEqual(cursor._split_terminal_writeback_stage([]), ([], None))
        self.assertEqual(
            cursor._split_terminal_writeback_stage([{"$match": {"x": 1}}]),
            ([{"$match": {"x": 1}}], None),
        )
        with self.assertRaisesRegex(
            OperationFailure, "only supported as the final aggregation stage"
        ):
            cursor._split_terminal_writeback_stage(
                [
                    {"$merge": {"into": "archive"}},
                    {"$merge": {"into": "archive"}},
                ]
            )

        with self.assertRaisesRegex(OperationFailure, "document specification"):
            await cursor._apply_merge_stage([], [])
        with self.assertRaisesRegex(
            OperationFailure, "collection name or \\{db, coll\\}"
        ):
            await cursor._apply_merge_stage([], {"into": 1})
        with self.assertRaisesRegex(OperationFailure, "non-empty string"):
            await cursor._apply_merge_stage([], {"into": {"db": "", "coll": "archive"}})
        with self.assertRaisesRegex(OperationFailure, "omitted on or on: '_id'"):
            await cursor._apply_merge_stage([], {"into": "archive", "on": "slug"})
        with self.assertRaisesRegex(OperationFailure, "whenMatched currently supports"):
            await cursor._apply_merge_stage(
                [], {"into": "archive", "whenMatched": "pipeline"}
            )
        with self.assertRaisesRegex(
            OperationFailure, "whenNotMatched currently supports"
        ):
            await cursor._apply_merge_stage(
                [], {"into": "archive", "whenNotMatched": "upsert"}
            )
        with self.assertRaisesRegex(OperationFailure, "pipelines are not supported"):
            await cursor._apply_merge_stage([], {"into": "archive", "whenMatched": []})
        await cursor._apply_merge_stage([{"value": 1}], {"into": "archive"})
        generated = await database.get_collection("archive").find_one({"value": 1})
        self.assertIsNotNone(generated)
        self.assertIn("_id", generated)

        await cursor._apply_merge_stage(
            [{"_id": "1", "value": 1}],
            {"into": "archive", "whenNotMatched": "discard"},
        )
        self.assertIsNone(
            await database.get_collection("archive").find_one({"_id": "1"})
        )
        with self.assertRaises(OperationFailure) as array_id_context:
            await cursor._apply_merge_stage(
                [{"_id": [1], "value": 1}],
                {"into": "archive", "whenNotMatched": "discard"},
            )
        self.assertEqual(array_id_context.exception.code, 51185)
        with self.assertRaisesRegex(OperationFailure, "whenNotMatched=fail"):
            await cursor._apply_merge_stage(
                [{"_id": "1", "value": 1}],
                {"into": "archive", "whenNotMatched": "fail"},
            )

        await database.get_collection("archive").insert_one(
            {"_id": "2", "value": 10, "extra": True}
        )
        await cursor._apply_merge_stage(
            [{"_id": "2", "value": 20}],
            {"into": "archive", "whenMatched": "keepExisting"},
        )
        self.assertEqual(
            (await database.get_collection("archive").find_one({"_id": "2"}))["value"],
            10,
        )
        with self.assertRaisesRegex(OperationFailure, "whenMatched=fail"):
            await cursor._apply_merge_stage(
                [{"_id": "2", "value": 20}],
                {"into": "archive", "whenMatched": "fail"},
            )
        await cursor._apply_merge_stage(
            [{"_id": "2", "value": 30}],
            {"into": "archive", "whenMatched": "replace"},
        )
        self.assertEqual(
            (await database.get_collection("archive").find_one({"_id": "2"}))["value"],
            30,
        )
        await cursor._apply_merge_stage(
            [{"_id": "2", "value": 40, "merged": True}],
            {"into": "archive", "whenMatched": "merge"},
        )
        merged = await database.get_collection("archive").find_one({"_id": "2"})
        self.assertEqual(merged["value"], 40)
        self.assertTrue(merged["merged"])

    async def test_merge_rejects_mismatched_target_storage_key_even_for_keep_existing(
        self,
    ):
        async def _exercise(engine_type):
            engine = engine_type()
            await engine.connect()
            try:
                database = AsyncDatabase(engine, "db")
                source = database.get_collection("source")
                target = database.get_collection("target")
                await source.insert_one({"_id": "new", "value": "incoming"})
                await target.insert_one({"_id": "old", "value": "target"})
                if isinstance(engine, MemoryEngine):
                    engine._storage["db"]["target"][engine._storage_key("old")] = (
                        engine._encode_storage_document(
                            {"_id": "new", "value": "corrupt-target"}
                        )
                    )
                else:
                    with engine._lock:
                        conn = engine._require_connection(None)
                        conn.execute(
                            (
                                "UPDATE documents SET document = ? "
                                "WHERE db_name = ? AND coll_name = ? AND storage_key = ?"
                            ),
                            (
                                engine._serialize_document(
                                    {"_id": "new", "value": "corrupt-target"}
                                ),
                                "db",
                                "target",
                                engine._storage_key("old"),
                            ),
                        )
                        conn.commit()

                cursor = AsyncAggregationCursor(source, [])
                with self.assertRaises(OperationFailure) as context:
                    await cursor._apply_merge_stage(
                        [{"_id": "new", "value": "incoming"}],
                        {"into": "target", "whenMatched": "keepExisting"},
                    )
                return context.exception, await target.find({}).to_list()
            finally:
                await engine.disconnect()

        for engine_type in (MemoryEngine, SQLiteEngine):
            with self.subTest(engine=engine_type.__name__):
                error, target_documents = await _exercise(engine_type)
                self.assertEqual(error.code, 66)
                self.assertEqual(
                    target_documents,
                    [{"_id": "new", "value": "corrupt-target"}],
                )

    async def test_aggregation_cursor_collstats_and_stream_batches_cover_fallback_branches(
        self,
    ):
        collection = _FakeCollection([{"_id": "1"}, {"_id": "2"}])
        cursor = AsyncAggregationCursor(
            collection, [{"$project": {"_id": 1}}], batch_size=2
        )

        self.assertEqual(
            cursor._collect_collstats_scales(
                [{"$collStats": {"storageStats": {"scale": 4}}}]
            ),
            {4},
        )
        self.assertEqual(
            cursor._collect_collstats_scales(
                [{"$collStats": {"count": {}}}, {"$collStats": []}]
            ),
            {1},
        )
        self.assertTrue(cursor._collect_index_stats_requested([{"$indexStats": {}}]))
        self.assertFalse(
            cursor._collect_index_stats_requested([{"$project": {"_id": 1}}])
        )
        self.assertTrue(cursor._collect_current_op_requested([{"$currentOp": {}}]))
        self.assertFalse(
            cursor._collect_current_op_requested([{"$project": {"_id": 1}}])
        )
        self.assertTrue(
            cursor._collect_plan_cache_stats_requested([{"$planCacheStats": {}}])
        )
        self.assertFalse(
            cursor._collect_plan_cache_stats_requested([{"$project": {"_id": 1}}])
        )
        self.assertTrue(
            cursor._collect_list_sessions_requested([{"$listSessions": {}}])
        )
        self.assertFalse(
            cursor._collect_list_sessions_requested([{"$project": {"_id": 1}}])
        )

        search_cursor = AsyncAggregationCursor(
            collection,
            [{"$search": {"text": {"query": "Ada", "path": "name"}}}],
            batch_size=2,
        )
        with patch.object(
            search_cursor, "_materialize", return_value=[{"_id": "a"}]
        ) as materialize:
            self.assertEqual(
                [document async for document in search_cursor._stream_batches()],
                [{"_id": "a"}],
            )
            materialize.assert_awaited_once()

        merge_cursor = AsyncAggregationCursor(
            collection,
            [{"$match": {"x": 1}}, {"$merge": {"into": "archive"}}],
            batch_size=2,
        )
        with patch.object(
            merge_cursor, "_materialize", return_value=[{"_id": "m"}]
        ) as materialize:
            self.assertEqual(
                [document async for document in merge_cursor._stream_batches()],
                [{"_id": "m"}],
            )
            materialize.assert_awaited_once()

        unbatched_cursor = AsyncAggregationCursor(
            collection, [{"$project": {"_id": 1}}], batch_size=None
        )
        with patch.object(
            unbatched_cursor, "_materialize", return_value=[{"_id": "u"}]
        ) as materialize:
            self.assertEqual(
                [document async for document in unbatched_cursor._stream_batches()],
                [{"_id": "1"}, {"_id": "2"}],
            )
            materialize.assert_not_awaited()

        with (
            patch.object(cursor, "_split_streamable_pipeline", return_value=None),
            patch.object(
                cursor, "_materialize", return_value=[{"_id": "p"}]
            ) as materialize,
        ):
            self.assertEqual(
                [document async for document in cursor._stream_batches()],
                [{"_id": "p"}],
            )
            materialize.assert_awaited_once()

        stream_cursor = AsyncAggregationCursor(
            collection,
            [{"$project": {"_id": 1}}, {"$skip": 1}, {"$limit": 1}],
            batch_size=2,
        )
        with (
            patch(
                "mongoeco.api._async.aggregation_cursor.split_pushdown_pipeline",
                return_value=SimpleNamespace(
                    filter_spec={},
                    projection=None,
                    sort=None,
                    remaining_pipeline=[
                        {"$project": {"_id": 1}},
                        {"$skip": 1},
                        {"$limit": 1},
                    ],
                    skip=0,
                    limit=3,
                ),
            ),
            patch.object(
                stream_cursor,
                "_split_streamable_pipeline",
                return_value=([{"$project": {"_id": 1}}], 1, 1),
            ),
            patch.object(
                stream_cursor, "_load_referenced_collections", return_value={}
            ),
            patch.object(stream_cursor, "_spill_policy", return_value=None),
        ):
            batches = [
                [{"_id": "1"}, {"_id": "2"}],
                [{"_id": "3"}],
                [],
            ]

            class _BatchCursor:
                def __init__(self, docs):
                    self._docs = docs

                async def to_list(self):
                    return self._docs

            stream_cursor._build_pushdown_cursor = lambda _operation: _BatchCursor(
                batches.pop(0)
            )  # type: ignore[method-assign]
            self.assertEqual(
                [document async for document in stream_cursor._stream_batches()],
                [{"_id": "2"}],
            )

    async def test_aggregation_cursor_supports_index_stats_stage_with_local_snapshot_projection(
        self,
    ):
        database = AsyncDatabase(MemoryEngine(), "db")
        collection = database.get_collection("events")
        await collection.insert_one({"_id": "1", "name": "Ada"})
        await collection.create_index([("name", 1)])

        cursor = AsyncAggregationCursor(collection, [{"$indexStats": {}}])
        result = await cursor.to_list()

        self.assertGreaterEqual(len(result), 1)
        for entry in result:
            self.assertIn("name", entry)
            self.assertIn("key", entry)
            self.assertIn("spec", entry)
            self.assertIn("accesses", entry)
            self.assertEqual(entry["accesses"]["ops"], 0)
            self.assertIsInstance(entry["accesses"]["since"], datetime.datetime)

    async def test_aggregation_cursor_supports_current_op_stage_with_engine_snapshot(
        self,
    ):
        collection = _FakeCollection([])
        collection._engine._snapshot_active_operations = lambda: [  # type: ignore[attr-defined]
            {"opid": "op-1", "command": "find", "ns": "db.coll"},
            {"opid": "op-2", "command": "currentOp", "ns": "admin.$cmd"},
        ]

        cursor = AsyncAggregationCursor(collection, [{"$currentOp": {}}], batch_size=2)
        result = await cursor.to_list()

        self.assertEqual(result, [{"opid": "op-1", "command": "find", "ns": "db.coll"}])

    async def test_aggregation_cursor_supports_plan_cache_stats_stage_with_runtime_diagnostics(
        self,
    ):
        collection = _FakeCollection([])
        collection._engine._runtime_diagnostics_info = lambda: {  # type: ignore[attr-defined]
            "planner": {"engine": "python"},
            "caches": {"trackedCollections": 1},
        }

        cursor = AsyncAggregationCursor(
            collection, [{"$planCacheStats": {}}], batch_size=2
        )
        result = await cursor.to_list()

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["ns"], "db.coll")
        self.assertEqual(result[0]["createdFromQuery"]["stage"], "$planCacheStats")
        self.assertEqual(result[0]["cachedPlan"]["planner"]["engine"], "python")

    async def test_aggregation_cursor_plan_cache_stats_ignores_non_dict_runtime_diagnostics(
        self,
    ):
        collection = _FakeCollection([])
        collection._engine._runtime_diagnostics_info = lambda: ["unexpected"]  # type: ignore[attr-defined]

        cursor = AsyncAggregationCursor(
            collection, [{"$planCacheStats": {}}], batch_size=2
        )
        result = await cursor.to_list()

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["cachedPlan"], {})

    async def test_aggregation_cursor_supports_list_sessions_stage_with_explicit_session(
        self,
    ):
        collection = _FakeCollection([])
        session = ClientSession()

        cursor = AsyncAggregationCursor(
            collection,
            [{"$listSessions": {}}],
            batch_size=2,
            session=session,
        )
        result = await cursor.to_list()

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["_id"]["id"], session.session_id)
        self.assertFalse(result[0]["inTransaction"])
        self.assertFalse(result[0].get("fromCurrentOp", False))

    async def test_aggregation_cursor_list_sessions_stage_uses_current_op_session_ids(
        self,
    ):
        collection = _FakeCollection([])
        collection._engine._snapshot_active_operations = lambda: [  # type: ignore[attr-defined]
            1,
            {"opid": "op-1", "command": "find", "sessionId": "sess-1"},
            {"opid": "op-2", "command": "find"},
        ]

        cursor = AsyncAggregationCursor(
            collection, [{"$listSessions": {}}], batch_size=2
        )
        result = await cursor.to_list()

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["_id"]["id"], "sess-1")
        self.assertTrue(result[0]["fromCurrentOp"])

    async def test_aggregation_cursor_additional_stream_and_merge_branches(
        self,
    ):
        database = AsyncDatabase(MemoryEngine(), "db")
        source = database.get_collection("source")
        await source.insert_many([{"_id": "1"}, {"_id": "2"}])
        cursor = AsyncAggregationCursor(source, [], batch_size=2)

        self.assertEqual(
            cursor._split_terminal_writeback_stage(["bad-stage"]),
            (["bad-stage"], None),
        )  # type: ignore[list-item]
        with self.assertRaisesRegex(OperationFailure, "final aggregation stage"):
            cursor._split_terminal_writeback_stage(
                [
                    {"$merge": {"into": "archive"}},
                    {"$project": {"_id": 1}},
                    {"$merge": {"into": "archive"}},
                ]
            )
        with self.assertRaisesRegex(OperationFailure, "non-empty string"):
            await cursor._apply_merge_stage(
                [{"_id": "1"}], {"into": {"db": "analytics"}}
            )

        merge_cursor = AsyncAggregationCursor(
            source, [{"$merge": {"into": "archive"}}], batch_size=2
        )
        with patch.object(
            merge_cursor, "_materialize", return_value=[{"_id": "m"}]
        ) as materialize:
            self.assertEqual(
                [document async for document in merge_cursor._stream_batches()],
                [{"_id": "m"}],
            )
            materialize.assert_awaited_once()

        with (
            patch.object(cursor, "_leading_search_stage", return_value=None),
            patch.object(
                cursor,
                "_effective_pipeline",
                return_value=[{"$project": {"_id": 1}}],
            ),
            patch(
                "mongoeco.api._async.aggregation_cursor.split_pushdown_pipeline",
                return_value=SimpleNamespace(remaining_pipeline=[], skip=0, limit=None),
            ),
            patch.object(cursor, "_split_streamable_pipeline", return_value=([], 0, 0)),
        ):
            self.assertEqual(
                [document async for document in cursor._stream_batches()], []
            )

    async def test_stream_batches_consumes_entire_batch_when_trailing_skip_exceeds_transformed_size(
        self,
    ):
        collection = _FakeCollection([{"_id": "1"}, {"_id": "2"}, {"_id": "3"}])
        cursor = AsyncAggregationCursor(
            collection, [{"$project": {"_id": 1}}, {"$skip": 3}], batch_size=2
        )
        with (
            patch(
                "mongoeco.api._async.aggregation_cursor.split_pushdown_pipeline",
                return_value=SimpleNamespace(
                    filter_spec={},
                    projection=None,
                    sort=None,
                    remaining_pipeline=[
                        {"$project": {"_id": 1}},
                        {"$skip": 3},
                    ],
                    skip=0,
                    limit=None,
                ),
            ),
            patch.object(
                cursor,
                "_split_streamable_pipeline",
                return_value=([{"$project": {"_id": 1}}], 3, None),
            ),
            patch.object(cursor, "_load_referenced_collections", return_value={}),
            patch.object(cursor, "_spill_policy", return_value=None),
        ):
            batches = [[{"_id": "1"}, {"_id": "2"}], [{"_id": "3"}], []]

            class _BatchCursor:
                def __init__(self, docs):
                    self._docs = docs

                async def to_list(self):
                    return self._docs

            cursor._build_pushdown_cursor = lambda _operation: _BatchCursor(
                batches.pop(0)
            )  # type: ignore[method-assign]
            self.assertEqual(
                [document async for document in cursor._stream_batches()], []
            )


class SyncAggregationCursorTests(unittest.TestCase):
    def test_internal_buffer_and_exhausted_load_paths_are_stable(self):
        async_cursor = _AsyncAggregationCursorStub([])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        cursor._sync_buffer = [{"_id": "buffered"}]

        self.assertEqual(cursor.to_list(1), [{"_id": "buffered"}])
        cursor._exhausted = True
        cursor._started = False
        self.assertEqual(cursor._load(), [])

    def test_active_first_closes_when_source_is_already_exhausted(self):
        async_cursor = _AsyncAggregationCursorStub([])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        cursor._active_async_iterable = async_cursor.__aiter__()

        self.assertIsNone(cursor.first())
        self.assertTrue(cursor._exhausted)
        self.assertIsNone(cursor._active_async_iterable)

    def test_empty_internal_chunk_closes_iterator(self):
        async_cursor = _AsyncAggregationCursorStub([])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        active = async_cursor.__aiter__()
        cursor._active_async_iterable = active
        iterator = _AggregationCursorIterator(cursor, active)

        with self.assertRaises(StopIteration):
            next(iterator)

        self.assertTrue(iterator._closed)
        self.assertTrue(cursor._exhausted)

    def test_to_list_validates_length_and_consumes_buffered_batches(self):
        async_cursor = _AsyncAggregationCursorStub(
            [{"_id": "1"}, {"_id": "2"}, {"_id": "3"}]
        )
        async_cursor._batch_size = 2
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        self.assertEqual(cursor.to_list(0), [])
        with self.assertRaisesRegex(ValueError, "non-negative"):
            cursor.to_list(-1)
        self.assertEqual(cursor.to_list(1), [{"_id": "1"}])
        self.assertEqual(cursor.to_list(2), [{"_id": "2"}, {"_id": "3"}])
        self.assertEqual(cursor.to_list(), [])

    def test_first_closes_active_iterator_when_read_fails(self):
        async_cursor = _FailingAsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        cursor._active_async_iterable = async_cursor.__aiter__()

        with self.assertRaisesRegex(InvalidOperation, "foreign session"):
            cursor.first()

        self.assertIsNone(cursor._active_async_iterable)
        self.assertEqual(async_cursor.close_calls, 1)

    def test_first_preserves_read_error_when_cleanup_also_fails(self):
        async_cursor = _FailingAsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_BrokenSyncClientStub(), async_cursor)
        cursor._active_async_iterable = async_cursor.__aiter__()

        with self.assertRaisesRegex(RuntimeError, "boom"):
            cursor.first()

    def test_collection_aggregate_accepts_pymongo_allow_disk_use_alias(self):
        with MongoClient(MemoryEngine()) as client:
            collection = client.db.events
            collection.insert_many(
                [
                    {"_id": "1", "rank": 2},
                    {"_id": "2", "rank": 1},
                ],
            )

            documents = list(
                collection.aggregate(
                    [{"$sort": {"rank": 1}}],
                    allowDiskUse=True,
                ),
            )

            self.assertEqual([document["_id"] for document in documents], ["2", "1"])
            with self.assertRaisesRegex(
                TypeError,
                "cannot pass both allowDiskUse and allow_disk_use",
            ):
                collection.aggregate([], allow_disk_use=True, allowDiskUse=True)

    def test_closed_message_remains_stable(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        cursor.close()

        with self.assertRaisesRegex(
            InvalidOperation,
            "cannot use aggregation cursor after it has been closed",
        ):
            cursor.to_list()

    def test_first_uses_direct_async_first_path_without_materializing_cache(
        self,
    ):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}, {"_id": "2"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        self.assertEqual(cursor.first(), {"_id": "1"})
        self.assertEqual(async_cursor.first_calls, 1)
        self.assertEqual(async_cursor.to_list_calls, 0)

    def test_close_is_idempotent_and_blocks_further_use(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        cursor.close()
        cursor.close()

        with self.assertRaises(InvalidOperation):
            cursor.first()
        with self.assertRaises(InvalidOperation):
            cursor.to_list()
        with self.assertRaises(InvalidOperation):
            list(cursor)

    def test_explain_delegates_to_async_cursor(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}])

        async def _explain():
            return {"engine": "fake", "details": ["SCAN"]}

        async_cursor.explain = _explain  # type: ignore[method-assign]
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        explanation = cursor.explain()
        self.assertEqual(explanation["engine"], "fake")
        self.assertEqual(explanation["details"], ["SCAN"])

    def test_iteration_closes_active_async_iterator_on_early_break(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}, {"_id": "2"}])
        client = _DeferredCleanupSyncClientStub()
        cursor = AggregationCursor(client, async_cursor)

        for document in cursor:
            self.assertEqual(document, {"_id": "1"})
            break

        self.assertEqual(async_cursor.close_calls, 0)
        client.run_deferred_cleanup()
        self.assertEqual(async_cursor.close_calls, 1)

    def test_close_closes_active_async_iterator(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}, {"_id": "2"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        iterator = iter(cursor)

        self.assertEqual(next(iterator), {"_id": "1"})
        cursor.close()

        self.assertEqual(async_cursor.close_calls, 1)

    def test_reiterating_after_partial_consumption_continues_from_current_position(
        self,
    ):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}, {"_id": "2"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        iterator = iter(cursor)
        self.assertEqual(next(iterator), {"_id": "1"})

        self.assertEqual(list(cursor), [{"_id": "2"}])

    def test_first_uses_current_position_after_iteration_starts(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}, {"_id": "2"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        iterator = iter(cursor)
        self.assertEqual(next(iterator), {"_id": "1"})

        self.assertEqual(cursor.first(), {"_id": "2"})

    def test_iterator_stops_when_closed(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        iterator = iter(cursor)

        self.assertIs(iter(iterator), iterator)
        self.assertEqual(next(iterator), {"_id": "1"})
        with self.assertRaises(StopIteration):
            next(iterator)

    def test_iterator_stops_if_replaced_by_another_active_iterator(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        iterator = iter(cursor)
        cursor._active_async_iterable = object()

        with self.assertRaises(StopIteration):
            next(iterator)

    def test_iterator_del_swallows_close_errors(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_BrokenSyncClientStub(), async_cursor)
        iterator = iter(cursor)

        iterator.__del__()
        self.assertTrue(iterator._closed)

    def test_first_returns_none_when_active_iterator_is_exhausted(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        iterator = iter(cursor)
        self.assertEqual(next(iterator), {"_id": "1"})

        self.assertIsNone(cursor.first())

    def test_cursor_stays_exhausted_after_full_iteration(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}, {"_id": "2"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        self.assertEqual(list(cursor), [{"_id": "1"}, {"_id": "2"}])
        self.assertEqual(list(cursor), [])
        self.assertEqual(cursor.to_list(), [])
        self.assertIsNone(cursor.first())
        self.assertEqual(async_cursor.close_calls, 1)

    def test_iterator_pulls_sync_batches_with_one_run_per_chunk(self):
        async_cursor = _AsyncAggregationCursorStub(
            [{"_id": str(index)} for index in range(5)]
        )
        async_cursor._batch_size = 2
        client = _CountingSyncClientStub()
        cursor = AggregationCursor(client, async_cursor)

        self.assertEqual(
            list(cursor),
            [{"_id": str(index)} for index in range(5)],
        )
        self.assertEqual(client.run_calls, 4)
        self.assertEqual(async_cursor.close_calls, 1)

    def test_iter_uses_cache_when_loaded(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        self.assertEqual(cursor.to_list(), [{"_id": "1"}])
        self.assertEqual(list(cursor), [{"_id": "1"}])

    def test_iterator_raises_stop_iteration_when_closed_explicitly(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}, {"_id": "2"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        iterator = iter(cursor)

        iterator.close()

        with self.assertRaises(StopIteration):
            next(iterator)

    def test_iterator_closes_active_async_iterator_when_pull_fails(self):
        async_cursor = _FailingAsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)
        iterator = iter(cursor)

        with self.assertRaisesRegex(InvalidOperation, "foreign session"):
            next(iterator)

        self.assertTrue(iterator._closed)
        self.assertIsNone(cursor._active_async_iterable)
        self.assertEqual(async_cursor.close_calls, 1)

    def test_first_returns_none_for_loaded_empty_cache(self):
        async_cursor = _AsyncAggregationCursorStub([])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        self.assertEqual(cursor.to_list(), [])
        self.assertIsNone(cursor.first())

    def test_del_swallows_close_errors(self):
        async_cursor = _AsyncAggregationCursorStub([{"_id": "1"}])
        cursor = AggregationCursor(_SyncClientStub(), async_cursor)

        def broken_close() -> None:
            raise RuntimeError("boom")

        cursor.close = broken_close
        cursor.__del__()

        self.assertTrue(cursor._closed)
