import hashlib,json,math,os,statistics,subprocess,time,sys
from pathlib import Path
root=Path(Path('/tmp/mongoeco-f11-b837-location.txt').read_text());prefix=Path('/tmp/mongoeco-f11-b837-confirmatory');target='SQLiteEngine-standard-aggregate-first-page'
state=json.loads((root/'evaluation.json').read_text())
assert state['gate_status']['G4']=='accepted' and state['gate_status']['G5']=='accepted','Finish deep and G5 before cost'
assert not Path(str(prefix)+'-config.json').exists(),'Single final stage already initialized; do not restart'
oldpath=Path('/tmp/mongoeco-f11-b837-cost-look6.json');old=json.loads(oldpath.read_text());assert old['counts']=={'accepted':43,'regression':0,'inconclusive':1} and old['cases'][target]['classification']=='inconclusive'
oldsummary=json.loads(Path('/tmp/mongoeco-f11-b837-cost-summary.json').read_text());assert len(oldsummary['attempts'])==2
worker=Path('/tmp/mongoeco-consumption-benchmark.py');assert hashlib.sha256(worker.read_bytes()).hexdigest()=='4de091e3bec69f21c348ad20bc4a7e6d2e7fb6a2b284fb660a35fb03bc3b37c8'
legacy=json.loads(Path('/tmp/mongoeco-f11-b837-cost-config.json').read_text());roots={'A':Path('/var/folders/gh/m3pllfqn6m14srd4s448b0zw0000gn/T/mongoeco-dispatch-wheel-hbjagp_l'),'B':root}
expected=json.loads(Path('/tmp/mongoeco-f11-b837-cost-samples.json').read_text())[0]['results']['consumption']
for r in roots.values():
 info=json.loads((r/'wheel.json').read_text());site=Path(info['site_packages'])
 assert hashlib.sha256(Path(info['wheel']).read_bytes()).hexdigest()==info['sha256']
 for p,h in json.loads((r/'runtime.json').read_text()).items():assert hashlib.sha256((site/p.removeprefix('src/')).read_bytes()).hexdigest()==h
config={'target':target,'blocks':6,'alpha':.005,'critical':4.033,'wall_seconds_max':2400,'original_attempts_used':2,'additional_attempts_max':1,'decision':'new blocks only; old 43 retained unchanged','old_look6_sha256':hashlib.sha256(oldpath.read_bytes()).hexdigest(),'launch_prefix':legacy['launch_prefix'],'operations':500,'hash_seed':'0','gc':'active/default (2000,10,10)','worker_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'plan_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
def write(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
write(str(prefix)+'-config.json',config);write(str(prefix)+'-samples.json',[]);records=[];failure=None;verdict='inconclusive';decision=None
state['confirmatory']={'attempts_used':1,'attempts_max':1,'config':str(prefix)+'-config.json','status':'running'};write(root/'evaluation.json',state)
start=time.monotonic();deadline=start+min(2400,5400-oldsummary['elapsed_wall_seconds'])
try:
 for block in range(6):
  for position,label in enumerate(('A','B','B','A')):
   info=json.loads((roots[label]/'wheel.json').read_text());env=dict(os.environ,PYTHONHASHSEED='0',MONGOECO_BENCH_OPERATIONS='500');env.pop('PYTHONPATH',None)
   command=[*config['launch_prefix'],str(worker),info['site_packages']];remaining=deadline-time.monotonic()
   if remaining<=0:raise TimeoutError('Approved final-stage budget exhausted')
   log=Path(str(prefix)+f'-b{block}-{position}-{label}')
   with Path(str(log)+'.err').open('w') as err:result=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=err,text=True,timeout=remaining)
   Path(str(log)+'.json').write_text(result.stdout);assert result.returncode==0,(label,result.returncode)
   value=json.loads(result.stdout);assert value.keys()==expected.keys()
   for k,row in value.items():
    for field,ref in expected[k].items():
     if field!='cpu_ns':assert row[field]==ref,(k,field)
    assert math.isfinite(row['cpu_ns']) and row['cpu_ns']>0
   records.append({'block':block,'position':position,'label':label,'wheel_sha256':info['sha256'],'results':value});write(str(prefix)+'-samples.json',records)
 # The only inferential evaluation is here, after all six complete blocks.
 x=[]
 for block in range(6):
  y=[math.log(r['results'][target]['cpu_ns']) for r in records[4*block:4*block+4]];x.append((y[1]+y[2]-y[0]-y[3])/2)
 sd=statistics.stdev(x);assert sd>0,'No variance resolution proof'
 mean=statistics.mean(x);margin=4.033*sd/math.sqrt(6);lo,hi=math.exp(mean-margin),math.exp(mean+margin)
 verdict='accepted' if hi<=1.05 else 'regression' if lo>1.05 else 'inconclusive'
 decision={'target':target,'classification':verdict,'ratio':math.exp(mean),'lower':lo,'upper':hi,'new_block_log_ratios':x,'critical':4.033,'n':6}
except BaseException as error:
 failure={'type':type(error).__name__,'message':str(error)};verdict='inconclusive' if isinstance(error,(TimeoutError,subprocess.TimeoutExpired)) else 'technical_failure'
finally:
 summary={'config':config,'verdict':verdict,'decision':decision,'failure':failure,'completed_records':len(records),'elapsed_wall_seconds':time.monotonic()-start,'no_further_looks':True}
 write(str(prefix)+'-summary.json',summary)
 assert hashlib.sha256(oldpath.read_bytes()).hexdigest()==config['old_look6_sha256']
 state=json.loads((root/'evaluation.json').read_text());state['confirmatory'].update(status=verdict,summary=str(prefix)+'-summary.json');state['gate_status']['G3']='accepted' if verdict=='accepted' else verdict;write(root/'evaluation.json',state)
 print(json.dumps(summary,indent=2),flush=True)
if failure:sys.exit(2)
