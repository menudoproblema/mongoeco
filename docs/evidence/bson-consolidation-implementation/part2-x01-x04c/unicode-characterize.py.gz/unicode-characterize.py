import sys,json,subprocess,socket,tempfile,time,hashlib,importlib,traceback
from pathlib import Path
sys.path.insert(0,'/tmp/mongoeco-x01-backends')
import pymongo
from bson import json_util
root=Path(tempfile.mkdtemp(prefix='mongoeco-part2-characterize-'));(root/'data').mkdir();Path('/tmp/mongoeco-part2-characterize-location.txt').write_text(str(root))
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
cmd=['/opt/homebrew/bin/mongod','--dbpath',str(root/'data'),'--port',str(port),'--bind_ip','127.0.0.1','--nounixsocket','--logpath',str(root/'mongod.log')]
proc=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE);out={'command':cmd,'regex':[],'granularity':[]}
try:
 deadline=time.monotonic()+20
 while time.monotonic()<deadline:
  assert proc.poll() is None,'Owned mongod exited during startup'
  if (root/'mongod.log').exists() and 'Waiting for connections' in (root/'mongod.log').read_text():break
  time.sleep(.05)
 else:raise TimeoutError('Owned startup exceeded 20s')
 with pymongo.MongoClient(f'mongodb://127.0.0.1:{port}',directConnection=True,serverSelectionTimeoutMS=2000) as client:
  assert client.admin.command('getCmdLineOpts')['parsed']['storage']['dbPath']==str(root/'data')
  out['server']=client.admin.command('buildInfo');out['fcv']=client.admin.command({'getParameter':1,'featureCompatibilityVersion':1})
  patterns=[('word-default',r'\w+','á word'),('word-ucp',r'(*UCP)\w+','á word'),('digit-default',r'\d+','١2'),('digit-ucp',r'(*UCP)\d+','١2'),('unicode-offset','ab','éab'),('ascii-caseless','(?i)ss','ß'),('empty-match',r'(?=a)','aa')]
  for name,pattern,text in patterns:
   row={'name':name,'pattern':pattern,'text':text,'backends':{}}
   try:row['native']=list(client.admin.aggregate([{'$documents':[{}]},{'$project':{'_id':0,'found':{'$regexFind':{'input':{'$literal':text},'regex':pattern}}}}]))
   except pymongo.errors.OperationFailure as e:row['native_error']={'code':e.code,'message':str(e)}
   for backend in ('re','regex','pcre2'):
    m=importlib.import_module(backend)
    try:
     hit=m.compile(pattern).search(text);row['backends'][backend]=None if hit is None else {'match':hit.group(),'idx':hit.start(),'captures':list(hit.groups())}
    except Exception as e:row['backends'][backend]={'error':type(e).__name__,'message':str(e)}
   try:
    mod=importlib.import_module('pcre2');hit=mod.compile(pattern,mod.ASCII).search(text);row['backends']['pcre2-ascii-default']=None if hit is None else {'match':hit.group(),'idx':hit.start(),'captures':list(hit.groups())}
   except Exception as e:row['backends']['pcre2-ascii-default']={'error':type(e).__name__,'message':str(e)}
   out['regex'].append(row)
  series=['R5','R10','R20','R40','R80','1-2-5','E6','E12','E24','E48','E96','E192','POWERSOF2']
  cases=[]
  for granularity,values in cases:
   row={'granularity':granularity,'values':values}
   try:row['native']=list(client.admin.aggregate([{'$documents':[{'v':v} for v in values]},{'$bucketAuto':{'groupBy':'$v','buckets':3,'granularity':granularity,'output':{'count':{'$sum':1},'total':{'$sum':'$v'}}}}]))
   except pymongo.errors.OperationFailure as e:row['error']={'code':e.code,'message':str(e)}
   out['granularity'].append(row)
finally:
 proc.terminate()
 try:proc.wait(timeout=10)
 except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
 out['mongod_terminal']=proc.returncode;out['owned_process_stopped']=True;(root/'observations.json').write_text(json_util.dumps(out,indent=2));print(root,flush=True)
