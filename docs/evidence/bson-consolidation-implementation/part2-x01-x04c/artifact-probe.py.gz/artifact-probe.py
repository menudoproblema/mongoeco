import asyncio, importlib.util, json, os
from pathlib import Path
import mongoeco
from mongoeco import MongoClient, AsyncMongoClient
from mongoeco.engines import MemoryEngine, SQLiteEngine
assert Path(mongoeco.__file__).is_relative_to('/tmp/mongoeco-part2-installed'), mongoeco.__file__
assert importlib.util.find_spec('pymongo') is None
assert importlib.util.find_spec('bson') is None
optional = os.environ.get('MONGOECO_REGEX_BACKEND') == 'pcre2'
if not optional:
    assert importlib.util.find_spec('pcre2') is None
pattern = r'a\Kb' if optional else 'ab'
for factory in (MemoryEngine, SQLiteEngine):
    with MongoClient(factory()) as c:
        rows=c.db.rows
        rows.insert_many([{'_id':i,'v':i,'text':'ab'} for i in range(20)])
        assert rows.count_documents({'text':{'$regex':pattern}})==20
        buckets=list(rows.aggregate([{'$bucketAuto':{'groupBy':'$v','buckets':3,'granularity':'R5'}}]))
        assert sum(row['count'] for row in buckets)==20
        found=list(rows.aggregate([{'$limit':1},{'$project':{'v':{'$regexFind':{'input':'$text','regex':pattern}}}}]))
        assert found[0]['v']['match']==('b' if optional else 'ab')
async def run():
    async with AsyncMongoClient(MemoryEngine()) as c:
        await c.db.rows.insert_one({'v':1,'text':'ab'})
        found=await c.db.rows.find_one({'text':{'$regex':pattern}})
        assert found['v']==1
        cur=await c.db.rows.aggregate([{'$bucketAuto':{'groupBy':'$v','buckets':1,'granularity':'POWERSOF2'}}])
        assert (await cur.to_list())[0]['count']==1
asyncio.run(run())
print(json.dumps({'module':mongoeco.__file__,'sdk_free':True,'backend':'pcre2' if optional else 'python','sync_engines':2,'async':True}))
