import gc, json, time, tracemalloc
import mongoeco
from mongoeco import MongoClient
from mongoeco.engines import MemoryEngine, SQLiteEngine
from mongoeco.core._regex_engine import _compile_pcre2, compile_pattern
from pathlib import Path
assert Path(mongoeco.__file__).is_relative_to('/tmp/mongoeco-part2-installed')
assert gc.isenabled()
started=time.monotonic(); cpu=time.process_time(); operations=0
tracemalloc.start()
def checkpoint():
    global operations
    operations += 1
    assert operations <= 600
    assert time.monotonic()-started <= 60
for i in range(300):
    assert compile_pattern('a'+str(i)).search('a'+str(i))
    checkpoint()
assert _compile_pcre2.cache_info().currsize == 256
assert compile_pattern('a'*4096).search('a'*4096)
checkpoint()
series=('R5','R10','R20','R40','R80','1-2-5','E6','E12','E24','E48','E96','E192','POWERSOF2')
for engine in (MemoryEngine,SQLiteEngine):
    with MongoClient(engine()) as client:
        rows=client.db.rows
        rows.insert_many([{'_id':i,'v':i,'text':'ab'} for i in range(100)])
        checkpoint()
        for _ in range(75):
            assert rows.count_documents({'text':{'$regex':r'a\Kb'}})==100
            checkpoint()
        for i in range(15):
            result=list(rows.aggregate([{'$bucketAuto':{'groupBy':'$v','buckets':7,'granularity':series[i%len(series)]}}]))
            assert sum(row['count'] for row in result)==100
            checkpoint()
        for _ in range(10):
            result=list(rows.aggregate([{'$limit':1},{'$project':{'_id':0,'empty':{'$regexFindAll':{'input':'a'*4096,'regex':'(?=a)|$'}},'captures':{'$regexFind':{'input':'a'*64,'regex':'(a)'*64}}}}]))
            assert len(result[0]['empty'])==4097
            assert len(result[0]['captures']['captures'])==64
            checkpoint()
peak=tracemalloc.get_traced_memory()[1];tracemalloc.stop()
assert peak <= 16*1024*1024,peak
assert _compile_pcre2.cache_info().currsize <=256
assert gc.isenabled()
print(json.dumps({'status':'passed','attempt':1,'operations':operations,'wall_seconds':time.monotonic()-started,'cpu_seconds':time.process_time()-cpu,'python_peak_bytes':peak,'cache':_compile_pcre2.cache_info()._asdict(),'gc_enabled':gc.isenabled(),'module':mongoeco.__file__},indent=2))
