from pathlib import Path
import concurrent.futures,json,urllib.request,hashlib
root=Path('/tmp/mongoeco-byte-response-sources');root.mkdir(exist_ok=True)
paths=['db/query/find_common.h','db/query/find_common.cpp','rpc/op_msg_rpc_impl.cpp','rpc/op_msg_rpc_impl.h','rpc/op_msg.cpp','rpc/op_msg.h','db/commands/query_cmd/find_cmd.cpp','db/commands/query_cmd/getmore_cmd.cpp','db/commands/query_cmd/run_aggregate.cpp']
versions=['r7.0.43','r8.0.32','r9.0.2']
def fetch(item):
 tag,path=item;url=f'https://raw.githubusercontent.com/mongodb/mongo/{tag}/src/mongo/{path}'
 try:
  data=urllib.request.urlopen(url,timeout=15).read()
  target=root/tag/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  return {'tag':tag,'path':path,'url':url,'sha256':hashlib.sha256(data).hexdigest()}
 except Exception as error:return {'tag':tag,'path':path,'url':url,'error':str(error)}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:rows=list(pool.map(fetch,[(v,p) for v in versions for p in paths]))
(root/'sources.json').write_text(json.dumps(rows,indent=2)+'\n')
print({'downloaded':sum('sha256' in r for r in rows),'errors':[(r['tag'],r['path'],r['error']) for r in rows if 'error' in r]})
