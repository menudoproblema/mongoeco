import json,os,struct
from bson import BSON
from pymongo import MongoClient

limit=16*1024*1024
result={}
with MongoClient(os.environ['MONGOECO_REAL_MONGODB_URI']) as client:
    c=client.response_document_limit.rows
    payload_size=limit//2-1024
    c.insert_one({'_id':1,'p':'x'*payload_size})
    for offset in (-1,0,1,16383,16384,16385):
        padding=limit+offset-len(BSON.encode({'_id':1,'a':'','b':''}))-2*payload_size
        pipeline=[{'$project':{'a':'$p','b':{'$concat':['$p','x'*padding]}}}]
        for raw in (False,True):
            phase='open';cursor=None
            try:
                cursor=(c.aggregate_raw_batches(pipeline) if raw else c.aggregate(pipeline))
                phase='iterate'
                row=next(cursor)
                size=len(row) if raw else len(BSON.encode(row))
                result[f'{offset}/{raw}']={'ok':True,'bytes':size}
            except Exception as error:
                result[f'{offset}/{raw}']={'ok':False,'class':type(error).__name__,'code':getattr(error,'code',None),'phase':phase,'details':getattr(error,'details',None)}
            finally:
                if cursor is not None:cursor.close()
    c.drop()
print(json.dumps(result,indent=2,default=str))
