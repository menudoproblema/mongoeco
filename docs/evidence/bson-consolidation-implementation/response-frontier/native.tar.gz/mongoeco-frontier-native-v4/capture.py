import os,subprocess,sys
from pathlib import Path
v=os.environ['MONGOECO_REAL_MONGODB_TARGET']; suffix=v.replace('.','_')
for case_set,key in [('response-frontier','response_frontier')]:
 reference=f'tests/fixtures/semantic_{key}_{suffix}.json'
 if key=='response_frontier':
  subprocess.run([sys.executable,'scripts/capture_differential_replay_golden.py','--target',v,'--case-set',case_set,'--output',reference],check=True)
 subprocess.run([sys.executable,'scripts/capture_differential_replay_golden.py','--target',v,'--case-set',case_set,'--output',f'/tmp/mongoeco-frontier-native-v4/{v}/{key}-check.json','--check',reference],check=True)
