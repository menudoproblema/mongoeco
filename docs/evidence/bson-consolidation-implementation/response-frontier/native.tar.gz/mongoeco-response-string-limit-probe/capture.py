import json,os,struct
from bson import BSON
from pymongo import MongoClient

limit=16*1024*1024
result={}
with MongoClient(os.environ['MONGOECO_REAL_MONGODB_URI']) as client:
    c=client.response_document_limit.rows
    c.insert_one({'_id':1,'p':'x'*(limit-1024-len(BSON.encode({'_id':1,'p':''})))})
    for offset in (21,22,23):
        pipeline=[{'$project':{'p':{'$concat':['$p','x'*(1024+offset)]}}}]
        for raw in (False,True):
            phase='open';cursor=None
            try:
                cursor=(c.aggregate_raw_batches(pipeline) if raw else c.aggregate(pipeline))
                phase='iterate'
                row=next(cursor)
                size=len(row) if raw else len(BSON.encode(row))
                result[f'{offset}/{raw}']={'ok':True,'bytes':size}
            except Exception as error:
                result[f'{offset}/{raw}']={'ok':False,'class':type(error).__name__,'code':getattr(error,'code',None),'phase':phase,'details':getattr(error,'details',None)}
            finally:
                if cursor is not None:cursor.close()
    c.drop()
print(json.dumps(result,indent=2,default=str))
