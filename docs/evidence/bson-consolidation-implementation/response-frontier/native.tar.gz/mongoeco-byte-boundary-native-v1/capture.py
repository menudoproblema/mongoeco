import json,os,struct
from bson import BSON
from pymongo import MongoClient

base=16*1024*1024//4
result={}
with MongoClient(os.environ['MONGOECO_REAL_MONGODB_URI']) as client:
    db=client.byte_boundary_probe
    c=db.rows
    empty_size=len(BSON.encode({'_id':1,'p':''}))
    def count(kind,size):
        c.delete_many({})
        payload='x'*(size-empty_size)
        c.insert_many([{'_id':n,'p':payload} for n in range(1,10)])
        if kind=='find_getmore':
            reply=db.command({'find':'rows','sort':{'_id':1},'batchSize':0})
            cursor_id=reply['cursor']['id']
            try:
                reply=db.command({'getMore':cursor_id,'collection':'rows'})
                return len(reply['cursor']['nextBatch'])
            finally:
                db.command({'killCursors':'rows','cursors':[cursor_id]})
        cursor=(c.find_raw_batches({},sort=[('_id',1)]) if kind=='find_first' else c.aggregate_raw_batches([{'$sort':{'_id':1}}]))
        try:
            raw=next(cursor);pos=0;documents=0
            while pos<len(raw):
                pos+=struct.unpack_from('<i',raw,pos)[0];documents+=1
            assert pos==len(raw)
            return documents
        finally:cursor.close()
    for kind in ('find_first','find_getmore','aggregate_getmore'):
        low=base-64;high=base+1
        probes=[]
        while high-low>1:
            size=(low+high)//2
            n=count(kind,size);probes.append([size,n])
            if n>=4:low=size
            else:high=size
        control=[[size,count(kind,size)] for size in (low-1,low,low+1)]
        result[kind]={'last_size_with_four':low,'first_size_with_three':high,'search':probes,'controls':control}
    c.drop()
print(json.dumps(result,indent=2))
