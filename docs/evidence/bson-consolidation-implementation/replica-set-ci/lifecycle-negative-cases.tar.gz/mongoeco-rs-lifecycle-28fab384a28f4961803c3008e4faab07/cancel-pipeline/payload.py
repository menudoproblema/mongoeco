import json,os,subprocess,sys,time
from pathlib import Path
Path('/tmp/mongoeco-rs-lifecycle-28fab384a28f4961803c3008e4faab07/cancel-pipeline/pids.json').write_text(json.dumps({'pid':os.getpid(),'pgid':os.getpgrp(),'child':child.pid if 'child' in locals() else None}))
time.sleep(300)
