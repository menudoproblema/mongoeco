import json,os,subprocess,sys,time
from pathlib import Path
child=subprocess.Popen([sys.executable,'-c','import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(300)']); Path('/tmp/mongoeco-rs-lifecycle-28fab384a28f4961803c3008e4faab07/cancel-payload/pids.json').write_text(json.dumps({'pid':os.getpid(),'pgid':os.getpgrp(),'child':child.pid if 'child' in locals() else None}))
time.sleep(300)
