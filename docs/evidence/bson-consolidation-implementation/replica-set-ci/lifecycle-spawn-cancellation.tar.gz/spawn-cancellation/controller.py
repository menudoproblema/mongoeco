import json,os,signal,subprocess,sys
from pathlib import Path
from scripts import with_mongodb_replica_set as fixture
original=subprocess.Popen
def spawn(*args,**kwargs):
    process=original(*args,**kwargs)
    if kwargs.get('start_new_session'):
        Path(sys.argv[1]).write_text(json.dumps({'pid':process.pid}))
        os.kill(os.getpid(),signal.SIGTERM)
    return process
fixture.subprocess.Popen=spawn
raise SystemExit(fixture.main(sys.argv[2:]))
