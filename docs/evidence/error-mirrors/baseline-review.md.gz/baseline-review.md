# Revisión de errores espejo y rutas compartidas

Fecha: 2026-10-16. Resultado: seis hallazgos observados pendientes.

Base y HEAD: `2fb04b6ce4a071257772bf3eec2961390724a1e8`.
Workset: `3c2f2fcefb3db4c3e8880ab2a3531b936ccbcef4f56e40f6b8a6b973908dad1a` (2969 archivos). Se revisa el candidato local, incluidas sus modificaciones sin commit. El mapa sigue la definición del cierre anterior: archivos tracked/no ignorados, excluyendo únicamente el directorio de evidencia autorreferente `docs/evidence/shared-errors/`. Se verificó además su manifiesto SHA256SUMS. No cambió el candidato.

Contrato aplicable: documentos públicos de error compatibles con la operación y el dialecto; códigos por elemento; conservación de contadores y efectos parciales; recuperación y reutilización de conexión. Se contrasta el alcance documentado en `docs/shared-error-documents.md` con rutas espejo de sus correcciones. No se atribuye la introducción de todos los defectos al diff actual: también hay huecos preexistentes en rutas compartidas.

## 1. P1 — Validación de un modificador escalar aborta prematuramente todo el lote

Ubicaciones: `src/mongoeco/api/_async/collection.py:417-419` y `_collection_bulk.py:242-244`.

Testigo: tres UpdateOne, uno válido, `{'$set': 3}`, otro válido, ordered True/False. PyMongo permite enviar el documento al servidor. MongoDB devuelve BulkWriteError con writeErrors[0].index=1 y code=9. Ordered conserva la primera modificación, nMatched=nModified=1. Unordered conserva ambas válidas y sus contadores son 2.

En la API directa, _require_update clasifica la estructura interna como TypeError; la preparación de todo el lote lo eleva antes de ejecutar el primer elemento. Se pierden ambos efectos válidos y el resumen de escritura. En el proxy se conservan los efectos nativos, pero PyMongo recibe un error sin code y lanza KeyError('code'). Afecta sync/async, Memory/SQLite y los tres dialectos. Los métodos de escritura individual también presentan la familia incorrecta.

Corrección esperada: distinguir validación del cliente de validación del servidor; rechazar este modificador en la fase del elemento con código 9 y conservar ejecución, indexación y contadores del lote.

## 2. P1 — Las ramas hermanas del compilador siguen produciendo errores sin código

Ubicaciones: `src/mongoeco/core/operators.py:510-532`, `:578-617`.

El identificador repetido corregido no cubre los siguientes testigos nativos:

| Testigo | Código MongoDB 7/8/9 |
| --- | --- |
| Ruta items.$[i] sin filtro | 2 |
| Filtro no utilizado | 9 |
| Documento de filtro vacío | 9 |
| Dos raíces en un filtro | 9 |
| Identificador I inválido | 2 |
| Modificador $invalid | 9 |

Mongoeco rechaza estos casos con code=None. Los lotes directos omiten writeErrors[].code. El proxy provoca KeyError('code') en el cliente PyMongo, en vez de BulkWriteError. Las escrituras válidas circundantes sí se aplican según ordered, por lo que la excepción espuria oculta efectos reales. find_one_and_update tampoco obtiene el documento de error completo esperado. Los comandos raw devuelven respuestas con writeErrors sin code.

Corrección esperada: asignar los códigos semánticos en las ramas de origen y completar la adaptación por fase. No sustituirlos por un código genérico de reserva.

## 3. P1 — La evaluación numérica conserva el mismo agujero de códigos

Ubicaciones: `src/mongoeco/core/aggregation/numeric_expressions.py:191-193` y `:316-321`.

Testigos: pipeline con `$sqrt: -1` (código nativo 28714) y `$divide: ['bad', 2]` (código nativo 14). Mongoeco eleva OperationFailure sin código. Afecta aggregate, update_one, update_many, find_one_and_update y lotes. En bulk sobre el proxy reaparece KeyError('code'), con escrituras parciales ya aplicadas.

Corrección esperada: conservar códigos de cada error de evaluación, sus familias según la operación y documentos completos en la frontera del comando. Ampliar la cobertura más allá de dividir/módulo por cero.

## 4. P1 — Agregación directa aún expone codeName sin errmsg

Ubicaciones: `src/mongoeco/core/aggregation/preparation.py:296-297`, `:405-406`, `:498-500`; espejo en `core/aggregation/runtime.py:550-551`.

En dialecto 9, aggregate con `$$CLUSTER_TIME` devuelve details={'codeName':'Location10071200'}; aggregate con `$setWindowFields: {'output':1}` devuelve details={'codeName':'TypeMismatch'}. MongoDB incluye ok, code y errmsg en ambos. El envoltorio de preparación solo completa código 17276 y deja escapar los otros. Un traductor que accede a details['errmsg'] reproduce el fallo original.

El proxy completa estos dos documentos; la fachada directa no. En 7/8 el output de ventana mal tipado pierde además código 14 y details, porque la validación específica está bajo un flag de versión.

Corrección esperada: completar todos los errores de comando que salgan de la agregación directa, tanto al preparar como al consumir el cursor, preservando familias y códigos; aplicar la validación estructural en las versiones que ya la exigen.

## 5. P2 — Las escrituras clásicas no reutilizan los detalles y el diagnóstico del duplicado

Ubicación: `src/mongoeco/api/_async/_write_errors.py:50-54`. Serializadores espejo: `_collection_bulk.py:560-566` y `_database_admin_write_commands.py:325-331`.

Testigo: índice único k_1, documentos con k=1 y k=2, intentar reemplazar/cambiar el segundo a k=1. update_one/update_many/replace_one directos devuelven DuplicateKeyError(code=11000, details=None); MongoDB entrega index, code, errmsg, keyPattern y keyValue. La guardia que reenvía WriteError sin adaptación también reenvía DuplicateKeyError.

Por el proxy sí aparecen los campos, pero errmsg sigue siendo `Duplicate key for unique index ...` con la tupla interna del motor. Falta el diagnóstico E11000 y dup key nativo. El espejo se observa también en bulk y comandos raw. El observador existente solo compara la forma de estos textos, por lo que no detecta esta divergencia literal (límite ya documentado).

Corrección esperada: reutilizar el contexto de duplicado bajo autoridad de escritura y el formateador BSON en estas fronteras, preservando DuplicateKeyError y el formato propio del elemento. El prefijo de ejecución cambia en MongoDB 9; no imponer un texto único a los tres dialectos. Añadir una observación semántica de estos diagnósticos, además de su forma.

## 6. P2 — $$CLUSTER_TIME usa el código de variable inexistente en 7/8

Ubicaciones: `src/mongoeco/core/aggregation/runtime.py:543-556` y `preparation.py:289-303`.

MongoDB standalone 7.0.43 y 8.0.32 reconocen esta variable reservada y rechazan su uso con 51144 / Location51144. Mongoeco solo activa el rechazo específico en dialecto 9 y en 7/8 produce 17276 / Location17276 (variable inexistente). Se reproduce en aggregate, updates de pipeline, findAndModify y lotes, tanto directos como wire. En 9 el código 10071200 es correcto; su documento parcial directo pertenece al hallazgo 4.

Corrección esperada: resolver el error de disponibilidad de variable reservada según dialecto, en preparación y evaluación, diferenciándolo de una variable desconocida.

## Evidencia y límites

- PyMongo real 4.19.0; MongoDB privados 7.0.43, 8.0.32 y 9.0.2.
- `matrix.json`: 71 escenarios × 18 celdas (nativo/directo, los tres targets, sync/async, Memory/SQLite en las directas).
- `witness.json`: 25 testigos × 30 celdas (añade proxy con Memory/SQLite sync/async). Conserva detalles y textos completos, resultados y documentos tras el fallo y una escritura de recuperación.
- Las fachadas sync/async coinciden tras normalizar solo el namespace de la base en diagnósticos.
- 750 escrituras de recuperación correctas. 18 comprobaciones de pool nativo/proxy: una conexión física reutilizada. Estos testigos no evidencian rotura de conexión, aunque PyMongo lance KeyError al interpretar el error.
- `cases.py`, `run.py`, `witness.py`, `verify.py` permiten repetir la exploración. `receipt.json` registra comprobaciones e identidades. Referencias propias detenidas y sus directorios de datos eliminados.
- El arnés inicial falla al proyectar raw writeErrors sin code porque el observador exige ese campo. Esos KeyError en matrix.json se etiquetan harness_error; no se atribuyen al ejecutor raw. La segunda captura conserva la respuesta real y demuestra la omisión. En bulk wire, en cambio, el KeyError procede del propio PyMongo y se captura dentro de la operación.
- ¿Se pudo fijar el workset? Sí; identidad inicial/final idéntica, HEAD fijado y evidencia anterior verificada. No hay cambios en código, tests ni documentos del candidato; solo evidencia temporal ignorada dentro del repositorio.
- ¿La base permite acreditar ausencia de otros findings? No. Es una revisión dirigida de fronteras y ramas compartidas, con un corpus finito. No se ha vuelto a ejecutar la suite global ni se afirma compatibilidad completa para cada operador, SDK, topología o carácter BSON.
