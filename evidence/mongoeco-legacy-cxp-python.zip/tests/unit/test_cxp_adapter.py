import unittest
from types import SimpleNamespace

import mongoeco.cxp as mongoeco_cxp
import mongoeco.cxp.capabilities as cxp_capabilities_module
import mongoeco.cxp.integration as cxp_integration_module
from mongoeco.compat import export_cxp_catalog, export_full_compat_catalog
from mongoeco.cxp import (
    MongoAggregationMetadata,
    MongoSearchMetadata,
    MongoVectorSearchMetadata,
    MONGODB_AGGREGATE_RICH_PROFILE,
    MONGODB_CATALOG,
    MONGODB_CORE_PROFILE,
    MONGODB_INTERFACE,
    MONGODB_PLATFORM_PROFILE,
    MONGODB_TEXT_SEARCH_PROFILE,
    MONGODB_SEARCH_PROFILE,
)
from mongoeco.cxp.catalogs.interfaces.database import MONGODB_AGGREGATE
from mongoeco.cxp.catalogs.interfaces.execution import (
    EXECUTION_ENGINE_CATALOG,
    EXECUTION_ENGINE_EXECUTION_STATUS,
    EXECUTION_ENGINE_EXECUTION_STREAM,
    EXECUTION_ENGINE_FAMILY_CATALOG,
    EXECUTION_ENGINE_FAMILY_INTERFACE,
    EXECUTION_ENGINE_INTERFACE,
    EXECUTION_ENGINE_INPUT_VALIDATION,
    EXECUTION_ENGINE_PLANNING,
    EXECUTION_ENGINE_RUN,
    PLAN_RUN_EXECUTION_CATALOG,
    PLAN_RUN_EXECUTION_EXECUTION_STATUS,
    PLAN_RUN_EXECUTION_EXECUTION_STREAM,
    PLAN_RUN_EXECUTION_INPUT_VALIDATION,
    PLAN_RUN_EXECUTION_INTERFACE,
    PLAN_RUN_EXECUTION_PLANNING,
    PLAN_RUN_EXECUTION_RUN,
)
from mongoeco.cxp.descriptors import (
    CapabilityDescriptor,
    CapabilityOperationBinding,
    ComponentCapabilitySnapshot,
)
from mongoeco.cxp.types import ComponentIdentity


class CxpAlignmentTests(unittest.TestCase):
    def test_mongoeco_cxp_exposes_canonical_database_mongodb_interface(
        self,
    ) -> None:
        self.assertEqual(MONGODB_CATALOG.interface, MONGODB_INTERFACE)
        self.assertEqual(MONGODB_INTERFACE, 'database/mongodb')
        self.assertEqual(
            MONGODB_CATALOG.capability_operation_names('aggregation'),
            (MONGODB_AGGREGATE,),
        )

    def test_profiles_are_reexported_from_canonical_cxp_catalog(self) -> None:
        self.assertEqual(MONGODB_CORE_PROFILE.interface, MONGODB_INTERFACE)
        self.assertEqual(MONGODB_TEXT_SEARCH_PROFILE.name, 'mongodb-text-search')
        self.assertEqual(MONGODB_SEARCH_PROFILE.name, 'mongodb-search')
        self.assertEqual(MONGODB_PLATFORM_PROFILE.name, 'mongodb-platform')
        self.assertEqual(
            MONGODB_AGGREGATE_RICH_PROFILE.name,
            'mongodb-aggregate-rich',
        )
        self.assertEqual(
            MongoAggregationMetadata.__name__,
            'MongoAggregationMetadata',
        )
        self.assertEqual(MongoSearchMetadata.__name__, 'MongoSearchMetadata')
        self.assertEqual(
            MongoVectorSearchMetadata.__name__,
            'MongoVectorSearchMetadata',
        )

    def test_execution_catalog_surface_is_aligned_with_cxp_3(self) -> None:
        self.assertEqual(EXECUTION_ENGINE_FAMILY_INTERFACE, 'execution/engine')
        self.assertEqual(
            EXECUTION_ENGINE_FAMILY_CATALOG.interface,
            'execution/engine',
        )
        self.assertEqual(
            EXECUTION_ENGINE_INTERFACE,
            'execution/plan-run',
        )
        self.assertEqual(
            EXECUTION_ENGINE_CATALOG.interface,
            'execution/plan-run',
        )
        self.assertEqual(
            PLAN_RUN_EXECUTION_INTERFACE,
            'execution/plan-run',
        )
        self.assertEqual(
            PLAN_RUN_EXECUTION_CATALOG.interface,
            'execution/plan-run',
        )
        self.assertEqual(
            PLAN_RUN_EXECUTION_CATALOG.capability_names(),
            (
                PLAN_RUN_EXECUTION_RUN,
                PLAN_RUN_EXECUTION_PLANNING,
                PLAN_RUN_EXECUTION_INPUT_VALIDATION,
                PLAN_RUN_EXECUTION_EXECUTION_STATUS,
                PLAN_RUN_EXECUTION_EXECUTION_STREAM,
            ),
        )
        self.assertEqual(EXECUTION_ENGINE_RUN, PLAN_RUN_EXECUTION_RUN)
        self.assertEqual(
            EXECUTION_ENGINE_PLANNING,
            PLAN_RUN_EXECUTION_PLANNING,
        )
        self.assertEqual(
            EXECUTION_ENGINE_INPUT_VALIDATION,
            PLAN_RUN_EXECUTION_INPUT_VALIDATION,
        )
        self.assertEqual(
            EXECUTION_ENGINE_EXECUTION_STATUS,
            PLAN_RUN_EXECUTION_EXECUTION_STATUS,
        )
        self.assertEqual(
            EXECUTION_ENGINE_EXECUTION_STREAM,
            PLAN_RUN_EXECUTION_EXECUTION_STREAM,
        )
        self.assertFalse(
            hasattr(mongoeco_cxp, 'EXECUTION_ENGINE_DRAFT_VALIDATION')
        )
        self.assertFalse(
            hasattr(mongoeco_cxp, 'EXECUTION_ENGINE_LIVE_EXECUTION_OBSERVABILITY')
        )
        self.assertFalse(hasattr(mongoeco_cxp, 'EXECUTION_ENGINE_CATALOG'))
        self.assertFalse(hasattr(mongoeco_cxp, 'PLAN_RUN_EXECUTION_CATALOG'))
        self.assertFalse(hasattr(mongoeco_cxp, 'Capability'))
        self.assertFalse(hasattr(mongoeco_cxp, 'CapabilityMatrix'))
        self.assertFalse(hasattr(mongoeco_cxp, 'CapabilityMetadata'))
        self.assertFalse(
            hasattr(mongoeco_cxp, 'mongoeco_public_cxp_capability_metadata')
        )
        self.assertFalse(
            hasattr(mongoeco_cxp, 'export_legacy_runtime_subset_catalog')
        )
        self.assertFalse(
            hasattr(mongoeco_cxp, 'export_cxp_extension_catalog')
        )
        self.assertFalse(hasattr(mongoeco_cxp, 'MONGODB_FIND'))
        self.assertFalse(hasattr(mongoeco_cxp, 'MONGODB_UPDATE_ONE'))
        self.assertFalse(hasattr(mongoeco_cxp, 'MONGODB_SEARCH'))

    def test_cxp_capability_exports_and_legacy_runtime_projection_share_a_canonical_source(
        self,
    ) -> None:
        metadata = (
            cxp_capabilities_module.mongoeco_public_cxp_capability_metadata()
        )
        exported = cxp_capabilities_module.export_cxp_capability_catalog()
        legacy = cxp_capabilities_module.export_legacy_runtime_subset_catalog()
        projection = cxp_capabilities_module.build_mongodb_explain_projection(
            capability='aggregation',
            additional_capabilities=('search',),
            metadata={'mode': 'local'},
        )
        platform_projection = (
            cxp_capabilities_module.build_mongodb_explain_projection(
                capability='transactions',
            )
        )
        write_projection = (
            cxp_capabilities_module.build_mongodb_explain_projection(
                capability='write',
            )
        )

        self.assertEqual(exported['interface'], 'database/mongodb')
        self.assertIn('profiles', exported)
        self.assertEqual(
            exported['profiles']['mongodb-text-search']['recommendedFor'],
            ['text-search-tests', 'search-without-vector-search'],
        )
        self.assertEqual(
            exported['profiles']['mongodb-text-search']['requirements'][-1],
            {
                'capabilityName': 'search',
                'requiredOperations': ['aggregate'],
                'requiredMetadataKeys': ['operators', 'aggregateStage'],
            },
        )
        self.assertEqual(
            exported['operations']['find'][0]['capabilityName'],
            'read',
        )
        self.assertEqual(
            exported['operations']['update_one'][0]['compatibleProfiles'],
            ['mongodb-core', 'mongodb-platform'],
        )
        self.assertEqual(
            exported['operations']['aggregate'][1]['capabilityName'],
            'search',
        )
        self.assertEqual(
            exported['operations']['serverStatus'][0]['capabilityName'],
            'collation',
        )
        self.assertEqual(
            exported['operations']['serverStatus'][0]['compatibleProfiles'],
            ['mongodb-platform'],
        )
        self.assertEqual(
            exported['operations']['sdam_capabilities'][0]['capabilityName'],
            'topology_discovery',
        )
        self.assertEqual(
            exported['operations']['listDatabases'][0]['capabilityName'],
            'persistence',
        )
        self.assertTrue(
            exported['profileSupport']['mongodb-text-search']['supported']
        )
        self.assertTrue(
            exported['profileSupport']['mongodb-platform']['supported']
        )
        self.assertEqual(
            exported['profileSupport']['mongodb-text-search']['validation'],
            {
                'messages': [],
                'unknownProfileCapabilities': [],
                'missingCapabilities': [],
                'missingOperations': [],
                'missingMetadataKeys': [],
                'invalidMetadata': [],
                'interfaceMismatch': None,
                'expectedInterface': None,
            },
        )
        self.assertEqual(
            exported['capabilities']['aggregation']['operations'][0]['name'],
            MONGODB_AGGREGATE,
        )
        self.assertIn(
            '$group',
            exported['capabilities']['aggregation']['metadata'][
                'supportedStages'
            ],
        )
        self.assertIn(
            'operationMetadata',
            exported['capabilities']['read']['metadata'],
        )
        self.assertTrue(
            exported['capabilities']['read']['metadata']['operationMetadata'][
                'find'
            ]['supportsExplain']
        )
        self.assertEqual(
            exported['capabilities']['read']['metadata']['operationMetadata'][
                'find'
            ]['resultType'],
            'cursor',
        )
        self.assertTrue(
            exported['capabilities']['read']['metadata']['operationMetadata'][
                'find'
            ]['acceptsProjection']
        )
        self.assertTrue(
            exported['capabilities']['write']['metadata']['operationMetadata'][
                'update_one'
            ]['supportsPipelineUpdate']
        )
        self.assertTrue(
            exported['capabilities']['write']['metadata']['operationMetadata'][
                'update_one'
            ]['supportsUpsert']
        )
        self.assertTrue(
            exported['capabilities']['aggregation']['metadata'][
                'operationMetadata'
            ]['aggregate']['supportsDatabaseScope']
        )
        self.assertIn(
            'fieldMappings',
            exported['capabilities']['search']['metadata'],
        )
        self.assertIn(
            'embeddedDocuments',
            exported['capabilities']['search']['metadata']['fieldMappings'],
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata'][
                'structuredFieldMappings'
            ],
            ['document', 'embeddedDocuments'],
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata'][
                'structuredParentPathOperators'
            ],
            ['text', 'phrase', 'autocomplete', 'wildcard', 'regex', 'exists'],
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['explainFeatures'],
            [
                'pathSummary',
                'resolvedLeafPaths',
                'structuredParentPathResolution',
                'querySemantics',
                'stageOptions',
                'countPreview',
                'highlightPreview',
                'facetPreview',
            ],
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['textSearchTier'],
            'closed-local-tier',
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['operatorSemantics']['autocomplete'],
            {
                'matchingMode': 'token-prefix',
                'tokenization': 'classic-text-local',
                'tokenOrder': ['any', 'sequential'],
                'scoreModes': ['frequency', 'binary'],
                'supportsFuzzy': True,
                'fuzzy': {
                    'maxEdits': [1, 2],
                    'supportsPrefixLength': True,
                    'supportsMaxExpansions': True,
                },
                'atlasParity': 'subset',
                'scope': 'local-text-tier',
            },
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['operatorSemantics']['wildcard'],
            {
                'matchingMode': 'glob-local',
                'patternSyntax': 'fnmatch-like',
                'allowAnalyzedField': True,
                'tokenFallbackOnAnalyzedField': True,
                'atlasParity': 'subset',
                'scope': 'local-text-tier',
            },
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['operatorSemantics']['regex'],
            {
                'matchingMode': 'python-regex-local',
                'supportsFlags': True,
                'supportsOptionsAlias': True,
                'supportedFlags': ['a', 'i', 'm', 's', 'u', 'x'],
                'allowAnalyzedField': True,
                'tokenFallbackOnAnalyzedField': True,
                'atlasParity': 'subset',
                'scope': 'local-text-tier',
            },
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['stageOptions']['highlight'],
            {
                'supportsPath': True,
                'supportsMaxChars': True,
                'supportsMaxNumPassages': True,
                'resultField': 'searchHighlights',
            },
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['stageOptions']['countOptions'],
            {
                'supportsThreshold': True,
                'thresholdMode': 'lowerBound',
            },
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['stageOptions']['facet'],
            {
                'supportsPath': True,
                'supportsNumBuckets': True,
                'supportsType': True,
                'supportsIncludeMeta': True,
                'supportedTypes': [
                    'string',
                    'number',
                    'date',
                    'boolean',
                    'objectId',
                    'uuid',
                ],
                'supportsCollectorOperator': True,
                'collectorOperatorSupports': [
                    'text',
                    'phrase',
                    'autocomplete',
                    'wildcard',
                    'regex',
                    'exists',
                    'in',
                    'equals',
                    'range',
                    'near',
                    'compound',
                ],
                'previewOnly': True,
            },
        )
        self.assertEqual(
            exported['capabilities']['collation']['metadata'],
            {
                'backend': {
                    'selectedBackend': 'pyuca',
                    'availableBackends': ['pyuca'],
                    'unicodeAvailable': True,
                    'advancedOptionsAvailable': False,
                },
                'capabilities': {
                    'supportedLocales': ['simple', 'en'],
                    'supportedStrengths': [1, 2, 3],
                    'supportsCaseLevel': True,
                    'supportsNumericOrdering': True,
                    'optionalIcuBackend': True,
                    'fallbackBackend': 'pyuca',
                    'advancedOptionsRequireIcu': [
                        'backwards',
                        'alternate',
                        'maxVariable',
                        'normalization',
                    ],
                },
                'operationMetadata': {
                    'find': {
                        'supportsCollation': True,
                        'scope': 'collection-query',
                        'behavior': 'filter-and-sort',
                    },
                    'find_one': {
                        'supportsCollation': True,
                        'scope': 'collection-query',
                        'behavior': 'filter',
                    },
                    'count_documents': {
                        'supportsCollation': True,
                        'scope': 'collection-query',
                        'behavior': 'filter',
                    },
                    'distinct': {
                        'supportsCollation': True,
                        'scope': 'collection-query',
                        'behavior': 'dedup',
                    },
                    'update_one': {
                        'supportsCollation': True,
                        'scope': 'collection-write',
                        'behavior': 'filter-match',
                    },
                    'update_many': {
                        'supportsCollation': True,
                        'scope': 'collection-write',
                        'behavior': 'filter-match',
                    },
                    'replace_one': {
                        'supportsCollation': True,
                        'scope': 'collection-write',
                        'behavior': 'filter-match',
                    },
                    'delete_one': {
                        'supportsCollation': True,
                        'scope': 'collection-write',
                        'behavior': 'filter-match',
                    },
                    'delete_many': {
                        'supportsCollation': True,
                        'scope': 'collection-write',
                        'behavior': 'filter-match',
                    },
                    'serverStatus': {
                        'supportsCapabilityInspection': True,
                        'inspectionSurface': 'database.command',
                        'metadataPath': 'mongoeco.collation',
                    },
                },
            },
        )
        self.assertEqual(
            exported['capabilities']['persistence']['metadata'],
            {
                'persistent': True,
                'storageEngine': 'runtime-dependent',
                'operationMetadata': {
                    'serverStatus': {
                        'supportsCapabilityInspection': True,
                        'inspectionSurface': 'database.command',
                        'metadataPaths': [
                            'storageEngine.name',
                            'mongoeco.engineRuntime',
                        ],
                    },
                    'listDatabases': {
                        'supportsCapabilityInspection': True,
                        'inspectionSurface': 'database.command',
                        'behavior': 'list-visible-databases',
                    },
                },
            },
        )
        self.assertEqual(
            exported['capabilities']['topology_discovery']['metadata'],
            {
                'topologyType': 'unknown',
                'serverCount': 1,
                'sdam': {
                    'fullSdam': False,
                    'topologyVersionAware': True,
                    'helloMemberDiscovery': True,
                    'serverHealthTracking': True,
                    'electionMetadataAware': True,
                    'longPollingHello': False,
                    'distributedMonitoring': False,
                },
                'operationMetadata': {
                    'hello': {
                        'supportsCapabilityInspection': True,
                        'inspectionSurface': 'database.command',
                        'metadataPaths': [
                            'helloOk',
                            'isWritablePrimary',
                            'maxWireVersion',
                        ],
                    },
                    'isMaster': {
                        'supportsCapabilityInspection': True,
                        'inspectionSurface': 'database.command',
                        'legacyAliasOf': 'hello',
                    },
                    'serverStatus': {
                        'supportsCapabilityInspection': True,
                        'inspectionSurface': 'database.command',
                        'metadataPath': 'mongoeco.sdam',
                    },
                    'sdam_capabilities': {
                        'supportsCapabilityInspection': True,
                        'inspectionSurface': 'mongoeco.client',
                        'metadataPath': 'sdam_capabilities()',
                    },
                },
            },
        )
        self.assertTrue(
            exported['capabilities']['read']['metadata']['operationMetadata'][
                'find'
            ]['acceptsSort']
        )
        self.assertTrue(
            exported['capabilities']['write']['metadata']['operationMetadata'][
                'update_one'
            ]['acceptsArrayFilters']
        )
        self.assertTrue(
            exported['capabilities']['write']['metadata']['operationMetadata'][
                'bulk_write'
            ]['acceptsOrderedExecution']
        )
        self.assertTrue(
            exported['capabilities']['read']['metadata']['operationMetadata'][
                'find'
            ]['acceptsCollation']
        )
        self.assertTrue(
            exported['capabilities']['write']['metadata']['operationMetadata'][
                'update_one'
            ]['acceptsCollation']
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['operationMetadata'][
                'aggregate'
            ]['aggregateStage'],
            '$search',
        )
        self.assertEqual(
            exported['capabilities']['search']['metadata']['operators'],
            metadata['search']['operators'],
        )
        self.assertEqual(
            legacy['vectorSearch']['similarities'],
            metadata['vector_search']['similarities'],
        )
        self.assertEqual(
            exported['capabilities']['vector_search']['metadata']['hybridFilterModes'],
            [
                'candidate-prefilter',
                'candidate-prefilter+post-candidate',
                'post-candidate',
            ],
        )
        self.assertIn(
            'scoreBreakdown',
            exported['capabilities']['vector_search']['metadata']['explainFeatures'],
        )
        self.assertEqual(
            exported['capabilities']['vector_search']['metadata']['operationMetadata'][
                'aggregate'
            ]['scoreField'],
            'vectorSearchScore',
        )
        self.assertEqual(projection['provider'], 'mongoeco')
        self.assertEqual(projection['minimalProfile'], 'mongodb-text-search')
        self.assertEqual(
            projection['compatibleProfiles'],
            ['mongodb-text-search', 'mongodb-search'],
        )
        self.assertEqual(projection['operationName'], 'aggregate')
        self.assertEqual(
            projection['operationMetadata']['aggregateStage'],
            '$search',
        )
        self.assertTrue(
            projection['compatibleProfileSupport']['mongodb-text-search'][
                'supported'
            ]
        )
        self.assertEqual(
            projection['minimalProfileRequirements'][-1],
            {
                'capabilityName': 'search',
                'requiredOperations': ['aggregate'],
                'requiredMetadataKeys': ['operators', 'aggregateStage'],
            },
        )
        self.assertEqual(projection['additionalCapabilities'], ['search'])
        self.assertEqual(projection['metadata'], {'mode': 'local'})
        self.assertEqual(
            write_projection['compatibleProfiles'],
            ['mongodb-core', 'mongodb-platform'],
        )
        self.assertNotIn('operationName', write_projection)
        self.assertNotIn('operationMetadata', write_projection)
        self.assertNotIn('minimalProfile', platform_projection)
        self.assertNotIn('minimalProfileRequirements', platform_projection)
        self.assertNotIn('compatibleProfiles', platform_projection)

    def test_catalog_operation_result_types_reject_inconsistent_catalog_entries(
        self,
    ) -> None:
        conflicting_catalog = SimpleNamespace(
            capabilities=(
                SimpleNamespace(
                    operations=(
                        SimpleNamespace(name='aggregate', result_type='cursor'),
                    ),
                ),
                SimpleNamespace(
                    operations=(
                        SimpleNamespace(
                            name='aggregate',
                            result_type='document',
                        ),
                    ),
                ),
            ),
        )

        with self.assertRaisesRegex(
            ValueError,
            "catalog operation result types must stay consistent",
        ):
            cxp_capabilities_module._catalog_operation_result_types(
                conflicting_catalog,
            )

    def test_profiles_validate_snapshot_requirements_for_reusable_test_gates(
        self,
    ) -> None:
        snapshot = ComponentCapabilitySnapshot(
            component_name='provider',
            identity=ComponentIdentity(
                interface=MONGODB_INTERFACE,
                provider='test-provider',
                version='1.0.0',
            ),
            capabilities=(
                CapabilityDescriptor(
                    name='read',
                    level='supported',
                    operations=(
                        CapabilityOperationBinding('find'),
                        CapabilityOperationBinding('find_one'),
                        CapabilityOperationBinding('count_documents'),
                        CapabilityOperationBinding('estimated_document_count'),
                        CapabilityOperationBinding('distinct'),
                    ),
                ),
                CapabilityDescriptor(
                    name='write',
                    level='supported',
                    operations=(
                        CapabilityOperationBinding('insert_one'),
                        CapabilityOperationBinding('insert_many'),
                        CapabilityOperationBinding('update_one'),
                        CapabilityOperationBinding('update_many'),
                        CapabilityOperationBinding('replace_one'),
                        CapabilityOperationBinding('delete_one'),
                        CapabilityOperationBinding('delete_many'),
                        CapabilityOperationBinding('bulk_write'),
                    ),
                ),
                CapabilityDescriptor(
                    name='aggregation',
                    level='supported',
                    operations=(CapabilityOperationBinding('aggregate'),),
                    metadata={
                        'supportedStages': ['$match', '$group'],
                        'supportedExpressionOperators': ['$add'],
                        'supportedGroupAccumulators': ['$sum'],
                        'supportedWindowAccumulators': ['$sum'],
                    },
                ),
                CapabilityDescriptor(
                    name='search',
                    level='supported',
                    operations=(CapabilityOperationBinding('aggregate'),),
                    metadata={
                        'operators': ['text'],
                        'aggregateStage': '$search',
                    },
                ),
                CapabilityDescriptor(
                    name='vector_search',
                    level='supported',
                    operations=(CapabilityOperationBinding('aggregate'),),
                    metadata={
                        'similarities': ['cosine'],
                        'aggregateStage': '$vectorSearch',
                        'scoreField': 'vectorSearchScore',
                    },
                ),
                CapabilityDescriptor(
                    name='transactions',
                    level='supported',
                    operations=(
                        CapabilityOperationBinding('start_session'),
                        CapabilityOperationBinding('with_transaction'),
                    ),
                ),
                CapabilityDescriptor(
                    name='change_streams',
                    level='supported',
                    operations=(CapabilityOperationBinding('watch'),),
                ),
                CapabilityDescriptor(
                    name='collation',
                    level='supported',
                    metadata={'backend': {}, 'capabilities': {}},
                ),
                CapabilityDescriptor(
                    name='persistence',
                    level='supported',
                    metadata={'persistent': True, 'storageEngine': 'sqlite'},
                ),
                CapabilityDescriptor(
                    name='topology_discovery',
                    level='supported',
                    metadata={
                        'topologyType': 'single',
                        'serverCount': 1,
                        'sdam': {},
                    },
                ),
            ),
        )

        self.assertTrue(
            MONGODB_CATALOG.is_component_snapshot_profile_compliant(
                snapshot,
                MONGODB_CORE_PROFILE,
            )
        )
        self.assertTrue(
            MONGODB_CATALOG.is_component_snapshot_profile_compliant(
                snapshot,
                MONGODB_TEXT_SEARCH_PROFILE,
            )
        )
        self.assertTrue(
            MONGODB_CATALOG.is_component_snapshot_profile_compliant(
                snapshot,
                MONGODB_SEARCH_PROFILE,
            )
        )
        self.assertTrue(
            MONGODB_CATALOG.is_component_snapshot_profile_compliant(
                snapshot,
                MONGODB_PLATFORM_PROFILE,
            )
        )
        self.assertTrue(
            MONGODB_CATALOG.is_component_snapshot_profile_compliant(
                snapshot,
                MONGODB_AGGREGATE_RICH_PROFILE,
            )
        )

    def test_compat_export_surfaces_operations_and_aggregation_subset_metadata(
        self,
    ) -> None:
        full_catalog = export_full_compat_catalog()
        cxp_catalog = export_cxp_catalog()

        self.assertEqual(full_catalog['cxp'], cxp_catalog)
        self.assertEqual(
            cxp_catalog['capabilities']['aggregation']['operations'][0][
                'name'
            ],
            'aggregate',
        )
        self.assertIn('mongodb-text-search', cxp_catalog['profiles'])
        self.assertIn(
            'supportedStages',
            cxp_catalog['capabilities']['aggregation']['metadata'],
        )

    def test_cxp_module_stays_minimal_while_integration_helpers_remain_available_in_submodule(
        self,
    ) -> None:
        self.assertFalse(
            hasattr(mongoeco_cxp, 'collect_provider_capability_snapshot')
        )
        self.assertTrue(
            hasattr(
                cxp_integration_module, 'collect_provider_capability_snapshot'
            )
        )
        self.assertTrue(
            hasattr(cxp_integration_module, 'negotiate_with_provider')
        )
        self.assertFalse(hasattr(mongoeco_cxp, 'CxpProvider'))
        self.assertFalse(hasattr(mongoeco_cxp, 'AsyncCxpProvider'))
